#!/bin/sh

source init-mlb-env.sh

if [ -f "${WEB_APP_DB_PATH}" ]
then
    MDM_3G="/dev/ttyACM0"
    MDM_4G="/dev/cdc-wdm1"
    DB_VPN_ACTIVE=`sqlite3 "${WEB_APP_DB_PATH}" "select active from vpn_active"`
    echo DB_VPN_ACTIVE = ${DB_VPN_ACTIVE}
    DB_VPN_POSTROUTING_INDX=()
    export VPN_IPSEC_CONF_RULES=""
    export VPN_IPSEC_SECRETS_RULES=""
    if [ "${DB_VPN_ACTIVE}" = 0 ]; then
        update-rc.d -f ipsec remove
    else
        for indx in {1..5}
        do
            rule="select active from vpn where id=${indx}"
            echo id = ${indx}
            rule="select ipsec from vpn where id=${indx}"
            DB_VPN_IPSEC_EN=`sqlite3 "${WEB_APP_DB_PATH}" "${rule}"`
            if [ "${DB_VPN_IPSEC_EN}" = 0 ]; then
                continue
            fi
            echo ipsec enable = ${DB_VPN_IPSEC_EN}            
            DB_VPN_POSTROUTING_INDX+=(${indx})
            rule="select conn_name from vpn where id=${indx}"
            DB_VPN_CONN_NAME=`sqlite3 "${WEB_APP_DB_PATH}" "${rule}"`
            echo connection name = ${DB_VPN_CONN_NAME}
            rule="select _left from vpn where id=${indx}"
            DB_VPN_LEFT=`sqlite3 "${WEB_APP_DB_PATH}" "${rule}"`
            echo local ip = ${DB_VPN_LEFT}
            rule="select startup_mode from vpn where id=${indx}"
            DB_VPN_START_MODE=`sqlite3 "${WEB_APP_DB_PATH}" "${rule}"`
            echo start in initial = ${DB_VPN_START_MODE}
            rule="select leftsubnet from vpn where id=${indx}"
            DB_VPN_LEFT_SUBNET=`sqlite3 "${WEB_APP_DB_PATH}" "${rule}"`
            echo local network = ${DB_VPN_LEFT_SUBNET}
            rule="select leftid from vpn where id=${indx}"
            DB_VPN_LEFTID=`sqlite3 "${WEB_APP_DB_PATH}" "${rule}"`
            echo local id = ${DB_VPN_LEFTID}
            rule="select _right from vpn where id=${indx}"
            DB_VPN_RIGHT=`sqlite3 "${WEB_APP_DB_PATH}" "${rule}"`
            echo remote ip = ${DB_VPN_RIGHT}
            rule="select rightsubnet from vpn where id=${indx}"
            DB_VPN_RIGHT_SUBNET=`sqlite3 "${WEB_APP_DB_PATH}" "${rule}"`
            echo remote network = ${DB_VPN_RIGHT_SUBNET}
            rule="select rightid from vpn where id=${indx}"
            DB_VPN_RIGHTID=`sqlite3 "${WEB_APP_DB_PATH}" "${rule}"`
            echo remote id = ${DB_VPN_RIGHTID}
            rule="select keyexchange from vpn where id=${indx}"
            DB_VPN_IKE_MODE=`sqlite3 "${WEB_APP_DB_PATH}" "${rule}"`
            echo ike proposal = ${DB_VPN_IKE_MODE}
            rule="select aggressive from vpn where id=${indx}"
            DB_VPN_OPER_MODE=`sqlite3 "${WEB_APP_DB_PATH}" "${rule}"`
            echo operation mode = ${DB_VPN_OPER_MODE}
            rule="select ike from vpn where id=${indx}"
            DB_VPN_IKE_ENCRYPT=`sqlite3 "${WEB_APP_DB_PATH}" "${rule}"`
            echo ike encrypt = ${DB_VPN_IKE_ENCRYPT}
            rule="select lifetime from vpn where id=${indx}"
            DB_VPN_LIFETIME=`sqlite3 "${WEB_APP_DB_PATH}" "${rule}"`
            echo life time = ${DB_VPN_LIFETIME}
            rule="select rekey from vpn where id=${indx}"
            DB_VPN_REKEY=`sqlite3 "${WEB_APP_DB_PATH}" "${rule}"`
            echo rekey = ${DB_VPN_REKEY}
            rule="select esp from vpn where id=${indx}"
            DB_VPN_ESP=`sqlite3 "${WEB_APP_DB_PATH}" "${rule}"`
            echo esp = ${DB_VPN_ESP}
            rule="select dpdaction from vpn where id=${indx}"
            DB_VPN_DPD_ACTION=`sqlite3 "${WEB_APP_DB_PATH}" "${rule}"`
            echo dpd action = ${DB_VPN_DPD_ACTION}
            rule="select dpddelay from vpn where id=${indx}"
            DB_VPN_DPD_DELAY=`sqlite3 "${WEB_APP_DB_PATH}" "${rule}"`
            echo dpd delay = ${DB_VPN_DPD_DELAY}
            rule="select dpdtimeout from vpn where id=${indx}"
            DB_VPN_DPD_TIMEOUT=`sqlite3 "${WEB_APP_DB_PATH}" "${rule}"`
            echo dpd timeout = ${DB_VPN_DPD_TIMEOUT}
            rule="select auth_mode from vpn where id=${indx}"
            DB_VPN_AUTH_MODE=`sqlite3 "${WEB_APP_DB_PATH}" "${rule}"`
            echo auth_mode = ${DB_VPN_AUTH_MODE}
            rule="select psk from vpn where id=${indx}"
            DB_VPN_PSK=`sqlite3 "${WEB_APP_DB_PATH}" "${rule}"`
            echo pre-share key = ${DB_VPN_PSK}
            rule="select local_cert from vpn where id=${indx}"
            DB_VPN_LOCAL_CERT=`sqlite3 "${WEB_APP_DB_PATH}" "${rule}"`
            echo local_cert = ${DB_VPN_LOCAL_CERT}
            rule="select remote_cert from vpn where id=${indx}"
            DB_VPN_REMOTE_CERT=`sqlite3 "${WEB_APP_DB_PATH}" "${rule}"`
            echo remote_cert = ${DB_VPN_REMOTE_CERT}
            if [ "${DB_VPN_IPSEC_EN}" = 0 ]; then
                DB_VPN_AUTO="ignore"
                echo auto = ${DB_VPN_AUTO}
            elif [ "${DB_VPN_IPSEC_EN}" = 1 -a "${DB_VPN_START_MODE}" = 1 ]; then
                DB_VPN_AUTO="start"
                echo auto = ${DB_VPN_AUTO}
            elif [ "${DB_VPN_IPSEC_EN}" = 1 -a "${DB_VPN_START_MODE}" = 0 ]; then 
                DB_VPN_AUTO="add"
                echo auto = ${DB_VPN_AUTO}
            fi

            VPN_IPSEC_CONF_RULES+="conn ${DB_VPN_CONN_NAME}"$'\n'
            VPN_IPSEC_CONF_RULES+="        authby=${DB_VPN_AUTH_MODE}"$'\n'
            VPN_IPSEC_CONF_RULES+="        aggressive=${DB_VPN_OPER_MODE}"$'\n'
            VPN_IPSEC_CONF_RULES+="        keyexchange=${DB_VPN_IKE_MODE}"$'\n'
            VPN_IPSEC_CONF_RULES+="        dpdaction=${DB_VPN_DPD_ACTION}"$'\n'
            VPN_IPSEC_CONF_RULES+="        dpddelay=${DB_VPN_DPD_DELAY}"$'\n'
            VPN_IPSEC_CONF_RULES+="        dpdtimeout=${DB_VPN_DPD_TIMEOUT}"$'\n'
            VPN_IPSEC_CONF_RULES+="        ike=${DB_VPN_IKE_ENCRYPT}"$'\n'
            VPN_IPSEC_CONF_RULES+="        esp=${DB_VPN_ESP}"$'\n'
            VPN_IPSEC_CONF_RULES+="        lifetime=${DB_VPN_LIFETIME}"$'\n'
            VPN_IPSEC_CONF_RULES+="        rekey=${DB_VPN_REKEY}"$'\n'
            VPN_IPSEC_CONF_RULES+="        left=%any"$'\n'
            if [ "${DB_VPN_AUTH_MODE}" = "pubkey" ]; then
                VPN_IPSEC_CONF_RULES+="        leftcert=local/${DB_VPN_LOCAL_CERT}"$'\n'
            fi
            VPN_IPSEC_CONF_RULES+="        leftsubnet=${DB_VPN_LEFT_SUBNET}"$'\n'
            VPN_IPSEC_CONF_RULES+="        leftid=\"${DB_VPN_LEFTID}\""$'\n'
            VPN_IPSEC_CONF_RULES+="        right=${DB_VPN_RIGHT}"$'\n'
            if [ "${DB_VPN_AUTH_MODE}" = "pubkey" ]; then
                VPN_IPSEC_CONF_RULES+="        rightcert=remote/${DB_VPN_REMOTE_CERT}"$'\n'
            fi
            VPN_IPSEC_CONF_RULES+="        rightsubnet=${DB_VPN_RIGHT_SUBNET}"$'\n'
            VPN_IPSEC_CONF_RULES+="        rightid=\"${DB_VPN_RIGHTID}\""$'\n'
            VPN_IPSEC_CONF_RULES+="        auto=${DB_VPN_AUTO}"$'\n'

            if [ "${DB_VPN_AUTH_MODE}" = "pubkey" ]; then
                VPN_IPSEC_SECRETS_RULES="\"${DB_VPN_RIGHTID}\" : RSA ${DB_VPN_LOCAL_CERT}"$'\n'
            elif [ "${DB_VPN_AUTH_MODE}" = "psk" ]; then
                VPN_IPSEC_SECRETS_RULES="\"${DB_VPN_RIGHTID}\" : PSK ${DB_VPN_PSK}"$'\n'
            fi
        done
        source gen-vpn-conf.sh
        update-rc.d -f ipsec defaults
    fi
	# echo "VPN=${DB_VPN}" > "${MLB_VPN_PATH}"
fi
