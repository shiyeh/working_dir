#!/bin/sh
###createUser ${DB_SNMP_WRITE_COMMUNITY} ${DB_SNMP_AUTH_PROTO} "${DB_SNMP_AUTH_KEY}" ${DB_SNMP_PRIV_PROTO} "${DB_SNMP_PRIV_KEY}"

### Generate /opt/mlis/conf/snmpd.conf file.
cat > "${MLB_SNMP_CFG_PATH}" << EOL
#!/bin/sh

${DB_SNMP_AC}

#           incl/excl subtree                          mask
view all    included  .1.3.6.1.2.1.1
view all    excluded  .1.3.6.1.4.1.8072
view all    excluded  .1.3.6.1.6
view all    included  .1.3.6.1.4.1.46144


#                context sec.model sec.level match  read   write  notif
access ROSystem ""     any       noauth    exact  system none   none
access ROGroup ""      any       noauth    exact  all    none   none
access RWGroup ""      any       noauth    exact  all    all    none

sysDescr MLiS MLB-G4201 3G Wireless Terminal
#syslocation .
#sysName .
syscontact support.mlis@schmidtelectronics.com

pass_persist .1.3.6.1.4.1.46144.2.2 /usr/bin/python -u /opt/mlis/snmp_agent/snmp_agent.py

EOL

cp -f "${MLB_SNMP_CFG_PATH}" "${SYS_SNMP_CFG_PATH}"
####### End to config "/opt/mlis/conf/snmpd.conf" 
