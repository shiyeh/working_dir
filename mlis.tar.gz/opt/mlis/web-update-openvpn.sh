#!/bin/sh

source init-mlb-env.sh

if [ -f "${WEB_APP_DB_PATH}" ]
then
    DB_OPENVPN_EN=`sqlite3 "${WEB_APP_DB_PATH}" "select active from openvpn"`
    echo DB_OPENVPN_EN = ${DB_OPENVPN_EN}
    if [ "${DB_OPENVPN_EN}" = 1 ]
    then
        DB_OPENVPN_CONF=`sqlite3 "${WEB_APP_DB_PATH}" "select conf from openvpn"`
        echo DB_OPENVPN_CONF = ${DB_OPENVPN_CONF}

        if [ ! -d "${SYS_OPENVPN_CONF_DIR}" ]
        then
            mkdir -p ${SYS_OPENVPN_CONF_DIR}
        fi

        rm -f ${SYS_OPENVPN_CONF_DIR}/*
        cp -f ${MLB_OPENVPN_CONF_DIR}/${DB_OPENVPN_CONF} ${SYS_OPENVPN_CONF_DIR}
        update-rc.d -f openvpn defaults
    else 
        update-rc.d -f openvpn remove
    fi
fi


