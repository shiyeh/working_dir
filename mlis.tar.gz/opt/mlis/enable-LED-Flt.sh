#!/bin/sh

if [ "$#" = 0 ]; then
	echo "must have choose on or off."
else
	case $1 in
		ON | on )           
			echo "LEDs ON"
 			onoff=1
 			;;
 		OFF | off )
			echo "LEDs ON"		
 			onoff=0
 			;;
 		Flash | FLASH | flash )
 			echo "LED flash mode, ON: 1sec, OFF: 1sec."
		 	onoff=2
		 	;;
        * )
        	echo "arg must be [ON|on] or [OFF|off]"
			exit 1
	esac
fi

LED_S3=/sys/class/leds/mlb:86
LED_S2=/sys/class/leds/mlb:87
LED_S1=/sys/class/leds/mlb:89
LED_4G=/sys/class/leds/mlb:117
LED_3G=/sys/class/leds/mlb:110
LED_FAIL=/sys/class/leds/mlb:112
LED_READY=/sys/class/leds/mlb:111
LED_SIM1=/sys/class/leds/mlb:113
LED_SIM2=/sys/class/leds/mlb:114


if [ -d "${LED_FAIL}" ]; then
	echo "Led FAIL: ${LED_FAIL}"
	
	if [ $onoff = 1 ]; then
		echo none > "${LED_FAIL}"/trigger
		VALUE=`cat "${LED_FAIL}"/max_brightness`
		echo "brightness is ${VALUE}"
		echo ${VALUE} > "${LED_FAIL}/brightness"
	elif [ $onoff = 2 ]; then
		echo timer > "${LED_FAIL}"/trigger
		echo 1000 > "${LED_FAIL}"/delay_on
		echo 1000 > "${LED_FAIL}"/delay_off	
	else
		echo none > "${LED_FAIL}"/trigger
		VALUE=0
		echo "brightness is ${VALUE}"
		echo ${VALUE} > "${LED_FAIL}/brightness"
	fi
fi
