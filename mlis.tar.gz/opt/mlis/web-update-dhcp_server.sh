#!/bin/sh

source /opt/mlis/init-mlb-env.sh

if [ -f "${WEB_APP_DB_PATH}" ]
then
	DB_DHCP_EN=`sqlite3 "${WEB_APP_DB_PATH}" 'select dhcp_server from dhcp_server'`
	DHCPD_IP_RANG_BGN=`sqlite3 "${WEB_APP_DB_PATH}" 'select start_ip from dhcp_server'`	
	IPADDRSUB=`echo ${DHCPD_IP_RANG_BGN} | awk -F. '{printf ("%s.%s.%s", $1, $2, $3)}'`
	DB_DHCP_IP_SUBMSK=`sqlite3 "${WEB_APP_DB_PATH}" 'select submask from dhcp_server'`	
	DB_DHCP_IP_START=`echo ${DHCPD_IP_RANG_BGN} | cut -d. -f4 | awk '{ print $1}'`
	DB_DHCP_IP_NUM=`sqlite3 web_console/app/app.db 'select max_users from dhcp_server'`
	DB_DHCP_IP_END=$(($DB_DHCP_IP_START+$DB_DHCP_IP_NUM))

	DHCPD_IP_RANG_BGN="${IPADDRSUB}.${DB_DHCP_IP_START}"
	DHCPD_IP_RANG_END="${IPADDRSUB}.${DB_DHCP_IP_END}"
	DHCP_IP_GW=`sqlite3 "${WEB_APP_DB_PATH}" 'select gateway from dhcp_server'`
	DHCP_IP_SUBMASK="${DB_DHCP_IP_SUBMSK}"

	export DHCP_STATIC_LEASE=""
	for indx in {1..2}
	do 
		rule="select active from dhcp_mapping where id=${indx}"
		DB_DHCP_STATIC_EN=`sqlite3 "${WEB_APP_DB_PATH}" "${rule}"`
		if [ "${DB_DHCP_STATIC_EN}" = 1 ]
		then
			rule="select ip from dhcp_mapping where id=${indx}"
			DB_DHCP_STC_IP=`sqlite3 "${WEB_APP_DB_PATH}" "${rule}"`
			rule="select mac from dhcp_mapping where id=${indx}"			
			DB_DHCP_STC_MAC=`sqlite3 "${WEB_APP_DB_PATH}" "${rule}"`

			# Static leases map
			#static_lease 00:60:08:11:CE:4E 192.168.0.54
			#static_lease 00:60:08:11:CE:3E 192.168.0.44
			DHCP_STATIC_LEASE+="static_lease ${DB_DHCP_STC_MAC} ${DB_DHCP_STC_IP}"
			DHCP_STATIC_LEASE+=$'\n'
		fi
	done
    if [ "${DB_DHCP_EN}" = 1 ]
    then
        /usr/sbin/update-rc.d udhcpd defaults
    else
        /usr/sbin/update-rc.d -f udhcpd remove
    fi
	source gen-dhcpd-conf.sh
fi