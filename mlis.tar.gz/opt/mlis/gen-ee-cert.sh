#!/bin/sh

source init-mlb-env.sh

if [ -f "${WEB_APP_DBTMP_PATH}" ];
then
    DB_EE_NAME=`sqlite3 "${WEB_APP_DBTMP_PATH}" "select ee_name from ee_cert"`
    echo DB_EE_NAME = ${DB_EE_NAME}
    DB_EE_LIFETIME=`sqlite3 "${WEB_APP_DBTMP_PATH}" "select lifetime from ee_cert"`
    echo DB_EE_LIFETIME = ${DB_EE_LIFETIME}
    DB_EE_C=`sqlite3 "${WEB_APP_DBTMP_PATH}" "select c from ee_cert"`
    echo DB_EE_C = ${DB_EE_C}
    DB_EE_ST=`sqlite3 "${WEB_APP_DBTMP_PATH}" "select st from ee_cert"`
    echo DB_EE_ST = ${DB_EE_ST}
    DB_EE_L=`sqlite3 "${WEB_APP_DBTMP_PATH}" "select l from ee_cert"`
    echo DB_EE_L = ${DB_EE_L}
    DB_EE_O=`sqlite3 "${WEB_APP_DBTMP_PATH}" "select o from ee_cert"`
    echo DB_EE_O = ${DB_EE_O}
    DB_EE_OU=`sqlite3 "${WEB_APP_DBTMP_PATH}" "select ou from ee_cert"`
    echo DB_EE_OU = ${DB_EE_OU}
    DB_EE_CN=`sqlite3 "${WEB_APP_DBTMP_PATH}" "select cn from ee_cert"`
    echo DB_EE_CN = ${DB_EE_CN}
    DB_EE_E=`sqlite3 "${WEB_APP_DBTMP_PATH}" "select e from ee_cert"`
    echo DB_EE_E = ${DB_EE_E}

    PRIVATE_KEY_PATH=${SYS_VPN_PRIVATE_KEY_DIR}/${DB_EE_NAME}.der
    echo PRIVATE_KEY_PATH = ${PRIVATE_KEY_PATH}
    EE_CERT_PATH=${SYS_VPN_CERTS_LOCAL_DIR}/${DB_EE_NAME}.der
    EE_DN=""
    if [ -n "${DB_EE_C}" ]; then
        EE_DN+="C=${DB_EE_C}, "
    fi
    if [ -n "${DB_EE_ST}" ]; then
        EE_DN+="ST=${DB_EE_ST}, "
    fi
    if [ -n "${DB_EE_L}" ]; then
        EE_DN+="L=${DB_EE_L}, "
    fi
    if [ -n "${DB_EE_O}" ]; then
        EE_DN+="O=${DB_EE_O}, "
    fi
    if [ -n "${DB_EE_OU}" ]; then
        EE_DN+="OU=${DB_EE_OU}, "
    fi
    if [ -n "${DB_EE_CN}" ]; then
        EE_DN+="CN=${DB_EE_CN}, "
    fi
    if [ -n "${DB_EE_E}" ]; then
        EE_DN+="E=${DB_EE_E}, "
    fi
    echo EE_DN = ${EE_DN}
    if [ -z "${EE_DN}" ]; then
        exit 1
    fi
    ipsec pki --gen > ${PRIVATE_KEY_PATH}

    ipsec pki --pub --in ${PRIVATE_KEY_PATH} | ipsec pki --issue --lifetime ${DB_EE_LIFETIME} --cacert ${SYS_VPN_ROOT_CA_PATH} --cakey ${SYS_VPN_ROOT_CA_KEY_PATH} --dn "${EE_DN}" > ${EE_CERT_PATH}
fi
