#!/bin/sh
kernel_build_date=`uname -v`


_version=v1.4.0_20170807_RC1_R0
_builddate=20170613

### Generate /opt/mlis/init-G420x file.
cat > "${MLB_INIT_PATH}" << EOF
#!/bin/sh
# Begin ${MLB_INIT_PATH}
export mlb_init=1
export mlb_model_name="MLB G420x"
export mlb_ver="${_version}"
export mlb_ver_builtdate="${_builddate}"
export mlb_rootfs_builtdate=`cat /etc/version`
export mlb_kernel_builtdate="${kernel_build_date}"
export mac_addr=`cat /sys/class/net/eth0/address`
source /opt/mlis/output-DINx.sh
source /opt/mlis/enable-RELAY.sh off
source /opt/mlis/init-managements.sh

sqlite3 "${WEB_STAT_DB_PATH}" "update system_info set model_name = \"\${mlb_model_name}\" where id = 1;"
sqlite3 "${WEB_STAT_DB_PATH}" "update system_info set fw_ver = \"\${mlb_ver}\" where id = 1;"
sqlite3 "${WEB_STAT_DB_PATH}" "update system_info set fw_build_time = \"\${mlb_ver_builtdate}\" where id = 1;"
sqlite3 "${WEB_STAT_DB_PATH}" "update lan_info set mac_addr = \"\${mac_addr}\" where id = 1;"
# End ${MLB_INIT_PATH}
