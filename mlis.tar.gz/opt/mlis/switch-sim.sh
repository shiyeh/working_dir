#!/bin/sh

if [ "$#" = 0 ]; then
	echo "must have choose sim1 or sim2."
else
	case $1 in
		sim1 | SIM1 )           
			echo "Switch to sim1"
 			onoff=0
 			;;
 		sim2 | SIM2 )
			echo "Switch to sim2"		
 			onoff=1
 			;;
        * )
        	echo "arg must be [sim1|SIM1] or [sim2|SIM2]"
			exit 1
	esac
fi

if [ ! -d /sys/class/gpio/gpio115 ]; then
	echo "Export gpio115 for SIMCARD switch"
	echo 115 > /sys/class/gpio/export
	echo out > /sys/class/gpio/gpio115/direction
fi

LED_SIM1=/sys/class/leds/mlb:113
LED_SIM2=/sys/class/leds/mlb:114
if [ ${onoff} = 0 ]; then
	echo 0 > "${LED_SIM2}/brightness"

	echo 255 > "${LED_SIM1}/brightness"	
	echo 'timer' > "${LED_SIM1}/trigger"
	echo '800' > "${LED_SIM1}/delay_on"
	echo '800' > "${LED_SIM1}/delay_off"
else
	echo 0 > "${LED_SIM1}/brightness"

	echo 255 > "${LED_SIM2}/brightness"
	echo 'timer' > "${LED_SIM2}/trigger"
	echo '800' > "${LED_SIM2}/delay_on"
	echo '800' > "${LED_SIM2}/delay_off"
fi	
	
echo "${onoff}" > /sys/class/gpio/gpio115/value
echo "Turn off 4G module."
source /opt/mlis/enable-4G.sh off
echo "Turn on 4G module."
source /opt/mlis/enable-4G.sh on

echo "done."
