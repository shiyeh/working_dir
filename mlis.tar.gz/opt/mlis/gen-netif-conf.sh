#!/bin/sh

### Generate /etc/network/interfaces file.
cat > "${SYS_NETWORK_DIR}/${MLB_NETWORK_IFACES}" << EOF
# Begin ${SYS_NETWORK_DIR}/${MLB_NETWORK_IFACES}
# The loopback interface
auto lo
iface lo inet loopback

# Wired interfaces
auto eth0
iface eth0 inet static
    address     ${IF_ADDR_IP}
    netmask     ${IF_MASK_STR}
    network     ${IF_ADDR_SUB}.0
    broadcast   ${IF_ADDR_SUB}.255

iface wwan1 inet dhcp
# End ${SYS_NETWORK_DIR}/${MLB_NETWORK_IFACES}
