#!/bin/sh

source init-mlb-env.sh
if [ -f "${WEB_APP_DBTMP_PATH}" ];
then
    DB_ROOT_CA_LIFETIME=`sqlite3 "${WEB_APP_DBTMP_PATH}" "select lifetime from ca_cert"`
    echo DB_ROOT_CA_LIFETIME = ${DB_ROOT_CA_LIFETIME}
    DB_ROOT_CA_C=`sqlite3 "${WEB_APP_DBTMP_PATH}" "select c from ca_cert"`
    echo DB_ROOT_CA_C = ${DB_ROOT_CA_C}
    DB_ROOT_CA_ST=`sqlite3 "${WEB_APP_DBTMP_PATH}" "select st from ca_cert"`
    echo DB_ROOT_CA_ST = ${DB_ROOT_CA_ST}
    DB_ROOT_CA_L=`sqlite3 "${WEB_APP_DBTMP_PATH}" "select l from ca_cert"`
    echo DB_ROOT_CA_L = ${DB_ROOT_CA_L}
    DB_ROOT_CA_O=`sqlite3 "${WEB_APP_DBTMP_PATH}" "select o from ca_cert"`
    echo DB_ROOT_CA_O = ${DB_ROOT_CA_O}
    DB_ROOT_CA_OU=`sqlite3 "${WEB_APP_DBTMP_PATH}" "select ou from ca_cert"`
    echo DB_ROOT_CA_OU = ${DB_ROOT_CA_OU}
    DB_ROOT_CA_CN=`sqlite3 "${WEB_APP_DBTMP_PATH}" "select cn from ca_cert"`
    echo DB_ROOT_CA_CN = ${DB_ROOT_CA_CN}
    DB_ROOT_CA_E=`sqlite3 "${WEB_APP_DBTMP_PATH}" "select e from ca_cert"`
    echo DB_ROOT_CA_E = ${DB_ROOT_CA_E}

    ROOT_CA_DN=""
    if [ -n "${DB_ROOT_CA_C}" ]; then
        ROOT_CA_DN+="C=${DB_ROOT_CA_C}, "
    fi
    if [ -n "${DB_ROOT_CA_ST}" ]; then
        ROOT_CA_DN+="ST=${DB_ROOT_CA_ST}, "
    fi
    if [ -n "${DB_ROOT_CA_L}" ]; then
        ROOT_CA_DN+="L=${DB_ROOT_CA_L}, "
    fi
    if [ -n "${DB_ROOT_CA_O}" ]; then
        ROOT_CA_DN+="O=${DB_ROOT_CA_O}, "
    fi
    if [ -n "${DB_ROOT_CA_OU}" ]; then
        ROOT_CA_DN+="OU=${DB_ROOT_CA_OU}, "
    fi
    if [ -n "${DB_ROOT_CA_CN}" ]; then
        ROOT_CA_DN+="CN=${DB_ROOT_CA_CN}, "
    fi
    if [ -n "${DB_ROOT_CA_E}" ]; then
        ROOT_CA_DN+="E=${DB_ROOT_CA_E}, "
    fi
    echo ROOT_CA_DN = ${ROOT_CA_DN}
    if [ -z "${ROOT_CA_DN}" ]; then
        exit 1
    fi
    ipsec pki --gen > ${SYS_VPN_ROOT_CA_KEY_PATH}
    ipsec pki --self --lifetime ${DB_ROOT_CA_LIFETIME} --in ${SYS_VPN_ROOT_CA_KEY_PATH} --dn "${ROOT_CA_DN}" --ca > ${SYS_VPN_ROOT_CA_PATH}
fi
