#!/bin/sh

source init-mlb-env.sh

DBTMP_ADDR_IP=`sqlite3 "${WEB_APP_DBTMP_PATH}" 'select ip_addr from lan_setting'`
sqlite3 "${WEB_STAT_DB_PATH}" 'update lan_info set ip_addr = "'"${DBTMP_ADDR_IP}"'" where ID = 1'
sqlite3 "${WEB_APP_DBTMP_PATH}" 'update dhcp_server set gateway = "'"${DBTMP_ADDR_IP}"'" where ID = 1'

DBTMP_ADDR_MASK=`sqlite3 "${WEB_APP_DBTMP_PATH}" 'select submask from lan_setting'`
sqlite3 "${WEB_STAT_DB_PATH}" 'update lan_info set submask = "'"${DBTMP_ADDR_MASK}"'" where ID = 1'
sqlite3 "${WEB_APP_DBTMP_PATH}" 'update dhcp_server set submask = "'"${DBTMP_ADDR_MASK}"'" where ID = 1'

DBTMP_ADDR_DNS=`sqlite3 "${WEB_APP_DBTMP_PATH}" 'select dns from lan_setting'`
sqlite3 "${WEB_APP_DBTMP_PATH}" 'update dhcp_server set dns = "'"${DBTMP_ADDR_DNS}"'" where ID = 1'
DBTMP_ADDR_SEC_DNS=`sqlite3 "${WEB_APP_DBTMP_PATH}" 'select sec_dns from lan_setting'`
sqlite3 "${WEB_APP_DBTMP_PATH}" 'update dhcp_server set sec_dns = "'"${DBTMP_ADDR_SEC_DNS}"'" where ID = 1'

cp -f "${WEB_APP_DBTMP_PATH}" "${WEB_APP_DB_PATH}"

source web-update-all.sh

exit 0
