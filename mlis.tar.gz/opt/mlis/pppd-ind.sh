#!/bin/sh
sleep 1
PPPINDLOG="/tmp/pppd-ind_log"
PPPINDINFO="/tmp/ppp_info"
echo "start serial config utility" >> "${PPPINDLOG}"

if [ ${MDM_PATH} = "" ]
then
	exit 1
fi

if [ ! -n "${PPP_CTRL+1}" ]
then 
	PPP_CTRL="/var/tmp/ppp-stop"
fi

MDM_PPP_OPT="/opt/mlis/conf/apn_opt"
MDM_QMI_OPT="/opt/mlis/conf/qmi-network.conf"
MDM_QMI_CMD="/opt/mlis/qmi-network.sh"
NWIF_UP_CMD="/sbin/ifup"
NWIF_DN_CMD="/sbin/ifdown"

if [ -e ${MDM_PPP_OPT} ]
then
	source "${MDM_PPP_OPT}"
	if [ ${MLBPRISIM} == "sim1" ]
	then
		export MLBAPN="${MLBAPN1}"
		export MLBPDPYTPE="${MLBPDPYTPE1}"
		export MLBUSRNAME="${MLBUSRNAME1}"
		export MLBPASSWORD="${MLBPASSWORD1}"
	elif [ ${MLBPRISIM} == "sim2" ]
	then
		export MLBAPN="${MLBAPN2}"
		export MLBPDPYTPE="${MLBPDPYTPE2}"
		export MLBUSRNAME="${MLBUSRNAME2}"
		export MLBPASSWORD="${MLBPASSWORD2}"
	else
		echo "Incorrct Primary SIM Slot setting: ${MLBPRISIM} " >> "${PPPINDLOG}"
		exit 1
	fi
else
	echo "Please setup Modem APN configurtaion first!!" >> "${PPPINDLOG}"
	exit 1
fi
MDM_ACT_SIM="${MLBPRISIM}"
echo "APN=${MLBAPN}" > "${MDM_QMI_OPT}"

echo "PPPD ACTIVE SIM is ${MDM_ACT_SIM}" >> "${PPPINDLOG}"
echo "PPPD APN setting is ${MLBAPN}" >> "${PPPINDLOG}"

source /opt/mlis/init-mlb-env.sh
while true;
do 
	if [ ! -f /tmp/dev-manager.pid ]
	then
		PATH=/sbin:/bin:/usr/sbin:/usr/bin:/opt/mlis/dev_management
		NAME=DEV-MGR
		DESC=dev_management
		DAEMON_PID_FILE=/var/run/dev-manager.pid
		DAEMON_OPTS='start'
		DAEMON=/opt/mlis/dev_management/manager.py
		if start-stop-daemon --start --quiet --background \
			--pidfile $DAEMON_PID_FILE --make-pidfile \
			--name $NAME --exec $DAEMON -- $DAEMON_OPTS
		then
			echo "MLB DEV Manager is running."
		fi
	fi


	while [ -e "/tmp/qmi-network-state" ] || [ -e "/run/lock/LCK..ttyACM0" ]
	do
		sh /opt/mlis/update-web-cellular_info.sh 
		sleep 3

		if [ -f "${PPP_CTRL}" ]
		then
			if [ -c "${MDM_3G}" ]
			then
				kill `cat /run/lock/LCK..*`
				sleep 3
			fi

			if [ -c "${MDM_4G}" ]
			then
				sh "${MDM_QMI_CMD}" "${MDM_4G}" "stop"
				sleep 5
				${NWIF_DN_CMD} "wwan1" &
			fi
		fi
	done

	if [ -f "${PPP_CTRL}" ]
	then
		echo "MLB_PPP_IP=192.168.0.1" > "${PPPINDINFO}"
		sh /opt/mlis/update-web-cellular_info.sh 
		
		MDM_REQ=`cat "${PPP_CTRL}"`
		timestamp=`date +"%F-%T"`
		echo "${timestamp} Recv req from mdm mgr: ${MDM_REQ}" >> "${PPPINDLOG}"

		if test -z "${MDM_REQ}"
		then
			sleep 30
			
		# workaround, 
		# TOTO: Using MCCP CMD here.
		elif [ ${MDM_REQ} == "MDMMGR-SIMSWITCH-REQ" ]
		then
			if [ ${MDM_ACT_SIM} == "sim1" ]
			then
				MDM_ACT_SIM="sim2"
				MLBAPN="${MLBAPN2}"
				MLBPDPYTPE="${MLBPDPYTPE2}"
				MLBUSRNAME="${MLBUSRNAME2}"
				MLBPASSWORD="${MLBPASSWORD2}"
			elif [ ${MDM_ACT_SIM} == "sim2" ]
			then
				MDM_ACT_SIM="sim1"
				MLBAPN="${MLBAPN1}"
				MLBPDPYTPE="${MLBPDPYTPE1}"
				MLBUSRNAME="${MLBUSRNAME1}"
				MLBPASSWORD="${MLBPASSWORD1}"
			else
				echo "Incorrct Active SIM Slot value: ${MDM_ACT_SIM} " >> "${PPPINDLOG}"
				exit 1
			fi
			echo "APN=${MLBAPN}" > "${MDM_QMI_OPT}"

			# stop mdm manager ?? avoid /dev/ttyUSB device be locked.
			
			# switch SIM solt
			sh /opt/mlis/switch-sim.sh "${MDM_ACT_SIM}"
			echo "Switch Active SIM Slot to ${MDM_ACT_SIM}, APN=${MLBAPN} " >> "${PPPINDLOG}"

			wcnt=1
			until [ -c ${MDM_3G} ] || [ -c ${MDM_4G} ] || [ ${wcnt} = 3 ]
			do
				wcnt=$(( wcnt+1 ))
				echo "Trying (${wcnt}): to find modem." >> "${PPPINDLOG}"
				sleep 5
			done			
			if [ ${wcnt} = 3 ]
			then
				MDM_PATH=""
				echo "No modem on device" >> "${PPPINDLOG}"
				exit 1
			elif [ -c ${MDM_3G} ]
			then
				MDM_PATH=${MDM_3G}
				sleep 3
			elif [ -c ${MDM_4G} ]
			then
				MDM_PATH=${MDM_4G}
			fi
			timestamp=`date +"%F-%T"`
			echo "${timestamp} finish running ${MDM_REQ}" >> "${PPPINDLOG}"
			rm /tmp/ppp-stop
			# start mdm manager
		fi
	else
		#statements
		echo "MLB_PPP_IP=0.0.0.0" > "${PPPINDINFO}"
		sh /opt/mlis/update-web-cellular_info.sh 

		if [ -c ${MDM_4G} ]
		then
			set -x
			sh "${MDM_QMI_CMD}" "${MDM_4G}" "start"
			sleep 5

			if [ -e "/tmp/qmi-network-state" ]
			then
				${NWIF_UP_CMD} "wwan1" &
			fi
			set +x
		fi

		if [ -c ${MDM_3G} ]
		then
			if [ -f "/opt/mlis/conf/pap-secrets" ]
			then
				cp -rf /opt/mlis/conf/pap-secrets /etc/ppp/pap-secrets
			else
				rm -rf /etc/ppp/pap-secrets
				touch /etc/ppp/pap-secrets
			fi

			pppd call cdma ${MDM_PATH} &
			echo "Waiting 60sec, and restart pppd." >> "${PPPINDLOG}"
			sleep 30
		fi
	fi	
done
