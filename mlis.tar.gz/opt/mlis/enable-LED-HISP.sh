#!/bin/sh

if [ "$#" = 0 ]; then
	echo "must have choose on or off."
else
	case $1 in
		ON | on )           
			echo "LEDs ON"
 			onoff=1
 			;;
 		OFF | off )
			echo "LEDs ON"		
 			onoff=0
 			;;
        * )
        	echo "arg must be [ON|on] or [OFF|off]"
			exit 1
	esac
fi

LED_S3=/sys/class/leds/mlb:86
LED_S2=/sys/class/leds/mlb:87
LED_S1=/sys/class/leds/mlb:89
LED_LOW_SP=/sys/class/leds/mlb:117
LED_HI_SP=/sys/class/leds/mlb:110
LED_FAIL=/sys/class/leds/mlb:111
LED_READY=/sys/class/leds/mlb:112
LED_SIM1=/sys/class/leds/mlb:113
LED_SIM2=/sys/class/leds/mlb:114

if [ -d "${LED_HI_SP}" ]; then
	echo "Led HiSpeed: ${LED_HI_SP}"
	if [ $onoff = 1 ]; then
		VALUE=`cat "${LED_HI_SP}"/max_brightness`
	else
		VALUE=0
	fi
	echo "brightness is ${VALUE}"
	echo ${VALUE} > "${LED_HI_SP}/brightness"
fi