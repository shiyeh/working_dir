#!/usr/bin/python -u

import snmp_passpersist
import pdb
import pprint
import os
from copy import copy
import json
from db_agent import dbAgent

POLLING_INTERVAL = 20
G420X_BASE_OID = ".1.3.6.1.4.1.46144.2.2"
DB_AGENT = dbAgent()

##################################################
### type 
### 0: bool
### 1: integer
### 2: string
### 3: ipaddress
##################################################
TYPE_DIC = ('integer', 'integer', 'string', 'ipaddress')

with open('/opt/mlis/db_management/menus.json') as f:
    MENUS = json.load(f)

##cannot configurate via snmp. 
READ_ONLY_MENU = {
                  'system_info': [
                                  'model_name',
                                  'fw_build_time',
                                  'fw_ver'
                                 ],
                  'lanInfo': [
                              'ip_addr',
                              'mac_addr',
                              'submask'
                             ],
                  'cellular': [
                               'rssi',
                               'ip_addr',
                               'mode'
                              ],
                  'cellular_info': [
                                    'imei',
                                    'imsi'
                                   ]
                 }
class snmpBase(object):
    def __init__(self, base_oid=None):
        if base_oid:
            self.base_oid = base_oid
            self.snmp = snmp_passpersist.PassPersist(self.base_oid)
            self.update()

    def update(self):
        raise NotImplemented

    def start(self):
        self.snmp.start(self.update, self.polling_interval)


class snmpAgent(snmpBase):
    def __init__(self):
        self.menu_flag = True
        self.assign_oids()
        super(snmpAgent, self).__init__(G420X_BASE_OID)
        #super(snmpAgent, self).__init__()
        self.polling_interval = POLLING_INTERVAL
        self.snmp.register_setter(self.base_oid, self.setter)
        #self.snmp.register_setter('3.1.8.0', self.setter)

    def assign_oids_back(self, oids):
        for oid, data in oids.items():
            ### tuple type that mean the data is single column in the database.
            if type(data[0]) is tuple:
                for idx, value in enumerate(data):
                    _oid = "{}.{}.{}".format(oid[:-2], idx + 1, 0)
                    oids[_oid] = value

            ### list type that mean the data is multi columns in the database.
            elif type(data[0]) is list:
                for _id, menu in enumerate(data):
                    for idx, value in enumerate(menu):
                        _oid = "{}.{}.{}.{}".format(oid[:-2], 1, idx + 1, _id + 1)
                        oids[_oid] = value

            ### dict type that mean the data is reference.
            elif type(data[0]) is dict:
                for idx, menu in enumerate(data):
                    for key, value in menu.items():
                        _oid = "{}.{}".format(oid[:-2], idx + 1)
                        oids[_oid] = (key, value)


    def assign_oids(self):
        self.oids = {}
        self.peel_onion("", MENUS)
        self.oids_ref = copy(self.oids)
        self.assign_oids_back(self.oids_ref)

        self.query_data(self.oids)
        self.assign_oids_back(self.oids)

        ### drop useless data from self.oids.
        self.clean_oids(self.oids)
        #pprint.pprint(self.oids)
        #pprint.pprint(self.oids_ref)

    def clean_oids(self, oids):
        for oid, value in oids.items():
            if type(value) is list:
                oids.pop(oid)

    def query_data(self, dic):
        temp = {}
        for oid, value in dic.items():
            ### value's type is not list that mean the oid is not a table,
            ### so query is unnecessary.
            if type(value) is not list:
                continue

            query = dic[oid[:-2]]
            raw_data = self.db_query(query)
            list_tags = [data.values()[0] for i, data in enumerate(value)]
            list_keys = [data.keys()[0] for i, data in enumerate(value)]

            for idx, data in enumerate(raw_data):
                config = [data.get(key) for _len, key in enumerate(list_keys)]
                config = (zip(config, list_tags))
                _oid = "{}.0".format(oid[:-2])

                ### arrsign data in the temp dict. 
                if temp.get(_oid) is None:
                    temp[_oid] = config
                elif type(temp[_oid][0]) is tuple:
                    temp[_oid] = [temp[_oid]] + [config]
                else:
                    temp[_oid] = temp[_oid] + [config]
        self.oids.update(temp)

    def peel_onion(self, _oid, onion):
        for oid, menus_dic in enumerate(onion):
            for menu, sub_menus in menus_dic.items():
                if type(sub_menus) is not int:
                    if not self.menu_flag:
                        _oid = _oid[:-2]
                        self.menu_flag = True
                    _oid += "." + str(oid+1)
                    self.oids[_oid[1:]] = menu
                    self.peel_onion(_oid, sub_menus)
                else:
                    self.menu_flag = False
                    oid = "{}.{}".format(_oid[1:], 0) 
                    self.oids[oid] = onion

    def db_query(self, index, method='get'):
        if method is 'check':
            return DB_AGENT.query(method, index)
        data = DB_AGENT.query(method, index)
        result = data[index] if data['result'] == 'success' else False
        return result

    def analysis_db_date(self, oid, db_data):
        dic = {}
        data = self.oids_ref.get("{}.{}".format(oid, 0))
        for _id, menu in enumerate(data):
            for key, value in menu.items():
                for i ,db_value in enumerate(db_data):
                    if len(db_data) is 1:
                        _oid = "{}.{}.{}".format(oid, _id + 1 , 0)
                    else:
                        _oid = "{}.{}.{}.{}".format(oid, 1, _id + 1 , i + 1)
                    dic[_oid] = (db_value[key], value)
        return dic
    
    def update_from_db(self, table):
        data = self.db_query(table)
        if data:
            ### get oid from oids_ref and arrsign value to the right oid field
            for oid, value in self.oids_ref.items():
                if value == table:
                    dic = self.analysis_db_date(oid, data)
        else:
            ### return empty dict if cannot get data from database 
            ### that can avoid exception occur.
            dic = {}
        return dic 

    def analysis_set_request(self, oid):
        oid_ref, _id = oid.rsplit('.', 1)
        if _id is not '0':
            temp = oid_ref.rsplit('.' , 2)
            oid_ref = "{}.{}".format(temp[0], temp[2])

        _id = 1 if _id is '0' else int(_id)

        name, _type = self.oids_ref.get(oid_ref)
        table = self.oids_ref.get(oid_ref.rsplit('.', 1)[0])
        return table, name, _id, _type

    def setter(self, oid, _type, value):
        oid = self.snmp.cut_oid(oid)

        if oid =='20.1.1.0' and value == '1':
            os.chdir('/opt/mlis/')
            os.system('./save-config.sh')
            os.system('./reboot.sh')
            return True
        elif oid =='20.1.2.0' and value == '1':
            os.chdir('/opt/mlis/')
            os.system('./reboot.sh')
            return True

        table, name, _id, type_idx = self.analysis_set_request(oid)
        if table in READ_ONLY_MENU:
            if name in READ_ONLY_MENU.get(table):
                return False

        if _type != TYPE_DIC[type_idx]:
            return False

        d = dict(method='set', table=table, id=_id, values={name: value})
        result = DB_AGENT.set(d)
        if result['result'] == 'success':
            return True
        return False

    def update(self):
        self.oids.update(self.update_from_db('cellular'))
        db_updated = self.db_query('all', method='check')

        if db_updated['result']:
            for oid, value in self.oids_ref.items():
                if type(value) is unicode:
                    self.oids.update(self.update_from_db(value))


        for oid, value in self.oids.items():
            if value is "":
                pass
            elif value[1] is 0:
                self.snmp.add_int(oid, value[0])
            elif value[1] is 1:
                self.snmp.add_int(oid, value[0])
            elif value[1] is 2:
                self.snmp.add_str(oid, value[0])
            elif value[1] is 3:
                if value[0] == '':
                    self.snmp.add_ip(oid, '0.0.0.0')
                else:
                    self.snmp.add_ip(oid, value[0])

        self.snmp.add_int('20.1.1.0', 0)
        self.snmp.add_int('20.1.2.0', 0)
                
agent = snmpAgent()
agent.start()

