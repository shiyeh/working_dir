#!/usr/bin/python 

import socket
import json
import time

class dbAgent(object):
    def __init__(self):
        pass

    def set(self, data):
        self.sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        self.sock.connect("/tmp/db.sock")
        self.sock.send(json.dumps(data))
        data = self.sock.recv(4096)
        recv = json.loads(data)
        with open('/tmp/temp', 'a') as f:
            f.write('{}\n'.format(recv))
        return recv


    def query(self, method, table):
        self.sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        self.sock.connect("/tmp/db.sock")
        d = dict(method=method, table=table)
        self.sock.send(json.dumps(d))
        data = self.sock.recv(4096)
        data = json.loads(data)
        return data

    def dump(self):
        self.sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        self.sock.connect("/tmp/db.sock")
        d = dict(method='dump')
        self.sock.send(json.dumps(d))
        data = self.sock.recv(10240)
        data = json.loads(data)
        return data


if __name__ == "__main__":
    agent = dbAgent()
    print(agent.query("get", "lan_setting"))
