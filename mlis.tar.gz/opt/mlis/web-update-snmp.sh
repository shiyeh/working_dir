#!/bin/sh

source init-mlb-env.sh

if [ -f "${WEB_APP_DB_PATH}" ]
then
    DB_SNMP_EN=`sqlite3 "${WEB_APP_DB_PATH}" "select active from snmp_agent"`
    echo DB_SNMP_EN = ${DB_SNMP_EN}
    if [ "${DB_SNMP_EN}" = 1 ]
    then
        export DB_SNMP_AC=""
        ref=0
        DB_SNMP_READ_COMMUNITY=`sqlite3 "${WEB_APP_DB_PATH}" "select read_community from snmp_agent"`
        echo DB_SNMP_READ_COMMUNITY = ${DB_SNMP_READ_COMMUNITY}
        DB_SNMP_WRITE_COMMUNITY=`sqlite3 "${WEB_APP_DB_PATH}" "select write_community from snmp_agent"`
        echo DB_SNMP_WRITE_COMMUNITY = ${DB_SNMP_WRITE_COMMUNITY}
        DB_SNMP_AGENT_VER=`sqlite3 "${WEB_APP_DB_PATH}" "select agent_ver from snmp_agent"`
        echo DB_SNMP_AGENT_VER = ${DB_SNMP_AGENT_VER}
        if [ "${DB_SNMP_AGENT_VER}" -gt 1 ]; then let ref+=4 ; else let ref+=0 ; fi

        DB_SNMP_AUTH_PROTO=`sqlite3 "${WEB_APP_DB_PATH}" "select auth_protocol from snmp_agent"`
        if [ "${DB_SNMP_AUTH_PROTO}" -gt 0 ]; then let ref+=2 ; else let ref+=0 ; fi
        case ${DB_SNMP_AUTH_PROTO} in 
            0) DB_SNMP_AUTH_PROTO='';;
            1) DB_SNMP_AUTH_PROTO="MD5";;
            2) DB_SNMP_AUTH_PROTO="SHA";;
        esac
        echo DB_SNMP_AUTH_PROTO = ${DB_SNMP_AUTH_PROTO}
        DB_SNMP_AUTH_KEY=`sqlite3 "${WEB_APP_DB_PATH}" "select auth_key from snmp_agent"`
        echo DB_SNMP_AUTH_KEY = ${DB_SNMP_AUTH_KEY}

        DB_SNMP_PRIV_PROTO=`sqlite3 "${WEB_APP_DB_PATH}" "select priv_protocol from snmp_agent"`
        if [ "${DB_SNMP_PRIV_PROTO}" -gt 0 ]; then let ref+=1 ; else let ref+=0 ; fi
        case ${DB_SNMP_PRIV_PROTO} in 
            0) DB_SNMP_PRIV_PROTO='';;
            1) DB_SNMP_PRIV_PROTO="DES";;
            2) DB_SNMP_PRIV_PROTO="AES";;
        esac
        echo DB_SNMP_PRIV_PROTO = ${DB_SNMP_PRIV_PROTO}
        DB_SNMP_PRIV_KEY=`sqlite3 "${WEB_APP_DB_PATH}" "select priv_key from snmp_agent"`
        echo DB_SNMP_PRIV_KEY = ${DB_SNMP_PRIV_KEY}

        echo ref = ${ref}
        
        if [ ${ref} -ge 4 ]; then DB_SNMP_AC+="createUser ${DB_SNMP_READ_COMMUNITY}" ; fi
        if [ ${ref} -ge 6 ]; then DB_SNMP_AC+=" ${DB_SNMP_AUTH_PROTO} \"${DB_SNMP_AUTH_KEY}\"" ; fi
        if [ ${ref} -ge 7 ]; then DB_SNMP_AC+=" ${DB_SNMP_PRIV_PROTO} \"${DB_SNMP_PRIV_KEY}\"" ; fi

        DB_SNMP_AC+=$'\n'
        DB_SNMP_AC+=$'\n'
        if [ ${DB_SNMP_AGENT_VER} -le 2 ]; 
        then
            DB_SNMP_AC+="#        sec.name  source          community"$'\n'
            DB_SNMP_AC+="com2sec  readonly  default         ${DB_SNMP_READ_COMMUNITY}"$'\n'
            DB_SNMP_AC+="#com2sec readwrite default         private"$'\n'
            DB_SNMP_AC+=$'\n'
        fi
        DB_SNMP_AC+="#             sec.model  sec.name"$'\n'
        DB_SNMP_AC+="group ROGroup v1         readonly"$'\n'
        DB_SNMP_AC+="group ROGroup v2c        readonly"$'\n'
        DB_SNMP_AC+="group ROGroup usm        ${DB_SNMP_READ_COMMUNITY}"$'\n'

        if [ ! -d ${SYS_SNMP_CFG_DIR} ];
        then
            mkdir -p ${SYS_SNMP_CFG_DIR}
        fi
        source gen-snmp-conf.sh
        update-rc.d -f snmpd defaults
    else 
        update-rc.d -f snmpd remove
    fi
fi


