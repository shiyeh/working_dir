#!/bin/sh

source /opt/mlis/init-mlb-env.sh
if [ -d "$MLB_DIR/test" ]
then
    rm -rf "${MLB_DIR}/test"
fi

if [ -f "${MLB_DIR}/gen-ipk-setup.sh" ]
then
    chmod +x "${MLB_DIR}/gen-ipk-setup.sh"
    ${MLB_DIR}/gen-ipk-setup.sh
fi

if [ -f $MLB_INIT_PATH ]
then
    source ${MLB_INIT_PATH}

    fw_name="G420x_"${mlb_ver}.fw
    rm -f ${MLB_INIT_PATH}

    tar -zcvpf mlis.tar.gz ${MLB_DIR}
    md5sum mlis.tar.gz | awk '{ print $1 }' > md5
    tar -zcvpf /tmp/${fw_name} mlis.tar.gz md5
    rm -f mlis.tar.gz md5
    exit 0
fi
echo "init-G420x is not existed."
echo "Please reboot and try again."
exit 1

