#!/bin/sh

sync
sleep 2
reboot
