#!/bin/sh

### Generate /etc/udhcpd.conf file.
cat > "${SYS_DIR}/${MLB_DHCP_CFG}" << EOF
# Begin ${SYS_DIR}/${MLB_DHCP_CFG}
# The start and end of the IP lease block
start       ${DHCPD_IP_RANG_BGN}
end         ${DHCPD_IP_RANG_END}
# The interface that udhcpd will use
interface   ${DHCPD_USED_IF}
# The location of the pid file
pidfile     /var/run/udhcpd.pid

# Static leases map
${DHCP_STATIC_LEASE}

# The remainder of options are DHCP options and can be specified with the
# keyword 'opt' or 'option'. If an option can take multiple items, such
# as the dns option, they can be listed on the same line, or multiple
# lines.
opt         dns     ${DB_DHCP_IP_DNS} ${DB_DHCP_IP_SEC_DNS} #public google dns servers
option      subnet  ${DHCP_IP_SUBMASK}
opt         router  ${IF_ADDR_IP}
option      lease   ${DB_DHCP_IP_CLIENT_TIME} # default: 10 days
# Arbitrary option in hex form:
option      0x08    01020304 # option 8: "cookie server IP addr: 1.2.3.4"

# The location of the leases file                                        
lease_file     /var/lib/misc/udhcpd.leases

# End ${SYS_DIR}/${MLB_DHCP_CFG}
