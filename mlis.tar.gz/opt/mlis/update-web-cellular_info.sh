#!/bin/sh

# set -x
PPP_INFO_PATH=/tmp/ppp_info
# if [ -f "${WEB_STAT_DB_PATH}" ]
if [ -f "/tmp/cellular.db" ]
then
	if [ -f "${PPP_INFO_PATH}" ]
	then
		source "${PPP_INFO_PATH}"
	else
		MLB_PPP_IP=192.168.0.1
	fi
	sqlite3 "/tmp/cellular.db" "update cellular set ip_addr = \"${MLB_PPP_IP}\" where id = 1;"
	# sqlite3 "${WEB_STAT_DB_PATH}" "update cellular set ip_addr = \"${MLB_PPP_IP}\" where id = 1;"
fi
# set +x
