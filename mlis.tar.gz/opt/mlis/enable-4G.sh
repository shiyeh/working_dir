#!/bin/sh

if [ "$#" = 0 ]; then
	echo "Enable 4G module"
	onoff=0
else
	case $1 in
		on | ON | 1 )           
			echo "Enable 4G module"
 			onoff=0
 			;;
 		off | OFF | 0 )
			echo "Disable 4G module"		
 			onoff=1
 			;;
        * )
        	echo "arg must be [on|ON|1] or [off|OFF|0]"
			exit 1
	esac
fi

if [ ! -d /sys/class/gpio/gpio69 ]; then
	echo "Export gpio69 for ON/OFF 4G module"
	echo 69 > /sys/class/gpio/export
	echo out > /sys/class/gpio/gpio69/direction
fi

MDM_3G="/dev/ttyACM0"
MDM_4G="/dev/ttyUSB2"
wcnt=0
echo "${onoff}" > /sys/class/gpio/gpio69/value
if [ ${onoff} = 0 ]
then
	until [ -c ${MDM_3G} ] || [ -c ${MDM_4G} ] || [ ${wcnt} = 20 ]
	do
		sleep 1
		wcnt=$(( wcnt+1 ))
		echo "ON(${wcnt})"
	done
else
	until [ ! -c ${MDM_3G} ] && [ ! -c ${MDM_4G} ] || [ ${wcnt} = 20 ]
	do
		sleep 1
		wcnt=$(( wcnt+1 ))
		echo "OFF(${wcnt})"
	done
fi
echo "done."
