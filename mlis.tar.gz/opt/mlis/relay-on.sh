#!/bin/sh

echo 1 > /sys/class/gpio/gpio26/value
exit 0
