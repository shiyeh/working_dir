#!/bin/sh

source /opt/mlis/init-mlb-env.sh

if [ -f /tmp/*.fw ]
then
    fw_name=`ls /tmp/*.fw`
    tar -xvpf ${fw_name} -C /tmp
    md5_original=`cat /tmp/md5`
    md5_file=`md5sum /tmp/mlis.tar.gz | awk '{ print $1 }'`
    echo ${md5_original}
    echo ${md5_file}
else
    echo "no FW file found."
    rm -f /tmp/*.fw
    exit 1
fi 

# ===================kill process before update FW===========================
kill_list=()
pid_of_ppp_on_boot=`ps | grep {ppp_on_boot} | awk '{ print $1 }' | head -n 1`
kill_list+=(${pid_of_ppp_on_boot})
pid_of_serial_config=`pidof serial-config`
kill_list+=(${pid_of_serial_config})

for pid in ${kill_list[@]}
do
	kill -9 ${pid}
done
#============================================================================


if [ $md5_original != $md5_file ]
then
    rm -f /tmp/*.fw /tmp/md5 /tmp/mlis.tar.gz
    echo "MD5 is not the same."
	exit 1
fi
exit 0
