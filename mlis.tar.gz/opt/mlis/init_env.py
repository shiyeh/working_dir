#!/usr/bin/python
import os
import subprocess

output = subprocess.check_output(
    ['bash', '-c', '. /opt/mlis/init-mlb-env.sh && env'])

for line in output.split('\n'):
    print line
    if not line:
        continue

    try:
        key, value = line.split('=', 1)
    except Exception:
        continue

    if os.environ.get(key) != value:
        os.environ[key] = value
