#!/bin/sh

### Generate /opt/mlis/conf/apt_opt file.
cat > "${MLB_PPP_APN_OPT_PATH}" << EOL
#!/bin/sh
# Begin ${MLB_PPP_APN_OPT_PATH}
export MLBPRISIM="sim${PRISIM}"
export MLBBCKSIM="sim${BCKINGSIM}"

export MLBAPN1=${DB_APN}
export MLBPDPYTPE1=ip
export MLBUSRNAME1=${DB_USR_NAME}
export MLBPASSWORD1=${DB_PASS_WRD}
export MLBAPN2=${DB_2ND_APN}
export MLBPDPYTPE2=ip
export MLBUSRNAME2=${DB_2ND_USR_NAME}
export MLBPASSWORD2=${DB_2ND_PASS_WRD}

# End ${MLB_PPP_APN_OPT_PATH}
####### End to config "/opt/mlis/conf/apt_opt" 
