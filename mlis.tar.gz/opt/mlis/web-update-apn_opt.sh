#!/bin/sh

source /opt/mlis/init-mlb-env.sh

if [ -f "${WEB_APP_DB_PATH}" ]
then
	export DB_APN=`sqlite3 "${WEB_APP_DB_PATH}" 'select apn from wan_setting where id=1'`
	echo "New APN: ${DB_APN}"
	export DB_USR_NAME=`sqlite3 "${WEB_APP_DB_PATH}" 'select username from wan_setting where id=1'`
	if [ -n "${DB_USR_NAME}" ]
	then
		echo "New User Name: ${DB_USR_NAME}"
	else
		echo "no username"
	fi
	export DB_PASS_WRD=`sqlite3 "${WEB_APP_DB_PATH}" 'select password from wan_setting where id=1'`
	if [ -n "${DB_PASS_WRD}" ]
	then
		echo "New Password: ${DB_PASS_WRD}"
	else
		echo "no password"
	fi
	
	source /opt/mlis/gen-apn-conf.sh
	echo "APN=${DB_APN}" > "${MLB_QMI_APN_OPT_PATH}"

	if [ -n "${DB_USR_NAME}" ] && [ -n "${DB_PASS_WRD}" ]
	then
		echo "${DB_USR_NAME}    *    ${DB_PASS_WRD}" > /opt/mlis/conf/pap-secrets
	else
		rm -rf /opt/mlis/conf/pap-secrets
	fi
fi
