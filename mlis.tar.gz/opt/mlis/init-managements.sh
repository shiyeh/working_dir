#!/bin/sh
#PATH=/sbin:/bin:/usr/sbin:/usr/bin:/opt/mlis/db_management

if [ -d "/opt/log" ]
then
	echo "LOG output directory: /opt/log existed."
else
	echo "Created LOG output directory."
	mkdir "/opt/log"
fi

NAME=DB-MGR
DESC=db_management
DAEMON_PID_FILE=/var/run/db-manager.pid
DAEMON_OPTS='start'
DAEMON=/opt/mlis/db_management/db_manager.py
if start-stop-daemon --start --quiet --background \
    --pidfile $DAEMON_PID_FILE --make-pidfile \
    --name $NAME --exec $DAEMON -- $DAEMON_OPTS
then
    echo "MLB DB Manager is running."
fi

if [ ! -f /tmp/dev-manager.pid ]
then
	PATH=/sbin:/bin:/usr/sbin:/usr/bin:/opt/mlis/dev_management
	NAME=DEV-MGR
	DESC=dev_management
	DAEMON_PID_FILE=/var/run/dev-manager.pid
	DAEMON_OPTS='start'
	DAEMON=/opt/mlis/dev_management/manager.py
	if start-stop-daemon --start --quiet --background \
		--pidfile $DAEMON_PID_FILE --make-pidfile \
		--name $NAME --exec $DAEMON -- $DAEMON_OPTS
	then
		echo "MLB DEV Manager is running."
	fi
fi
