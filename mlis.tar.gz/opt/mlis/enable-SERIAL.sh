#!/bin/sh

if [ ! -d /sys/class/gpio/gpio44 ]; then
	echo "Export gpio44 for M2"
	echo 44 > /sys/class/gpio/export
	echo out > /sys/class/gpio/gpio44/direction
fi
if [ ! -d /sys/class/gpio/gpio45 ]; then
	echo "Export gpio65 for M1"
	echo 45 > /sys/class/gpio/export
	echo out > /sys/class/gpio/gpio45/direction
fi
if [ ! -d /sys/class/gpio/gpio46 ]; then
	echo "Export gpio46 for M0"
	echo 46 > /sys/class/gpio/export
	echo out > /sys/class/gpio/gpio46/direction
fi

## READ serial port setting form database. 
## 

if [ ${mode} = 485 ]
then
	if [ ! -d /sys/class/gpio/gpio27 ]; then
		echo "Export gpio27 for DIR"
		echo 27 > /sys/class/gpio/export
		echo out > /sys/class/gpio/gpio27/direction
	fi

	echo 0 > /sys/class/gpio/gpio44/value
	echo 0 > /sys/class/gpio/gpio45/value
	echo 1 > /sys/class/gpio/gpio46/value
	echo "switch to 485, done."
fi
if [ ${mode} = 232 ]
then
	if [ -d /sys/class/gpio/gpio27 ]; then
		echo "Unexport gpio27 on 232 mode"
		echo 27 > /sys/class/gpio/unexport
	fi

	echo 1 > /sys/class/gpio/gpio44/value
	echo 0 > /sys/class/gpio/gpio45/value
	echo 0 > /sys/class/gpio/gpio46/value
	echo "switch to 232, done."
fi
if [ ${mode} = check ]
then
	M2=`cat /sys/class/gpio/gpio44/value`
	M2DIR=`cat /sys/class/gpio/gpio44/direction`

	M1=`cat /sys/class/gpio/gpio45/value`
	M1DIR=`cat /sys/class/gpio/gpio45/direction`

	M0=`cat /sys/class/gpio/gpio46/value`
	M0DIR=`cat /sys/class/gpio/gpio46/direction`

	if [ -d /sys/class/gpio/gpio27 ]
	then
		DIR=`cat /sys/class/gpio/gpio27/value`
		DIRDIR=`cat /sys/class/gpio/gpio27/direction`
	else
		DIR="not exist."
		DIRDIR=""
	fi
	echo "M2: ${M2} ${M2DIR}"
	echo "M1: ${M1} ${M1DIR}"
	echo "M0: ${M0} ${M0DIR}"
	echo "DIR: ${DIR} ${DIRDIR}"
fi
