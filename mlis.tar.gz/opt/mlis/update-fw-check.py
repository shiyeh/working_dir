#!/usr/bin/python
import os
import sys
import logging
import glob
import hashlib
import signal
import init_env
from subprocess import Popen, PIPE

log = logging.getLogger(__name__)


def killProcess():
    try:
        _cmd = "ps | grep {ppp_on_boot} | awk '{print $1}' | head -n 1"
        p1 = Popen([_cmd], shell=True, stdout=PIPE, stderr=PIPE)
        pid1, err = p1.communicate()

        _cmd = 'pidof serial-config'
        p2 = Popen([_cmd], shell=True, stdout=PIPE, stderr=PIPE)
        pid2, err = p2.communicate()
    except Exception as e:
        log.exception(e)
    else:
        for pid in [pid1, pid2]:
            if pid is not '':
                log.info('Kill process: %s', pid)
                os.kill(int(pid), signal.SIGTERM)


def cancelProcess():
    _cmd = 'rm -f /tmp/*.fw /tmp/md5 /tmp/mlis.tar.gz'
    ret = os.system(_cmd)
    if ret == 0:
        log.error('Cancel the processes due to some error.')
        sys.exit(1)


def md5Checksum(filePath):
    with open(filePath, 'rb') as fh:
        m = hashlib.md5()
        while True:
            data = fh.read()
            if not data:
                break
            m.update(data)
        return m.hexdigest()


def main():
    ''' Get the firmware name and path. '''
    try:
        fwPath = glob.glob('/tmp/*.fw')[0]
    except Exception as e:
        log.error('Firmware not found.')
        cancelProcess()

    fwName = os.path.basename(fwPath)
    log.info('Fireware found, version is %s' % fwName)

    ''' Untar the file XXX.fw to /tmp '''
    try:
        p = Popen(['/bin/tar', '-xvpf', fwPath, '-C', '/tmp/'], stdout=PIPE, stderr=PIPE)
        fwFile, err = p.communicate()
        if p.returncode != 0:
            raise Exception(err.strip())
        # log.info('Untar the file: %s' % (fwFile))
    except Exception as e:
        log.error(e)
        cancelProcess()

    srcFile = '/tmp/' + fwFile.split()[0]  # Should be mlis.tar.gz
    md5File = '/tmp/' + fwFile.split()[1]  # Should be md5
    print 'src=', srcFile
    print 'md5=', md5File

    ''' Try to open original md5 file, just cat file. '''
    try:
        with open(md5File, 'rt') as f:
            md5_original = f.read().strip()
    except Exception as e:
        log.exception(e)
    finally:
        f.close()

    ''' Compare these 2 md5 files. '''
    md5_new = md5Checksum(srcFile)
    print 'md5_original=', md5_original
    print 'md5_new=', md5_new
    if md5_original != md5_new:
        log.error('MD5 Compared: FAIL')
        log.error('MD5 original: %s' % (md5_original))
        log.error('MD5 NEW: %s' % (md5_new))
        log.error('Firmware update cancel because the MD5 is not the same.')
        cancelProcess()
    else:
        # Kill process before update FW.
        log.info('MD5 Compared: PASS, continue the procedure.')
        killProcess()


if __name__ == '__main__':
    logging.basicConfig(level=logging.NOTSET, filename='/opt/log/fwUpdate.log',
                        format='%(asctime)s %(levelname)s: %(message)s')
    main()
