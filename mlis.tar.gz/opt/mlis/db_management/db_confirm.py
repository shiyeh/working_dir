#!/usr/bin/env python
#import pdb

class db_confirm(object):
    def __init__(self):
        self.D = { 
                   'lan_setting': self.lanSetting,
                   'dhcp_server': self.dhcpServer,
                   'port_forwarding': self.portForwarding,
                   'com_setting': self.comSetting,
                   'vpn_active': self.vpnActive,
                   'wan_setting': self.wanSetting,
                 }

    def isInIntList(self, target, _list):
        try:
            if not int(target) in _list:
                return False
            return True
        except:
            return False

    def isBool(self, _bool):
        try:
            if not 0 <= int(_bool) <= 1:
                return False
            return True
        except:
            return False

    def isInRange(self, _min, target, _max):
        try:
            if not _min <= int(target) <= _max:
                return False
            return True
        except:
            return False

    def isIP(self, address):
        if address == '':
            return True
        parts = address.split(".")
        if len(parts) != 4:
            return False
        for item in parts:
            if not 0 <= int(item) <= 255:
                return False
        return True

    def isPort(self, port):
        try:
            if port == '':
                return True
            if not 1 <= int(port) <= 65535:
                return False
            return True
        except:
            return False

    def lanSetting(self):
        _bool = True
        for key, value in self.values.items():
            if key is 'dns' and value is '':
                self.values[key] = '8.8.8.8'
            elif key is 'sec_dns' and value is '':
                self.values[key] = '8.8.4.4'
            else:
                _bool = _bool and self.isIP(value)
        return _bool

    def dhcpServer(self):
        _bool = True
        ips = ['start_ip',
               'dns', 
               'gateway',
               'sec_dns',
               'submask']
        for key, value in self.values.items():
            if key is 'dhcp_server':
                _bool = _bool and self.isBool(value)
            elif key is 'client_time':
                _bool = _bool and self.isInRange(120, value, 864000)
            elif key is 'max_users':
                _bool = _bool and self.isInRange(1, value, 99)
            elif key in ips:
                _bool = _bool and self.isIP(value)
        return _bool
       
    def portForwarding(self):
        _bool = True
        ports = ['internal_port',
                 'public_port']
        for key, value in self.values.items():
            if key is 'active':
                _bool = _bool and self.isBool(value)
            elif key in ports:
                _bool = _bool and self.isPort(value)
            elif key is 'ip':
                _bool = _bool and self.isIP(value)
            elif key is 'protocol':
                temp = value is 'tcp' or value is 'udp'
                _bool = _bool and temp
        return _bool
    
    def comSetting(self):
        _bool = True
        baudRates = [ 1200,
                      2400,
                      4800,
                      9600,
                      19200,
                      38400,
                      57600,
                      115200,
                      230400 ]
        paritys = [ 'none', 'odd', 'even' ]
        stopBits = [ 1, 1.5, 2 ]
        transMode= [ 232, 422, 485 ]
        workMode = ['mccp', 'trans']

        for key, value in self.values.items():
            if key is 'baud_rate':
                _bool = _bool and self.isInIntList(value, baudRates)
            elif key is 'data_bits':
                _bool = _bool and self.isInRange(5, value, 8)
            elif key is 'ip_addr':
                _bool = _bool and self.isIP(value)
            elif key is 'parity':
                _bool = _bool and value in paritys
            elif key is 'port':
                _bool = _bool and self.isPort(value)
            elif key is 'stop_bits':
                _bool = _bool and self.isInIntList(value, stopBits)
            elif key is 'trans_mode':
                _bool = _bool and self.isInIntList(value, transMode)
            elif key is 'work_mode':
                _bool = _bool and value in workMode
        return _bool

    def vpnActive(self):
        _bool = True
        for key, value in self.values.items():
            if key is 'active':
                _bool = _bool and self.isBool(value)
        return _bool
    def wanSetting(self):
        auth = ['pap', 'chap']
        _bool = True
        for key, value in self.values.items():
            if key is 'auth':
                _bool = _bool and self.isInIntList(value, auth)
        return _bool

    def confirm(self, payload):
        _bool = True
        self.values = payload.get('values')
        self.table = payload.get('table')
       
        for table, func in self.D.items():
            if self.table == table:
                _bool = func()

        payload['values'] = self.values
        return _bool, payload

if __name__ == '__main__':
    data = {"method": "set",
            "table": "com_setting",
            "id": 1,
            "values":  {
                   'baud_rate': 57600,
                   'data_bits': 7,
                   'parity': u'none',
                   'stop_bits': 1.2,
                   'work_mode': u'mcc'
               }
            }

    db = db_confirm()
    print(db.confirm(data))
    del db

    #pdb.set_trace()
    #print('finish')
    
    
    

