#!/usr/bin/python
import stat
import os
import Queue
import sys
import time
import logging
import datetime
from daemon import Daemon
from modem.device import mdm_dev
from modem.device import atcmd_agent as mdm_atcagent
from modem.parser import atcmd_parser as mdm_parser

from modem.status import status_leds as mdm_status
from modem.status import SystemInfo as mdm_sysinfo
from modem.status import CellularInfo as mdm_cellinfo
from modem.status import LanInfo as mdm_laninfo
from modem.status import LanSettingInfo as dev_laninfo
from modem.status import WanPrioSetting as wan_priocfg

logging.basicConfig(level=logging.NOTSET,
                    filename='/tmp/mdm-manager.log',
                    format='%(asctime)s %(message)s')
log = logging.getLogger(__name__)

MGREVT_CMDREQ = 'ATCMD'
MGREVT_CMDRSP = 'ATRST'
MGREVT_CMDERR = 'ERROR'
MGREVT_TIMEOUT = 'TIMEOUT'
MGREVT_ENTER = 'ENTER'
MGREVT_LEAVE = 'LEAVE'

MS_INIT = 'MS_INIT'
MS_SIMPIN = 'MS_SIMPIN'
MS_NOSIM = 'MS_NOSIM'
MS_SEARCHING = 'MS_SEARC'
MS_CONNTING = 'MS_CONNTING'
MS_INCONN = 'MS_INCONN'
MS_DISCONN = 'MS_DISCONN'
MS_PWROFF = 'MS_PWROFF'
MS_UNKNOWN = 'MS_UNKNOWN'

MDM_ATCMDSTR_LAYER = 'ATCMDSTR_LAYER'
MDM_PLAINTXT_LAYER = 'PLAINTXT_LAYER'


'''
class MdmDualSimSwitcher(object):
    evnttype = ['NOSIM',
                'NONETWORK',
                'DISCONN',
                'CONNTIMOUT',
                'UNKNOWN']

    rslttype = ['KEEPTRY',
                'SWITCHSIM',
                'NOTRY',
                'BLCKING',
                'NOACTIVE']

    """docstring for MdmDualSIM"""
    def __init__(self, arg):
        super(MdmDualSimSwitcher, self).__init__()
        self.arg = arg

        if self.arg is True:
            self._func_enable = True
        else:
            self._func_enable = False

        self.cfg_recycle = 5  # 1 cycle: 2 retry count (SIM1 & SIM2)
        self.cfg_nonwrk_waiting = 1 * 60.0  # seconds
        self.cfg_nocnn_retry = 5  # times

        self.nosim_retry = 0
        self.nonwk_retry = 0
        self.nonwk_datetime = datetime.datetime.now()
        self.nocnn_retry = 0
        self.reconn_cnt = 0

    def evnt_enter(self, inp_evt=''):
        if self._func_enable is False:
            return 'NOACTIVE'
        if inp_evt not in MdmDualSimSwitcher.evnttype:
            return 'NOACTIVE'
'''


class MdmMgrDaemon(Daemon):
    """docstring for manager"""
    def __init__(self, arg=''):
        super(MdmMgrDaemon, self).__init__(pidfile='/tmp/mdm-manager.pid')

        self.arg = arg
        self.currst = ''
        self.mdm_type = ''
        self.mdm_imei = ''
        self.s1_imsi = ''
        self.s2_imsi = ''
        self.agt_port = ''
        self.agt_addr = ''

        # if (len(arg) > 0):
        #     self.mlbdev = mdm_dev(arg)
        # else:
        #     defautl EHS6 2nd ATCMD port.
        #     self.mlbdev = mdm_dev('/dev/ttyACM3')

        # self.mgr_event_q = Queue.Queue()
        # self.pllprd = 2  # wait time in event queue.
        # self.mlbstatus = mdm_status()
        # self.mlbstatus.clean_all()

        # progredd event by state:
        #   STATE:
        #   -INIT
        #   -SIM PIN
        #   -NO SIM
        #   -SEARCHING/ATTACHING/NO NETWORK
        #   -CONNECTING
        #   -CONNECTED
        #   -DISCONNECT
        #   -POWEROFF
        self._MGR_STATE = {
            MS_INIT: self._mgr_init_hndl,
            MS_SIMPIN: self._mgr_simpin_hndl,
            MS_NOSIM: self._mgr_nosim_hndl,
            MS_SEARCHING: self._mgr_srchnw_hndl,
            MS_CONNTING: self._mgr_connting_hndl,
            MS_INCONN: self._mgr_inconn_hndl,
            MS_PWROFF: self._mgr_pwroff_hndl,
            MS_UNKNOWN: self._mgr_unknown
        }

        # event format: [TYPE='', udata=[]]]
        #   TYPE:
        #   1. CMDREQ
        #   2. CMDOK
        #   3. TIMEOUT
        self._MGREVT_LIST = [
            MGREVT_CMDREQ,
            MGREVT_CMDRSP,
            MGREVT_CMDERR,
            MGREVT_TIMEOUT,
            MGREVT_ENTER,
            MGREVT_LEAVE
        ]

        self._MDM_LAYER = {
            MDM_ATCMDSTR_LAYER: self._mgr_atcmdstr_nofify,
            MDM_PLAINTXT_LAYER: self._mgr_plaintxt_nofify
        }
        self.mdm_layer = MDM_ATCMDSTR_LAYER

        # Dev Dual-SIM will be packed into class
        self.cfg_enable = False
        self.cfg_recycle = 5  # 1 cycle: 2 retry count (SIM1 & SIM2)
        self.cfg_nonwrk_waiting = 1 * 60.0  # seconds
        self.cfg_nocnn_retry = 5  # times

        self.nosim_retry = 0
        self.nonwk_retry = 0
        self.nonwk_datetime = datetime.datetime.now()
        self.nocnn_retry = 0
        self.reconn_cnt = 0

    def _mgr_state_trans(self, nxtst='', evttype=MGREVT_ENTER, dataitm=[]):
        if (nxtst in self._MGR_STATE.keys()):
            log.debug('st trans to ' + nxtst)
            self.currst = nxtst

            if evttype != MGREVT_ENTER:
                log.debug('replace evt: ' + evttype)

            self._mgr_send_event(evttype, dataitm)
        else:
            log.error('invalid state of manager.')

    def _mgr_send_event(self, evttype='', dataitm=[]):
        if (evttype in self._MGREVT_LIST):
            event = []
            event.append(evttype)
            event.append(dataitm)
            self.mgr_event_q.put(event, block=True)
        else:
            log.error('not support MGREVT type: ' + evttype)
        return

    def _mgr_notify_cb(self, rslt=[]):
        self._mgr_send_event(MGREVT_CMDRSP, rslt)
        return

    def _mgr_atcag_notify_cb(self, inpstr=''):
        func = self._MDM_LAYER[self.mdm_layer]
        if (callable(func)):
            func(inpstr)

    def _mgr_plaintxt_nofify(self, inpstr=''):
        log.info('_mgr_plaintxt_nofify: ' + inpstr)
        itm = []
        itm.append(inpstr)
        self._mgr_send_event(MGREVT_CMDREQ, itm)

    def _mgr_atcmdstr_nofify(self, inpstr=''):
        STD_ATCMD_SUPRT_LIST = [
            'AT+CGDCONT',
            'AT+CPIN',
            'AT+CREG',
            'AT+CMGW',
            'AT+CMGF',
            'AT+CMGS',
            'AT+CMGC',
            'AT+CSQ',
            # 'AT+CSCA',  #SMS Service Center Address
            # 'AT+CMSS',  # Send message from storage,
            # 'AT+CMMS',  # More messages to send
            'AT+CMGD',    # Delete message
            # 'AT+CNMI',  # New message indications
            'AT+CMGL',    # List messages
            'AT+CMGR',    # Read messages
            # 'AT+CNMA',  # New message acknowledgement
            'AT!PCTEMP',  # Sierra Wireless TEMP monitor
            'AT^SCTM',    # Gemalto TEMP monitor
        ]

        log.info('atcag notify inpstr: ' + inpstr)
        if ('AT' in inpstr):
            found = False
            for str in STD_ATCMD_SUPRT_LIST:
                if str in inpstr:
                    found = True
                    itm = []
                    itm.append(inpstr)
                    self._mgr_send_event(MGREVT_CMDREQ, itm)
                    break

            if not found:
                # only for AT
                if 'AT' == inpstr:
                    itm = []
                    itm.append(inpstr)
                    self._mgr_send_event(MGREVT_CMDREQ, itm)
                else:
                    log.info('_mgr_atcmdstr_nofify drop: ' + inpstr)
        else:
            pass

    def _mgr_plain_text(self, inptxt='', rspparse=False):
        if inptxt == '':
            pass
        else:
            log.info('send _mgr_plain_text: ')
            log.info(inptxt)
            self.mlbdev.send_atcmd(inptxt)
            time.sleep(0.5)  # maybe only for EHS6

            tm = 0
            for x in xrange(1, 20):
                rspitm = self.mlbdev.recv_cmdrsp(timeout=tm)
                log.info('mdm raw output:')
                log.info(rspitm)

                # 1st target, example ['> '],
                if ('OK' in rspitm) or ('ERROR' in rspitm):
                    # exit plain text mode
                    self.mdm_layer = MDM_ATCMDSTR_LAYER
                    break
                # no 'OK', seek '>' prompt
                # 2nd time, ['+CMGS: 34', 'OK']
                elif '> ' in rspitm:
                    # keep in plain text mode
                    self.mdm_layer = MDM_PLAINTXT_LAYER
                    # time.sleep(0.1)
                    tm = 0.1
                else:
                    if (rspitm == ['']) or (rspitm == []):
                        log.error('_mgr_plain_text: empty, waiting 0.5s')
                    else:
                        log.error('_mgr_plain_text: except: ')
                        log.error(rspitm)
                    tm = 0.5
                    # might be 'ERROR' or something, no idea.
                    # so exit plain text mode.
                    # self.mdm_layer = MDM_ATCMDSTR_LAYER
            return rspitm

    def _mgr_at_command(self, cmdstr='', rspparse=True):
        if (cmdstr == ''):
            return ''

        # Send ATCMD to device require queue.
        cmdstr = cmdstr.strip('\r\n')
        log.info('send _mgr_at_command: ' + cmdstr)
        self.mlbdev.send_atcmd(cmdstr)

        # Receive ATCMD result from device response queue.
        recv_fullrslt_itm = self.mlbdev.recv_cmdrsp(block=True, timeout=None)
        log.info('cmp cmd: ' + cmdstr + ' mdm raw rsp:')
        log.info(recv_fullrslt_itm)

        # Check current command in this response.
        if (cmdstr in recv_fullrslt_itm):
            # Cut response to sub itme that start from current command.
            subitm = recv_fullrslt_itm[recv_fullrslt_itm.index(cmdstr) + 1:]
        else:
            return ['ERROR']

        if rspparse:
            # Parse ATCMD result
            mlbcmd = mdm_parser()
            rslt = []
            rslt = mlbcmd.exec_handle(subitm)
            log.info('mlbcmd exec:')
            log.info(rslt)
            return rslt
        else:
            return subitm

    def _mgrutil_stop_ppp_dialup(self, reqstr=''):
        fhandle = open('/tmp/ppp-stop', 'w')
        fhandle.write(reqstr)
        fhandle.close()

    def _mgrutil_check_ppp_status(self):
        # check /tmp/ppp_info content:
        # 192.168.0.1 -- stop ppp not to connect.
        # 0.0.0.0 -- pppd connecting operator
        # <pulic IP> -- pppd connected with operator
        info = []
        ipstr = ''
        try:
            fd = open('/tmp/ppp_info', 'r')
        # except Exception, OSError:
        #     log.error('[OSError] not found ppp_info')
        #    return 'CONNECTING'
        # except Exception, IOError:
        except:
            log.error('[Error] not found ppp_info')
            return 'CONNECTING'

        info = fd.readlines()
        fd.close()
        info = info[0].split('=')
        ipstr = info[1].strip()

        # arg: ['WANSTATE', 'CONNECTING'|'CONNECTED'|'NOCONNECT']
        self.mlbcellinfo.set_ip_addr(ipstr)
        self.mlbcellinfo.update_db()
        if ipstr == '192.168.0.1':
            return 'NOCONNECT'
        elif ipstr == '0.0.0.0':
            return 'CONNECTING'
        else:
            return 'CONNECTED'

    def _mgrutil_classify_sigquality(self, rssi=99):
        """
        arg: ['CELLSIG', 'NOSIG'|'POOR'|'NORMAL'|'GOOD']

        Singal LED 1+2+3 (GOOD):    21 < RSSI <= 31,
        Signal LED 2+3 (NORMAL):    12 < RSSI <= 21,
        Signal LED 3 (POOR):        0 < RSSI <= 12,
        """
        self.mlbcellinfo.set_rssi(rssi)
        self.mlbcellinfo.update_db()

        if rssi > 0 and rssi <= 12:
            return 'POOR'
        elif rssi > 12 and rssi <= 21:
            return 'NORMAL'
        elif rssi > 21 and rssi <= 31:
            return 'GOOD'
        else:
            return 'NOSIG'

    def _mgrutil_update_netwktype(self, mode=''):
        nw_type = ''
        nw_mode = ''

        if mode == '2':  # UTRAN
            nw_type = '3G'
            nw_mode = 'UTRAN'
        elif mode == '3':  # EGPRS
            nw_type = '2G'
            nw_mode = 'EGPRS'
        elif mode == '4':  # HSDPA
            nw_type = '3G'
            nw_mode = 'HSDPA'
        elif mode == '5':  # HSUPA
            nw_type = '3G'
            nw_mode = 'HSUPA'
        elif mode == '6':  # HSUPA & HSDPA
            nw_type = '3G'
            nw_mode = 'HSUPA and HSDPA'
        elif mode == '0':  # GSM
            nw_type = '2G'
            nw_mode = 'GSM'
        elif mode == '7':  # E-UTRAN
            nw_type = '4G'
            nw_mode = 'E-UTRAN'
        else:
            nw_type = 'NO SERVICE'
            nw_mode = ''
            # Not register in any network.
            # arg: ['CELLSIG', 'NOSIG'|'POOR'|'NORMAL'|'GOOD']
            log.error('not registed, cause: ' + mode)

        self.mlbstatus.update_status(['CELLTYPE', nw_type])
        self.mlbcellinfo.set_network_type(nw_type + '-' + nw_mode)

    def _mgrutil_update_temperature(self, mode=''):
        mdmtype = self.mlbstatus.get_modem_type()
        if mdmtype == 'EHS6':
            qrycmd = 'AT^SCTM?'
        elif mdmtype == 'MC7304':
            qrycmd = 'AT!PCTEMP?'
        else:
            return
        self._mgr_at_command(qrycmd, rspparse=False)
        return

    def _mgr_init_hndl(self, evtitm=[]):
        evttype = evtitm[0]
        usrdata = evtitm[1]
        if (evttype == MGREVT_ENTER):
            self.mlbdev.cmdprc_start()
            log.debug('*in mgr_init_hndl')
            log.debug(usrdata)

            simstr = self.mlbdev.get_sim_slot_idx()
            self.mlbcellinfo.set_act_sim(simstr)
            self.mlbcellinfo.update_db()
            log.debug('Currently use ' + simstr)
            simstr = simstr + 'LOCK'
            self.mlbstatus.update_status(['SIMSTATE', simstr])
            self.mlbstatus.update_status(['CELLSIG', 'NOSIG'])
            self.mlbstatus.update_status(['WANSTATE', 'NOCONNECT'])

            self.nonwk_datetime = datetime.datetime.now()
            self.reconn_cnt = 0

        elif (evttype == MGREVT_TIMEOUT):
            self._mgr_at_command('ATE1')
            rslt = self._mgr_at_command('AT')

            if len(rslt) == 0:
                log.error('NO OK')
                return

            if 'OK' in rslt:
                # Get 3G/4G module type/model
                rslt = self._mgr_at_command('AT+CGMM')
                if len(rslt) == 0:
                    log.error('NO CGMM')
                    return
                else:
                    self.mdm_type = rslt[1]
                    log.error('MODEM TYPE: ' + self.mdm_type)
                    self.mlbstatus.set_modem_type(self.mdm_type)

                # Get IMEI
                rslt = self._mgr_at_command('AT+CGSN', rspparse=False)
                if len(rslt) == 0:
                    log.error('NO CGSN')
                    return
                else:
                    self.mdm_imei = rslt[0]
                    log.error('IMEI: ' + self.mdm_imei)
                    self.mlbsysinfo.set_imei(self.mdm_imei)

                # get modem temperature
                self._mgrutil_update_temperature()

                # HW modem ready to be used. moving on next state.
                self._mgr_state_trans(MS_SIMPIN)
            else:
                log.error('non OK response for AT, waiting for next try.')
                log.error(rslt)

    def _mgr_simpin_hndl(self, evtitm=[]):
        evttype = evtitm[0]
        usrdata = evtitm[1]
        if (evttype == MGREVT_ENTER):
            log.debug('*in mgr_simpin_hndl')
            log.debug(usrdata)

            if self._mgrutil_check_ppp_status() == 'CONNECTED':
                log.error('connected, not to stop ppp.')
            else:
                self._mgrutil_stop_ppp_dialup()

        elif (evttype == MGREVT_TIMEOUT):
            rslt = self._mgr_at_command('AT+CPIN?')
            if len(rslt) == 0:
                log.error('NO CPIN data')
                return

            simst_mapping = {
                'READY': 'READY',
                'PIN1': 'LOCK',
                'PIN2': 'LOCK',
                'PUK1': 'LOCK',
                'PUK2': 'LOCK',
            }
            simstr = self.mlbdev.get_sim_slot_idx()
            if 'OK' == rslt[0]:
                ststr = ""
                ststr = simstr + simst_mapping[rslt[1]]

                # should check sim solt before.
                # arg: ['SIMSTATE', 'SIM1READY'|'SIM2READY'|'SIM1LOCK'|'SIM2LOCK'|'NOSIM']
                self.mlbstatus.update_status(['SIMSTATE', ststr])
                if 'SIM1LOCK' == ststr:
                    log.error('should get pin code from db?')
                    log.error('and then send out AT+CPIN=<PIN1>')

                    log.debug('at log: ')
                    log.debug(rslt)
                    log.debug('[END]')
                else:
                    # should check sim solt before.
                    # arg: ['SIMSTATE', 'SIM1READY'|'SIM2READY'|'SIM1LOCK'|'SIM2LOCK'|'NOSIM']
                    # self.mlbstatus.update_status(['SIMSTATE', 'SIM1READY'])
                    self._mgr_state_trans(MS_SEARCHING)
            elif 'ERROR':
                    log.error('ERROR: ')
                    log.error(rslt)
                    log.error('[END]')

                    # should check sim solt before.
                    # arg: ['SIMSTATE', 'SIM1READY'|'SIM2READY'|'SIM1LOCK'|'SIM2LOCK'|'NOSIM']
                    self.mlbstatus.update_status(['SIMSTATE', 'NOSIM'])
                    self._mgr_state_trans(MS_NOSIM)
            else:
                log.error('unknown rslt:')
                log.error(rslt)
                log.error('[END]')
                # arg: ['SIMSTATE', 'SIM1READY'|'SIM2READY'|'SIM1LOCK'|'SIM2LOCK'|'NOSIM']
                self.mlbstatus.update_status(['SIMSTATE', 'NOSIM'])
                self._mgr_state_trans(MS_UNKNOWN)

    def _mgr_nosim_hndl(self, evtitm=[]):
        evttype = evtitm[0]
        usrdata = evtitm[1]
        if (evttype == MGREVT_ENTER):
            log.debug('*in mgr_nosim_hndl')
            log.debug(usrdata)
            self.mlbstatus.update_status(['SIMSTATE', 'NOSIM'])
            log.debug('nosim retry cnt: ' + str(self.nosim_retry))
            self.pllprd = 50

        elif (evttype == MGREVT_TIMEOUT):
            if self.cfg_enable is False:
                log.error('Please switch slot manually or check SIM.')
                self.mlbstatus.update_status(['SIMSTATE', 'NOSIM'])

            elif self.nosim_retry <= (self.cfg_recycle * 2):
                self.mlbdev.cmdprc_stop()
                log.error('Switch SIM slot here, and then Reset HW Modem.')
                self.nosim_retry += 1
                self._mgrutil_stop_ppp_dialup('MDMMGR-SIMSWITCH-REQ')
                while os.path.isfile('/tmp/ppp-stop'):
                    time.sleep(1.0)

                self._mgr_state_trans(MS_INIT)
            else:
                log.error('Reached no-sim retry counting limited')
                self.pllprd = 600
                self._mgr_state_trans(MS_UNKNOWN)

    def _mgr_srchnw_hndl(self, evtitm=[]):
        evttype = evtitm[0]
        usrdata = evtitm[1]
        if (evttype == MGREVT_ENTER):
            log.debug('*in mgr_srchnw_hndl')
            log.debug(usrdata)
            self.pllprd = 10  # short period to check modem networking.
            self.nonwk_datetime = datetime.datetime.now()

        elif (evttype == MGREVT_TIMEOUT):
            rslt = self._mgr_at_command('AT+CIMI', rspparse=False)
            if len(rslt) == 0:
                log.error('NO IMSI data')
                return

            self.s1_imsi = rslt[0]
            log.error('SIM1 IMSI: ' + self.s1_imsi)
            self.mlbsysinfo.set_imsi(self.s1_imsi)

            rslt = self._mgr_at_command('AT+CREG?')
            log.error(rslt)
            if len(rslt) == 0:
                log.error('NO CREG data')
                return

            if 'OK' == rslt[0]:
                paras = rslt[1]
                # 0, disable network registration unsolicited result code
                if paras[0] == 0:
                    if paras[1] == '1' or paras == '5':
                        # registed network.
                        self._mgr_state_trans(MS_CONNTING)
                        self._mgr_at_command('AT+CREG=2')
                        self.nonwk_datetime = datetime.datetime.now()

                    else:
                        # Not register in any network.
                        # arg: ['CELLSIG', 'NOSIG'|'POOR'|'NORMAL'|'GOOD']
                        log.error('not registed, cause: ' + paras[1])
                        self.mlbstatus.update_status(['CELLSIG', 'NOSIG'])
                        self.mlbcellinfo.set_network_type('NO SERVICE')

                        if self.cfg_enable is False:
                            log.error('No Network, keep searching.')

                        elif self.nonwk_retry > (self.cfg_recycle * 2):
                            self._mgr_state_trans(MS_UNKNOWN)
                        else:
                            srch_sec = (datetime.datetime.now() -
                                        self.nonwk_datetime).total_seconds()
                            # ToDo: 300 sec, have to read from database
                            if srch_sec > self.cfg_nonwrk_waiting:
                                self.mlbdev.cmdprc_stop()
                                self.nonwk_retry += 1
                                self._mgrutil_stop_ppp_dialup('MDMMGR-SIMSWITCH-REQ')
                                while os.path.isfile('/tmp/ppp-stop'):
                                    time.sleep(1.0)
                                self._mgr_state_trans(MS_INIT)
                            else:
                                log.error('searching for ' + str(srch_sec) + ' seconds')

                # TODO:
                # 1, enable network registration unsolicited result code
                #    CREG:stat
                # 2, enable network registration and location information
                #    CREG:stat[,[lac],[ci],[AcT]
                elif paras[0] == 2:
                    # <stat>: 1 registered, home network
                    #         5 registered, roaming
                    if paras[1] == '1' or paras[1] == '5':
                        # example [2, '1', '"FFFE"', '"01968484"', '7']
                        self._mgrutil_update_netwktype(paras[4])
                        # self._mgrutil_update_netwktype(paras[1])
                        self._mgr_state_trans(MS_CONNTING)
                    # 0 not registered, MT is not currently searching a new
                    #   operator to register to
                    # 2 not registered, but MT is currently searching a new
                    #   operator to register to
                    # 3 registration denied
                    # 4 unknown (e.g. out of GERAN/UTRAN/E-UTRAN coverage)
                    # 6 ~ 10, current not to care.
                    else:
                        # Not register in any network.
                        # arg: ['CELLSIG', 'NOSIG'|'POOR'|'NORMAL'|'GOOD']
                        log.error(paras)
                        log.error('not registed, cause: ' + paras[1])
                        self.mlbstatus.update_status(['CELLSIG', 'NOSIG'])
                        self.mlbcellinfo.set_network_type('NO SERVICE')

                        if self.cfg_enable is False:
                            log.error('No Network, keep searching.')

                        elif self.nonwk_retry > (self.cfg_recycle * 2):
                            self._mgr_state_trans(MS_UNKNOWN)
                        else:
                            srch_sec = (datetime.datetime.now() -
                                        self.nonwk_datetime).total_seconds()
                            # ToDo: 300 sec, have to read from database
                            if srch_sec > self.cfg_nonwrk_waiting:
                                self.mlbdev.cmdprc_stop()
                                self.nonwk_retry += 1
                                self._mgrutil_stop_ppp_dialup('MDMMGR-SIMSWITCH-REQ')
                                while os.path.isfile('/tmp/ppp-stop'):
                                    time.sleep(1.0)
                                self._mgr_state_trans(MS_INIT)
                            else:
                                log.error('searching for ' + str(srch_sec) + ' seconds')
                # TODO:
                # 3, enable network registration, location information and
                #    cause value information unsolicited result code
                #    +CREG:<stat>[,[<lac>],[<ci>],[<AcT>][,<cause_type>,<reject_cause>]]
                else:
                    log.debug('+CREG: ')
                    log.debug(paras)
                    log.debug('[END]')

            elif 'ERROR' == rslt[0]:
                log.debug('ERROR:')
                log.debug(rslt)
                log.debug('[END]')

                self.mlbstatus.update_status(['CELLSIG', 'NOSIG'])
                self.mlbcellinfo.set_network_type('NO SERVICE')
            else:
                log.error('unknown rslt:')
                log.error(rslt)
                log.error('[END]')

                self.mlbstatus.update_status(['CELLSIG', 'NOSIG'])
                self.mlbcellinfo.set_network_type('NO SERVICE')
                self._mgr_state_trans(MS_UNKNOWN)

            self.mlbcellinfo.update_db()

            # get modem temperature
            self._mgrutil_update_temperature()

    def _mgr_connting_hndl(self, evtitm=[]):
        evttype = evtitm[0]
        usrdata = evtitm[1]

        if (evttype == MGREVT_ENTER):
            log.debug('*in mgr_connting_hndl')
            log.debug(usrdata)

            self.pllprd = 50  # reset to default
            try:
                os.remove('/tmp/ppp-stop')
            # except Exception, OSError:
            #    log.error('[OSError] remove ppp-stop failed.')
            #    return
            # except Exception, IOError:
            except:
                log.error('[Error] remove ppp-stop failed.')
                return

        elif (evttype == MGREVT_TIMEOUT):
            rslt = self._mgr_at_command('AT+CSQ')
            if len(rslt) == 0:
                log.error('NO CSQ data')
                return

            if 'OK' == rslt[0]:
                paras = rslt[1]
                rank = ''
                # arg: ['CELLSIG', 'NOSIG'|'POOR'|'NORMAL'|'GOOD']
                rank = self._mgrutil_classify_sigquality(int(paras[0]))
                self.mlbstatus.update_status(['CELLSIG', rank])

                if rank != 'NOSIG':
                    status = ''
                    status = self._mgrutil_check_ppp_status()
                    self.mlbstatus.update_status(['WANSTATE', status])
                    if status == 'CONNECTED':
                        self._mgr_state_trans(MS_INCONN)
                    self._mgr_at_command('AT+COPS=0')

            elif 'ERROR' == rslt[0]:
                log.error('ERROR: ')
                log.error(rslt)
                log.error('[END]')
                self.mlbstatus.update_status(['CELLSIG', 'NOSIG'])
                self.mlbcellinfo.set_network_type('NO SERVICE')

            else:
                log.error('unknown rslt:')
                log.error(rslt)
                log.error('[END]')

                self.mlbstatus.update_status(['CELLSIG', 'NOSIG'])
                self.mlbcellinfo.set_network_type('NO SERVICE')
                self._mgr_state_trans(MS_UNKNOWN)

            # get modem temperature
            self._mgrutil_update_temperature()

    def _mgr_inconn_hndl(self, evtitm=[]):
        evttype = evtitm[0]
        usrdata = evtitm[1]
        if (evttype == MGREVT_ENTER):
            log.debug('*in mgr_inconn_hndl')
            log.debug(usrdata)

            self.pllprd = 300  # long period to repeat query modem.
            self.reconn_cnt += 1

        elif (evttype == MGREVT_TIMEOUT):
            rslt = self._mgr_at_command('AT+CSQ')
            if len(rslt) == 0:
                log.error('NO CSQ data')
                return

            if 'OK' == rslt[0]:
                paras = rslt[1]
                rank = ''
                rank = self._mgrutil_classify_sigquality(int(paras[0]))
                self.mlbstatus.update_status(['CELLSIG', rank])

                if rank != 'NOSIG':
                    status = ''
                    status = self._mgrutil_check_ppp_status()
                    self.mlbstatus.update_status(['WANSTATE', status])
                    if status == 'CONNECTING':
                        self._mgr_state_trans(MS_CONNTING)
                        return
                else:
                    self._mgr_state_trans(MS_SEARCHING)
                    return

            rslt = self._mgr_at_command('AT+CREG?')
            if len(rslt) == 0:
                log.error('NO CREG data')
                return

            if 'OK' == rslt[0]:
                paras = rslt[1]
                if (paras[0] == 0) or (paras[0] == 1):
                    if paras[1] == '1' or paras[1] == '5':
                        # registed network.
                        pass
                    else:
                        # Not register in any network.
                        # arg: ['CELLSIG', 'NOSIG'|'POOR'|'NORMAL'|'GOOD']
                        log.error('not registed, cause: ' + paras[1])
                        self._mgrutil_update_netwktype()
                        self._mgr_state_trans(MS_SEARCHING)

                elif paras[0] == 2:
                    if paras[1] == '1' or paras[1] == '5':
                        if len(paras) == 5:
                            # example [2, '1', '"FFFE"', '"01968484"', '7']
                            self._mgrutil_update_netwktype(paras[4])
                        else:
                            log.error(paras)
                    else:
                        # Not register in any network.
                        # arg: ['CELLSIG', 'NOSIG'|'POOR'|'NORMAL'|'GOOD']
                        log.error(paras)
                        log.error('not registed, cause: ' + paras[1])
                        self.mlbstatus.update_status(['CELLSIG', 'NOSIG'])
                        self.mlbcellinfo.set_network_type('NO SERVICE')
                        self._mgr_state_trans(MS_SEARCHING)
                        return
            else:
                log.error('Unknown err: ' + str(rslt))
                self._mgr_state_trans(MS_UNKNOWN)

            # check valid WAN IP.
            status = self._mgrutil_check_ppp_status()
            self.mlbstatus.update_status(['WANSTATE', status])
            if status == 'CONNECTED':
                self.pllprd = 300

            else:  # status is  'CONNECTING' or 'NOCONNECT'
                if self.cfg_enable is False:
                    log.error('No PDP connection, keep conn.')

                elif self.nocnn_retry > (self.cfg_recycle * 2):
                    self._mgr_state_trans(MS_UNKNOWN)
                else:
                    if self.reconn_cnt > self.cfg_nocnn_retry:
                        # switch SIM to retry.
                        self.mlbdev.cmdprc_stop()
                        self.nocnn_retry += 1
                        self._mgrutil_stop_ppp_dialup('MDMMGR-SIMSWITCH-REQ')
                        while os.path.isfile('/tmp/ppp-stop'):
                            time.sleep(1.0)
                        self._mgr_state_trans(MS_INIT)
                    else:
                        self._mgr_state_trans(MS_CONNTING)

            # get modem temperature
            self._mgrutil_update_temperature()

    def _mgr_pwroff_hndl(self, evtitm=[]):
        evttype = evtitm[0]
        usrdata = evtitm[1]
        if (evttype == MGREVT_ENTER):
            log.debug('*in mgr_pwroff_hndl')
            log.debug(usrdata)

        elif (evttype == MGREVT_TIMEOUT):
            log.debug('trans to ' + MS_INIT)
            self._mgr_state_trans(MS_INIT)

    def _mgr_unknown(self, evtitm=[]):
        evttype = evtitm[0]
        usrdata = evtitm[1]
        if (evttype == MGREVT_ENTER):
            log.error('*in mgr_unknown')
            log.error(usrdata)
            self._mgrutil_stop_ppp_dialup('')

    def running_plaintxt_layer(self):
        self.mdm_layer = MDM_PLAINTXT_LAYER

        while self.mdm_layer == MDM_PLAINTXT_LAYER:
            try:
                # in SMS input mode, BLOCK resource HERE, waiting for 5Sec..
                evtitm = self.mgr_event_q.get(block=True, timeout=5)
            except Exception, Queue.Empty:
                rspitm = self._mgr_plain_text('\x1b', rspparse=False)
                log.error('">" end rsp:')
                log.error(rspitm)

                self.mdm_layer = MDM_ATCMDSTR_LAYER
                rply_str = ' '.join(rspitm)
                self.atc_agent.reply_message(rply_str)

            else:
                log.info('running_plaintxt_layer(evtitm)')
                log.info(evtitm)

                dataitm = evtitm[1]
                rply_str = '{0}'.format(dataitm[0])

                log.info(rply_str)
                rspitm = self._mgr_plain_text(rply_str, rspparse=False)

                log.info('running_plaintxt_layer(rspitm)')
                log.info(rspitm)

                rply_str = ' '.join(rspitm)
                self.atc_agent.reply_message(rply_str)

    def running_core_proc(self):
        self._mgr_state_trans(MS_INIT)
        toutcnt = 0
        while True:
            # get event from queue
            evtitm = []
            try:
                evtitm = self.mgr_event_q.get(block=False)
            except Exception, Queue.Empty:
                # post TIMEOUT event into event queue for next wakeup.
                # print 'TIMEOUT to current state: ' + self.currst
                if toutcnt == self.pllprd:
                    self._mgr_send_event(MGREVT_TIMEOUT)
                    self.mlbsysinfo.update_db()
                    toutcnt = 0
                else:
                    recv_itm = self.mlbdev.recv_cmdrsp(block=True, timeout=0.1)
                    if recv_itm:
                        log.error('Got new URC message')
                        log.error(recv_itm)

                    # time.sleep(0.1)
                    toutcnt = toutcnt + 1
            else:
                if MGREVT_CMDREQ in evtitm:
                    # disable URC
                    # self._mgr_at_command('AT+CREG=0', rspparse=False)

                    dataitm = evtitm[1]
                    atcmd_str = '{0}'.format(dataitm[0])
                    log.info(atcmd_str)

                    # very tricky
                    if 'AT+CMGS=' in atcmd_str:
                        self.mdm_layer = MDM_PLAINTXT_LAYER
                        self.atc_agent.reply_message('> ')

                    rspitm = self._mgr_at_command(atcmd_str, rspparse=False)
                    log.info('ATCAG RSP:')
                    log.info(rspitm)

                    rply_str = '\r\n'.join(rspitm)
                    if '>' in rply_str:
                        # start jump into plain text mode.
                        self.mdm_layer = MDM_PLAINTXT_LAYER
                        # will blocking here until exiting plain text mode.
                        self.running_plaintxt_layer()
                    else:
                        # return Modem full response string to socket.rply_str
                        # self.atc_agent.reply_message('ERROR')
                        self.mdm_layer = MDM_ATCMDSTR_LAYER
                        self.atc_agent.reply_message(rply_str)

                else:
                    # enable URC
                    # self._mgr_at_command('AT+CREG=2', rspparse=False)

                    toutcnt = 0
                    func = self._MGR_STATE[self.currst]
                    if (callable(func)):
                        func(evtitm)
                    else:
                        log.debug('*err mgr state: ' + self.currst)

    def run(self):
        log.debug("MdmMgrDaemon run(), sleep 20sec.")
        time.sleep(20)
        if (len(self.arg) > 0):
            self.mlbdev = mdm_dev(self.arg)
        else:
            # defautl EHS6 2nd ATCMD port.
            self.mlbdev = mdm_dev('/dev/ttyACM3')

        self.mgr_event_q = Queue.Queue()
        self.pllprd = 20  # wait time in event queue.
        self.mlbstatus = mdm_status()
        self.mlbstatus.clean_all()

        while not os.path.exists('/tmp/cellular.db'):
            time.sleep(1)
            log.debug("waiting for /tmp/cellular.db")

        self.mlbsysinfo = mdm_sysinfo('/opt/mlis/web_console/app/status.db')
        # self.mlbcellinfo = mdm_cellinfo('/opt/mlis/web_console/app/status.db')
        self.mlbcellinfo = mdm_cellinfo('/tmp/cellular.db')
        self.mlblaninfo = mdm_laninfo('/opt/mlis/web_console/app/status.db')
        self.devlaninfo = dev_laninfo('/tmp/app.db')
        self.mlbwanprio = wan_priocfg('/tmp/app.db')

        self.nosim_retry = self.mlbwanprio.get_total_recycle_cnt()
        self.nonwk_retry = self.mlbwanprio.get_total_recycle_cnt()
        self.nocnn_retry = self.mlbwanprio.get_diconnect_limited_cnt()

        self.cfg_enable =\
            self.mlbwanprio.get_redundant_enable()
        # 1 cycle: 2 retry count (SIM1 & SIM2)
        self.cfg_recycle =\
            self.mlbwanprio.get_total_recycle_cnt()
        self.cfg_nonwrk_waiting =\
            self.mlbwanprio.get_regist_network_timeout() * 60.0  # seconds
        self.cfg_nocnn_retry =\
            self.mlbwanprio.get_diconnect_limited_cnt()  # times

        if self.mlblaninfo.get_ip_addr() == 'N/A':
            self.agt_addr = self.devlaninfo.get_ip_addr()  # '10.0.10.1'
        else:
            self.agt_addr = self.mlblaninfo.get_ip_addr()  # '10.0.10.1'

        self.agt_port = '10001'

        self.atc_agent = mdm_atcagent(self._mgr_atcag_notify_cb)
        self.atc_agent.open(self.agt_addr, self.agt_port)

        self.running_core_proc()


if __name__ == "__main__":

    logging.basicConfig(level=logging.NOTSET, filename='/tmp/mdm-manager.log')
    devpath = '/dev/ttyUSB2'
    try:
        stat.S_ISCHR(os.stat(devpath).st_mode)
    except Exception, OSError:
        devpath = '/dev/ttyACM3'
        try:
            stat.S_ISCHR(os.stat(devpath).st_mode)
        except Exception, OSError:
            log.error('not found any modem/module on device.')
            sys.exit(2)

    # daemon = MdmMgrDaemon(arg=devpath)
    # development version, need more log to debug.
    daemon = MdmMgrDaemon(arg=devpath)

    if len(sys.argv) == 2:
        if 'start' == sys.argv[1]:
            daemon.start()
        elif 'debug' == sys.argv[1]:
            daemon.start(daemon=False)
        elif 'stop' == sys.argv[1]:
            daemon.stop()
        elif 'restart' == sys.argv[1]:
            daemon.restart()
        else:
            print "Unknown command"
            log.error('Unknown command: ' + sys.argv[1])
            sys.exit(2)

        sys.exit(0)
    else:
        print "usage: %s start|stop|restart" % sys.argv[0]
        sys.exit(2)
