#!/usr/bin/python
import os
import sys
import time

sys.path.insert(0, os.path.abspath('..'))

from modem.status import SystemInfo
from modem.status import CellularInfo
from modem.status import LanSettingInfo
from modem.status import LanInfo
import modem.config as config

if __name__ == "__main__":
    sysinfo = SystemInfo('/opt/mlis/web_console/app/status.db')
    cellinfo = CellularInfo('/opt/mlis/web_console/app/status.db')
    laninfo = LanInfo('/opt/mlis/web_console/app/status.db')
    lansetting = LanSettingInfo('/tmp/app.db')

    print cellinfo.get_ip_addr()
    print cellinfo.get_rssi()
    print cellinfo.get_network_type()
    print cellinfo.get_imei()
    print cellinfo.get_imsi()

    cellinfo.set_ip_addr('111.222.333.444')
    cellinfo.set_rssi('30')
    cellinfo.set_network_type('LTE')
    cellinfo.set_imei('abcdefghijklmnopq')
    cellinfo.set_imsi('rstuvwxyz01234567')
    cellinfo.update_db()

    print cellinfo.get_ip_addr()
    print cellinfo.get_rssi()
    print cellinfo.get_network_type()
    print cellinfo.get_imei()
    print cellinfo.get_imsi()

    print lansetting.get_ip_addr()
    print lansetting.get_ip_submask()
    print lansetting.get_dns()
    print lansetting.get_2nd_dns()
