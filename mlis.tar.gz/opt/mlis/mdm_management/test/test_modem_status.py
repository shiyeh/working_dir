#!/usr/bin/python
import os
import sys
import time

sys.path.insert(0, os.path.abspath('..'))

from modem.status import status_leds
import modem.config as config

testpatt_lst = [
	# ['WANSTATE', 'CONNECTING'|'CONNECTED'|'NOCONNECT']
	['WANSTATE', 'CONNECTING'],
	['WANSTATE', 'CONNECTED'],
	['WANSTATE', 'NOCONNECT'],

	# ['CELLTYPE', '2G'|'3G'|'4G'|'EMERGENCY']
	['CELLTYPE', '2G'],
	['CELLTYPE', '3G'],
	['CELLTYPE', '4G'],
	['CELLTYPE', 'EMERGENCY'],

	# ['CELLSIG', 'NOSIG'|'POOR'|'NORMAL'|'GOOD']
	['CELLSIG', 'NOSIG'],
	['CELLSIG', 'POOR'],
	['CELLSIG', 'NORMAL'],
	['CELLSIG', 'GOOD'],

	# arg: ['SIMSTATE', 'SIM1READY'|'SIM2READY'|'SIM1LOCK'|'SIM2LOCK']
	['SIMSTATE', 'SIM1READY'],
	['SIMSTATE', 'SIM2READY'],
	['SIMSTATE', 'SIM1LOCK'],
	['SIMSTATE', 'SIM2LOCK'],
]


if __name__ == "__main__":
	mdm_status = status_leds()
	for testpatt in testpatt_lst:
		input = raw_input(">> ")
		# Python 3 users
		# input = input(">> ")
		if input == 'exit':
			mdm_status.clean_all()
			time.sleep(1)
			exit()
		else:
			mdm_status.clean_all()
			print testpatt
			mdm_status.update_status(testpatt)
