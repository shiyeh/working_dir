#!/usr/bin/python
import stat
import os
import sys
import time

sys.path.insert(0, os.path.abspath('..'))

from modem.device import mdm_dev
import modem.config as config


def test_mdm_dev_sendout_at(test_dev):
    mlbdev = test_dev
    input = 1
    idx = ' '
    cmdlst = [
        'ATE0',
        'AT+CMEE=2',
        'ATQQ?',
        'AT+CPIN?',
        'AT+CSQ',
        'AT+COPS?',
        'AT+CREG?',
        'AT+CGREG?',
        'AT+CGATT?',
        'AT+CGPADDR'
    ]

#    for idx in xrange(1, 10):
    for idx in cmdlst:
        # input = 'AT{0}\r\n'.format(idx)
        input = idx
        mlbdev.send_atcmd(input)


def test_mdm_dev_recvin_at(test_dev):
    mlbdev = test_dev
    while 1:
        recv_fullrslt_itm = mlbdev.recv_cmdrsp()
        print recv_fullrslt_itm


if __name__ == "__main__":
    devpath = '/dev/ttyUSB2'
    try:
        stat.S_ISCHR(os.stat(devpath).st_mode)
    except Exception, OSError:
        devpath = '/dev/ttyACM3'
        try:
            stat.S_ISCHR(os.stat(devpath).st_mode)
        except Exception, OSError:
            print ('not found any modem/module on device.')
            sys.exit(2)

    mlbdev = mdm_dev(devpath)
    print 'get mdm power st: ' + mlbdev.get_mdm_pwr_state()
    print 'get sim slot idx: ' + mlbdev.get_sim_slot_idx()
    mlbdev.cmdprc_start()
    test_mdm_dev_sendout_at(mlbdev)
    time.sleep(1)

    while 1:  # get keyboard input
        input = raw_input(">> ")
        # Python 3 users
        # input = input(">> ")
        if input == 'exit':
            mlbdev.cmdprc_stop()
            time.sleep(1)
            exit()
        else:
            # send the character to the device
            # (note that I happend a \r\n carriage return and line feed to the
            # characters - this is requested by my device)
            mlbdev.send_atcmd(input)
            out = []
            # let's wait one second before reading output (let's give device time
            # to answer)
            time.sleep(1)
            while 1:
                out = mlbdev.recv_cmdrsp(block=False)
                if out == []:
                    break
                else:
                    print out
