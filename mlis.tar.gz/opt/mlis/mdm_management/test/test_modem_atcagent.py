#!/usr/bin/python
import stat
import os
import sys
import time
import Queue

sys.path.insert(0, os.path.abspath('..'))

from modem.device import atcmd_agent
from modem.device import mdm_dev
import modem.config as config


def test_notify(inpdata=''):
    if inpdata == '*** client conn':
        print 'could create queue here.'
    else:
        STD_ATCMD_SUPRT_LIST = [
            'AT+CGDCONT',
            'AT+CPIN',
            'AT+CREG',
            'AT+CMGW',
            'AT+CMGF',
            'AT+CMGS',
            'AT+CMGC',
            'AT+CSQ'
        ]

        if ('AT' in inpdata):
            found = False
            for str in STD_ATCMD_SUPRT_LIST:
                if str in inpdata:
                    found = True
                    itm = []
                    itm.append(inpdata)
                    test_msgQ.put(inpdata)
                    break

            if not found:
                # only for AT
                itm = []
                itm.append(inpdata)
                test_msgQ.put(inpdata)

if __name__ == "__main__":
    test_atc = atcmd_agent(test_notify)
    test_msgQ = Queue.Queue()
    test_cnt = 0

    devpath = '/dev/ttyUSB2'
    try:
        stat.S_ISCHR(os.stat(devpath).st_mode)
    except Exception, OSError:
        devpath = '/dev/ttyACM3'
        try:
            stat.S_ISCHR(os.stat(devpath).st_mode)
        except Exception, OSError:
            print ('not found any modem/module on device.')
            sys.exit(2)
    else:
        mlbdev = mdm_dev(devpath)

    rslt = test_atc.open('10.0.10.1', '10001')
    while rslt:
        # test_atc.start()
        nxt_itm = test_msgQ.get()
        if nxt_itm:
            if nxt_itm == 'client disconn ***':
                print nxt_itm
            elif 'AT' in nxt_itm:
                # pass to modem and return modem rsp.
                mlbdev.send_atcmd(nxt_itm)
                time.sleep(0.1)
                test_atc.reply_message(mlbdev.recv_cmdrsp())
            else:
                test_atc.reply_message('ERROR')
                time.sleep(0.1)

    print 'close agent'
    test_atc.close()
    test_atc.join()
