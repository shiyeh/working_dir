#!/usr/bin/python
import os
import sys
sys.path.insert(0, os.path.abspath('..'))

from modem.parser import atcmd_parser as mdm_parser

test_patt = [
    ['+CPIN: READY', 'OK'],
    ['+CPIN: SIM PIN', 'OK'],
    ['+CPIN: SIM PUK', 'OK'],
    ['+CPIN: SIM PIN2', 'OK'],
    ['+CPIN: SIM PUK2', 'OK'],
    ['+CPIN: SIM PIN  \r\n', 'OK'],
    ['+CSQ: 19,99', 'OK'],
    ['OK'],
    ['ERROR'],
    ['+COPS: 0,0,"TW Mobile",2', 'OK'],
    ['+CGATT: 1', 'OK'],
    ['+CREG: 0,1', 'OK'],
    ['+CGREG: 0,1', 'OK'],
    ['+CGPADDR: 1,"100.83.38.100"', 'OK'],
    ['+CME ERROR: SIM not inserted'],
    ['+CREG: 1,"765F","014496ED",0'],
    ['+CREG: 2,1,"5278","00DC1C6F",2', 'OK'],
    ['^MODE: 5', '+CREG: 1,"7987","014496ED",2'],
    ['+CREG: 1,"7987","068BCFE8",2'],
    ['^MODE: 9', '+CREG: 1,"FFFE","068BCFE8",7'],
    []
]

notify_plugin = {

}

if __name__ == "__main__":
    cmdpr = mdm_parser(notify_plugin)
    for itm in test_patt:
        cmdpr.exec_handle(itm)
