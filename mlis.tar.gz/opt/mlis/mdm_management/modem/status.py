#!/usr/bin/python
import modem.config as config
import sqlite3


class WanPrioSetting(object):
    """docstring for WanPrioSetting"""
    def __init__(self, arg):
        super(WanPrioSetting, self).__init__()
        if arg is not '':
            self.conn_db = sqlite3.connect(arg)
        else:
            self.conn_db = sqlite3.connect('app.db')

        self.curr = self.conn_db.cursor()
        self._get_table_keylist()

        self.cursor = self.curr.execute("SELECT redundant, reg_nw_timeout, data_session_retry, term_redundant FROM wan_priority_setting WHERE id = 1")
        for row in self.cursor:
            self.enable = row[0]
            self.reg_nw_time = row[1]
            self.disconn_cnt = row[2]
            self.recycle = row[3]

    def _get_table_keylist(self):
        self.curr.execute("SELECT * FROM lan_setting")
        self.curr.fetchall()
        names = [cn[0] for cn in self.curr.description]
        print names

    def get_redundant_enable(self):
        if self.enable == 0:
            return False
        elif self.enable == 1:
            return True
        else:
            return False

    def get_regist_network_timeout(self):
        return self.reg_nw_time

    def get_diconnect_limited_cnt(self):
        return self.disconn_cnt

    def get_total_recycle_cnt(self):
        return self.recycle


# LAN SETTING INFORMATION { READ ONLY }
class LanSettingInfo(object):
    """docstring for LanSettingInfo"""
    def __init__(self, arg):
        super(LanSettingInfo, self).__init__()
        if arg is not '':
            self.conn_db = sqlite3.connect(arg)
        else:
            self.conn_db = sqlite3.connect('app.db')

        self.curr = self.conn_db.cursor()
        self._get_table_keylist()

        self.cursor = self.curr.execute("SELECT ip_addr, submask, dns, sec_dns FROM lan_setting WHERE id = 1")
        for row in self.cursor:
            self.ip_addr = row[0]
            self.submask = row[1]
            self.dns = row[2]
            self.sec_dns = row[3]

    def _get_table_keylist(self):
        self.curr.execute("SELECT * FROM lan_setting")
        self.curr.fetchall()
        names = [cn[0] for cn in self.curr.description]
        print names

    # ['id', 'ip_addr', 'submask', 'dns', 'sec_dns']
    def get_ip_addr(self):
        return self.ip_addr

    def get_ip_submask(self):
        return self.submask

    def get_dns(self):
        return self.dns

    def get_2nd_dns(self):
        return self.sec_dns


class LanInfo(object):
    def __init__(self, arg=''):
        if arg is not '':
            self.conn_db = sqlite3.connect(arg)
        else:
            self.conn_db = sqlite3.connect('status.db')

        self.curr = self.conn_db.cursor()
        self._get_table_keylist()

        self.cursor = self.curr.execute("SELECT mac_addr, ip_addr, submask FROM lan_info WHERE id = 1")
        for row in self.cursor:
            self.mac_addr = row[0]
            self.ip_addr = row[1]
            self.submask = row[2]

    def get_table_name(self):
        # print self.conn_db.execute("SELECT ")
        pass

    def _get_table_keylist(self):
        self.curr.execute("SELECT * FROM lan_info")
        self.curr.fetchall()
        names = [cn[0] for cn in self.curr.description]
        print names

    # ['id', 'mac_addr', 'ip_addr', 'submask']
    def get_mac_addr(self):
        return self.mac_addr

    def get_ip_addr(self):
        return self.ip_addr

    def get_sub_mask(self):
        return self.submask


class SystemInfo(object):
    def __init__(self, arg=''):
        if arg is not '':
            self.conn_db = sqlite3.connect(arg)
        else:
            self.conn_db = sqlite3.connect('status.db')

        self.curr = self.conn_db.cursor()
        self._get_table_keylist()

        self.model_name = ''
        self.model_name_flg = False

        self.device_name = ''
        self.device_name_flg = False

        self.serial_no = ''
        self.serial_no_flg = False

        self.up_time = ''
        self.up_time_flg = False

        self.fw_ver = ''
        self.fw_ver_flg = False

        self.fw_build_time = ''
        self.fw_build_time_flg = False

        self.imei = ''
        self.imei_flg = False

        self.imsi = ''
        self.imsi_flg = False

        self.cursor = self.curr.execute("SELECT model_name, device_name, serial_no, up_time, fw_ver, fw_build_time  FROM system_info WHERE id = 1")
        for row in self.cursor:
            self.model_name = row[0]
            self.device_name = row[1]
            self.serial_no = row[2]
            self.up_time = row[3]
            self.fw_ver = row[4]
            self.fw_build_time = row[5]

        self.cursor = self.curr.execute("SELECT imei, imsi  FROM cellular_info WHERE id = 1")
        for row in self.cursor:
            self.imei = row[0]
            self.imsi = row[1]

    # ['id', 'model_name', 'device_name', 'serial_no', 'up_time', 'fw_ver', 'fw_build_time']
    def get_table_name(self):
        # print self.conn_db.execute("SELECT ")
        pass

    def _get_table_keylist(self):
        self.curr.execute("SELECT * FROM system_info")
        self.curr.fetchall()
        names = [cn[0] for cn in self.curr.description]
        print names

    def get_imei(self):
        return self.imei

    def set_imei(self, inp=''):
        self.imei = inp
        self.imei_flg = True

    def get_imsi(self):
        return self.imsi

    def set_imsi(self, inp=''):
        self.imsi = inp
        self.imsi_flg = True

    def get_model_name(self):
        return self.model_name

    def set_model_name(self, inp=''):
        self.model_name = inp
        self.model_name_flg = True

    def get_serial_no(self):
        return self.serial_no

    def set_serial_no(self, inp=''):
        self.serial_no = inp
        self.serial_no_flg = True

    def get_fw_info(self):
        return self.fw_ver

    def update_db(self):
        commit_flg = False
        if self.model_name_flg is True:
            query = "UPDATE system_info set model_name = ? where id = 1"
            self.conn_db.execute(query, (self.model_name,))
            commit_flg = True
        if self.serial_no_flg is True:
            query = "UPDATE system_info set serial_no = ? where id = 1"
            self.conn_db.execute(query, (self.serial_no,))
            commit_flg = True
        if self.imsi_flg is True:
            query = "UPDATE cellular_info set imsi = ? where id = 1"
            self.conn_db.execute(query, (self.imsi,))
            commit_flg = True
        if self.imei_flg is True:
            query = "UPDATE cellular_info set imei = ? where id = 1"
            self.conn_db.execute(query, (self.imei,))
            commit_flg = True

        if commit_flg is True:
            self.conn_db.commit()
            self.model_name_flg = False
            self.device_name_flg = False
            self.serial_no_flg = False
            self.up_time_flg = False
            self.fw_ver_flg = False
            self.fw_build_time_flg = False

            self.imei_flg = False
            self.imsi_flg = False
        else:
            return

        # if any update in db, will update to object.
        self.cursor = self.curr.execute("SELECT model_name, device_name, serial_no, up_time, fw_ver, fw_build_time  FROM system_info WHERE id = 1")
        for row in self.cursor:
            self.model_name = row[0]
            self.device_name = row[1]
            self.serial_no = row[2]
            self.up_time = row[3]
            self.fw_ver = row[4]
            self.fw_build_time = row[5]

        self.cursor = self.curr.execute("SELECT imei, imsi  FROM cellular_info WHERE id = 1")
        for row in self.cursor:
            self.imei = row[0]
            self.imsi = row[1]


class CellularInfo(object):
    def __init__(self, arg=''):
        if arg is not '':
            self.conn_db = sqlite3.connect(arg)
        else:
            # self.conn_db = sqlite3.connect('status.db')
            return

        self.curr = self.conn_db.cursor()
        self._get_table_keylist()

        self.rssi = ''
        self.rssi_flg = False

        self.ip_addr = ''
        self.ip_addr_flg = False

        self.mode = ''
        self.mode_flg = False

        self.sim_slot = ''
        self.sim_slot_flg = False

        self.cursor = self.curr.execute("SELECT rssi, ip_addr, mode, active_sim FROM cellular WHERE id = 1")
        for row in self.cursor:
            self.rssi = row[0]
            self.ip_addr = row[1]
            self.mode = row[2]
            self.sim_slot = row[3]

    # ['id', 'rssi', 'ip_addr', 'mode', 'imei', 'imsi']
    def get_table_name(self):
        # return self.table.name
        pass

    def _get_table_keylist(self):
        self.curr.execute("SELECT * FROM cellular")
        self.curr.fetchall()
        names = [cn[0] for cn in self.curr.description]
        print names

    def get_rssi_byIndx(self, indx):
        pass

    def set_rssi_byIndx(self, indx):
        pass

    def get_rssi(self):
        return self.rssi

    def set_rssi(self, inp=''):
        self.rssi = inp
        self.rssi_flg = True

    def get_ip_addr(self):
        return self.ip_addr

    def set_ip_addr(self, inp=''):
        self.ip_addr = inp
        self.ip_addr_flg = True

    def get_network_type(self):
        return self.mode

    def set_network_type(self, inp=''):
        self.mode = inp
        self.mode_flg = True

    def set_act_sim(self, inp=''):
        self.sim_slot = inp
        self.sim_slot_flg = True

    def get_act_sim(self):
        pass

    def update_db(self):
        commit_flg = False
        if self.rssi_flg is True:
            query = "UPDATE cellular set rssi = ? where id = 1"
            self.conn_db.execute(query, (self.rssi,))
            commit_flg = True
        if self.ip_addr_flg is True:
            query = "UPDATE cellular set ip_addr = ? where id = 1"
            self.conn_db.execute(query, (self.ip_addr,))
            commit_flg = True
        if self.mode_flg is True:
            query = "UPDATE cellular set mode = ? where id = 1"
            self.conn_db.execute(query, (self.mode,))
            commit_flg = True

        if self.sim_slot_flg is True:
            query = "UPDATE cellular set active_sim = ? where id = 1"
            self.conn_db.execute(query, (self.sim_slot,))
            commit_flg = True

        if commit_flg is True:
            self.conn_db.commit()
            self.rssi_flg = False
            self.ip_addr_flg = False
            self.mode_flg = False
            self.sim_slot_flg = False

        self.cursor = self.curr.execute("SELECT rssi, ip_addr, mode, active_sim FROM cellular WHERE id = 1")
        for row in self.cursor:
            self.rssi = row[0]
            self.ip_addr = row[1]
            self.mode = row[2]
            self.sim_slot = row[3]


class status_leds(object):
    """docstring for status_leds"""
    def __init__(self, arg=''):
        super(status_leds, self).__init__()
        self.arg = arg
        self._stftbl = {
            'CELLSIG': self.set_cellsig_qlty,
            'CELLTYPE': self.set_cellsig_type,
            'SIMSTATE': self.set_sim,
            'WANSTATE': self.set_wan,
        }
        self._ledctrlmap = {
            'LED_S3': '/sys/class/leds/mlb:86',
            'LED_S2': '/sys/class/leds/mlb:87',
            'LED_S1': '/sys/class/leds/mlb:89',
            'LED_4G': '/sys/class/leds/mlb:110',
            'LED_3G': '/sys/class/leds/mlb:117',
            'LED_READY': '/sys/class/leds/mlb:111',
            'LED_FAIL': '/sys/class/leds/mlb:112',
            'LED_SIM1': '/sys/class/leds/mlb:113',
            'LED_SIM2': '/sys/class/leds/mlb:114'
        }
        self._ledvalmap = {
            # led funciton by [[filename, value] ... ]
            'ON': [['trigger', 'none'], ['brightness', 255]],
            'OFF': [['trigger', 'none'], ['brightness', 0]],
            'FLASH': [['trigger', 'timer'], ['delay_on', 800], ['delay_off', 800]]
        }
        self.cellsig = 'NOSIG'
        self.cellnwtyp = 'EMERGENCY'
        self.wanstate = 'CONNECTING'
        self.simstate = 'NOSIM'

        self._mdm_type = ''

    # arg = ['LED_READY', 'ON'|'OFF'|'FLASH']
    def _led_set(self, arg):
        led = arg[0]
        val = arg[1]
        if (led in self._ledctrlmap.keys()):
            if (val in self._ledvalmap.keys()):
                target = self._ledvalmap[val]
                for itm in target:
                    fn = self._ledctrlmap[led] + '/' + itm[0]
                    val = itm[1]
                    print 'path: ' + fn + ', vaule: ' + str(val)
                    fd = open(fn, 'w')
                    fd.write(str(val))
                    fd.close()
            else:
                print 'not found led value setting in tbl'
        else:
            print 'not found led path in tbl'

    def set_modem_type(self, typename=''):
        self._mdm_type = typename
        return

    def get_modem_type(self):
        return self._mdm_type

    # arg: ['WANSTATE', 'CONNECTING'|'CONNECTED'|'NOCONNECT']
    # arg: ['CELLTYPE', '2G'|'3G'|'4G'|'EMERGENCY']
    # arg: ['CELLSIG', 'NOSIG'|'POOR'|'NORMAL'|'GOOD']
    # arg: ['SIMSTATE', 'SIM1READY'|'SIM2READY'|'SIM1LOCK'|'SIM2LOCK']
    def update_status(self, arg):
        if (callable(self._stftbl[arg[0]])):
            self._stftbl[arg[0]](arg)

    #  I think this function only for testing.
    def clean_all(self):
        for cled in self._ledctrlmap.keys():
            for itm in self._ledvalmap['OFF']:
                fn = self._ledctrlmap[cled] + '/' + itm[0]
                val = itm[1]
                fd = open(fn, 'w')
                fd.write(str(val))
                fd.close()

    # arg: ['CELLTYPE', '2G'|'3G'|'4G'|'EMERGENCY']
    def set_cellsig_type(self, arg):
        typ = arg[1]

        # skip update if same as current state.
        if self.cellnwtyp == typ:
            return

        if (typ == '2G'):
            hispd = ['LED_4G', 'OFF']
            lowspd = ['LED_3G', 'ON']

        elif (typ == '3G'):
            if self._mdm_type == 'EHS6':
                hispd = ['LED_4G', 'ON']
                lowspd = ['LED_3G', 'OFF']
            elif self._mdm_type == 'MC7304':
                hispd = ['LED_4G', 'OFF']
                lowspd = ['LED_3G', 'ON']

        elif (typ == '4G'):
            hispd = ['LED_4G', 'ON']
            lowspd = ['LED_3G', 'OFF']

        else:
            hispd = ['LED_4G', 'OFF']
            lowspd = ['LED_3G', 'OFF']

        self.cellnwtyp = typ
        self._led_set(hispd)
        self._led_set(lowspd)
        return

    # arg: ['CELLSIG', 'NOSIG'|'POOR'|'NORMAL'|'GOOD']
    def set_cellsig_qlty(self, arg):
        lvl = arg[1]

        # skip update if same as current state.
        if self.cellsig == lvl:
            return

        if (lvl == 'NOSIG'):
            sig1 = ['LED_S1', 'OFF']
            sig2 = ['LED_S2', 'OFF']
            sig3 = ['LED_S3', 'OFF']
        elif (lvl == 'POOR'):
            sig1 = ['LED_S1', 'ON']
            sig2 = ['LED_S2', 'OFF']
            sig3 = ['LED_S3', 'OFF']
        elif (lvl == 'NORMAL'):
            sig1 = ['LED_S1', 'ON']
            sig2 = ['LED_S2', 'ON']
            sig3 = ['LED_S3', 'OFF']
        elif (lvl == 'GOOD'):
            sig1 = ['LED_S1', 'ON']
            sig2 = ['LED_S2', 'ON']
            sig3 = ['LED_S3', 'ON']
        else:
            sig1 = ['LED_S1', 'OFF']
            sig2 = ['LED_S2', 'OFF']
            sig3 = ['LED_S3', 'OFF']

        self._led_set(sig1)
        self._led_set(sig2)
        self._led_set(sig3)
        self.cellsig = lvl
        return

    # arg: ['WANSTATE', 'CONNECTING'|'CONNECTED'|'NOCONNECT']
    def set_wan(self, arg):
        sts = arg[1]

        # skip update if same as current state.
        if self.wanstate == sts:
            return

        if (sts == 'CONNECTING'):
            cfg = ['LED_READY', 'FLASH']
        elif (sts == 'CONNECTED'):
            cfg = ['LED_READY', 'ON']
        # simily else case
        # elif (sts == 'NOCONNECT'):
        #     cfg = ['LED_READY', 'OFF']
        else:
            cfg = ['LED_READY', 'OFF']

        self._led_set(cfg)
        self.wanstate = sts
        return

    # arg: ['SIMSTATE', 'SIM1READY'|'SIM2READY'|'SIM1LOCK'|'SIM2LOCK'|'NOSIM']
    def set_sim(self, arg):
        slt = arg[1]

        # skip update if same as current state.
        if self.simstate == slt:
            return

        if (slt == 'SIM1READY'):
            sim1 = ['LED_SIM1', 'ON']
            sim2 = ['LED_SIM2', 'OFF']
        elif (slt == 'SIM2READY'):
            sim1 = ['LED_SIM1', 'OFF']
            sim2 = ['LED_SIM2', 'ON']
        elif (slt == 'SIM1LOCK'):
            sim1 = ['LED_SIM1', 'FLASH']
            sim2 = ['LED_SIM2', 'OFF']
            wan = ['LED_READY', 'OFF']
            self._led_set(wan)
        elif (slt == 'SIM2LOCK'):
            sim1 = ['LED_SIM1', 'OFF']
            sim2 = ['LED_SIM2', 'FLASH']
            wan = ['LED_READY', 'OFF']
            self._led_set(wan)
        elif (slt == 'NOSIM'):
            fault = ['LED_FAIL', 'ON']
            sim1 = ['LED_SIM1', 'OFF']
            sim2 = ['LED_SIM2', 'OFF']
            wan = ['LED_READY', 'OFF']
            self._led_set(wan)
            self._led_set(fault)
        else:
            sim1 = ['LED_SIM1', 'OFF']
            sim2 = ['LED_SIM2', 'OFF']
            wan = ['LED_READY', 'OFF']
            self._led_set(wan)

        self._led_set(sim1)
        self._led_set(sim2)
        self.simstate = slt
        return
