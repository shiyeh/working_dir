#!/usr/bin/python
import time
import serial
import Queue

import socket
import sys
import select

import threading


# AT Commad Agent class:
# .create subthread for agent running.
# .carete qeueu for communicating with parent thread.
class atcmd_agent(threading.Thread):
    """dnotify_cb=''tring for atc_if"""
    def __init__(self, notify):
        super(atcmd_agent, self).__init__()
        self.daemon = True
        self.alive = True
        self._lock = threading.Lock()
        self._connection_made = threading.Event()

        self.notify = notify
        self.rsp_q = Queue.Queue()
        # self.clntlst = []
        self.outputs = []
        self.inputs = []

    def open(self, addr='127.0.0.1', prt='10001'):
        print 'open agent'
        # create socket and then start running
        try:
            self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        except socket.error, msg:
            sys.stderr.write("[ERROR] %s\n" % msg[1])
            self.alive = False
            return False
        else:
            # reuse tcp port.
            self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self.sock.bind((addr, int(prt)))
            self.sock.listen(1)
            self.start()

        return True

    def reply_message(self, rsp_str=''):
        print rsp_str
        self.rsp_q.put(rsp_str)

    def run(self):
        print 'thread running'
        self.inputs.append(self.sock)

        while self.alive:
            try:
                rd_ready, wr_ready, on_err = select.select(self.inputs, self.outputs, self.inputs)
            except Exception:
                print 'force socket close.'
                self.outputs = []
                self.inputs = []
            else:
                for s in rd_ready:
                    print 'in rd_ready for loop'
                    if s is self.sock:
                        # server socket, accept incoming client.
                        # print 'accpet incoming conn'
                        (client_sock, addrstr) = self.sock.accept()
                        client_sock.setblocking(0)

                        self.inputs.append(client_sock)
                        # self.outputs.append(client_sock)
                        # self.clntlst.append(client_sock)
                        # call notify_cb
                        # if callable(self.notify):
                        #     inp_data = '*** client conn'
                        #     self.notify(inp_data)
                        print '*** client conn'

                    else:
                        try:
                            inp_data = s.recv(1024)
                        except Exception:
                            # Interpret empty result as closed connection
                            # Stop listening for input on the connection
                            self.inputs.remove(s)
                            if s in self.outputs:
                                self.outputs.remove(s)

                            s.close()
                            # if callable(self.notify):
                            #    self.notify('client disconn ***')
                            print 'socket.recv Exception, client disconn ***'

                        else:
                            if inp_data:
                                print 'recv data: ', inp_data
                                if s not in self.outputs:
                                    self.outputs.append(s)

                                # call notify_cb
                                if callable(self.notify):
                                    self.notify(inp_data)

                            else:
                                # Interpret empty result as closed connection
                                # Stop listening for input on the connection
                                self.inputs.remove(s)
                                if s in self.outputs:
                                    self.outputs.remove(s)

                                # self.clntlst.remove(s)
                                s.close()
                                # if callable(self.notify):
                                #     self.notify('client disconn ***')
                                print 'Interpret empty result, client disconn ***'

                for s in wr_ready:
                    # print 'in wr_ready for loop'
                    try:
                        next_msg = self.rsp_q.get(block=False)
                    except Exception, Queue.Empty:
                        time.sleep(0.1)  # waiting a little bit for next time.
                        # print 'queue empty, removing conn frm outputs'
                        # if s in self.outputs:
                        #    self.outputs.remove(s)

                        # s.send('ERROR')
                    else:
                        s.send(next_msg)
                        # reparsing or composing to other format?
                        # if 'OK' in next_msg:
                        #     s.send('OK')
                        # elif '>' in next_msg:
                        #     s.send('>')
                        # else:
                        #     s.send('ERROR')

                for s in on_err:
                    # Stop listening for input on the connection
                    self.inputs.remove(s)
                    if s in self.outputs:
                        self.outputs.remove(s)

                    # self.clntlst.remove(s)
                    s.close()
                    # if callable(self.notify):
                    #     self.notify('client disconn ***')
                    print 'in on_err for loop, client disconn ***'

        print "sleep 1s."
        time.sleep(1)

        print 'exit running'
        return

    def close(self):
        self.alive = False
        self.sock.close()


class mdm_dev(object):
    """docstring for mdm_dev"""
    def __init__(self, arg='/dev/ttyACM3'):
        super(mdm_dev, self).__init__()
        self._dev_path = arg
        self._baudrate = 115200
        self._parity = serial.PARITY_ODD
        self._stopbits = serial.STOPBITS_TWO
        self._bytesize = serial.SEVENBITS

        self._ioftbl = {
        }
        self._mdmctrlio = {
            'MDM_PWR': '/sys/class/gpio/gpio69',
            'MDM_SIMSEL': '/sys/class/gpio/gpio115'
        }
        self._iovalmap = {
            'ON': [['direction', 'out'], ['value', '1']],
            'OFF': [['direction', 'out'], ['value', '0']]
        }

        # config.DEV_CMD_DUMP=1
        self.req_q = Queue.Queue()
        self.rsp_q = Queue.Queue()
        self.work_running = False

    def _get_output_ioval(self, funcname=''):
        rlt = 'ON'
        if funcname == '':
            print 'Err: funcname empty'
            return 'ERROR'

        dirfile = self._mdmctrlio[funcname] + '/' + self._iovalmap[rlt][0][0]
        valfile = self._mdmctrlio[funcname] + '/' + self._iovalmap[rlt][1][0]

        fd = open(dirfile, 'r')
        dirstr = fd.read()
        fd.close()

        fd = open(valfile, 'r')
        valstr = fd.read()
        fd.close()

        if ('out' in dirstr) and ('0' in valstr):
            rlt = '0'
        elif ('out' in dirstr) and ('1' in valstr):
            rlt = '1'
        else:
            rlt = 'ERROR'
        return rlt

    def set_mdm_pwr_state(self, onoff='ON'):
        # currenlt not implement
        pass

    def get_mdm_pwr_state(self):
        rlt = self._get_output_ioval('MDM_PWR')

        print rlt
        if rlt == '1':
            rlt = 'OFF'
        elif rlt == '0':
            rlt = 'ON'
        else:
            rlt = 'ERROR'
        return rlt

    def set_sim_slot_idx(self, indx='SIM1'):
        # ToDo:
        #   . close comport
        #   . stop cmdprc thread.
        pass

    def get_sim_slot_idx(self):
        rlt = self._get_output_ioval('MDM_SIMSEL')

        if rlt == '0':
            rlt = 'SIM1'
        elif rlt == '1':
            rlt = 'SIM2'
        else:
            rlt = 'ERROR'
        return rlt

    def send_atcmd(self, cmdstr=""):
        if self.work_running is False:
            return
        if (cmdstr == ''):
            return
        else:
            atcmd = cmdstr + '\r\n'
            self.req_q.put(atcmd)
            return

    def recv_cmdrsp(self, block=True, timeout=None):
        while self.work_running:
            try:
                itm = self.rsp_q.get(block, timeout)
            except Exception, Queue.Empty:
                if (block is True) and (timeout is None):
                    time.slepp(0.1)
                else:
                    return []
            else:
                # print "recv_cmdrsp itm:"
                # print itm
                itm = filter(None, itm)
                return itm
        return []

    def _cmdprc_work(self):
        while self.work_running:
            try:
                itm = self.req_q.get(block=False, timeout=None)
            except Exception, Queue.Empty:
                time.sleep(0.01)
                if self.work_running is False:
                    break

                # read rsp from MDM
                rsp = ''

                while self.ser.inWaiting() > 0:
                    cnt = self.ser.inWaiting()
                    ch = self.ser.read(cnt)
                    rsp += ch

                if len(rsp) > 0:
                    rsp_itm = rsp.splitlines()
                    self.rsp_q.put(rsp_itm)

                    # while True:
                    #     time.sleep(0.1)
                    #     out = self.ser.read(1)
                    #     if (len(out) == 0):
                    #         if (len(rsp) > 0):
                    #            print("URC: [{1}] {0}".format(rsp, len(rsp)))
                    #            put rsp into queue, for main thdrd pocesses.
                    #            rsp_itm = rsp.splitlines()
                    #            self.rsp_q.put(rsp_itm)
                    #         break
                    #     else:
                    #         rsp += out
                    # time.sleep(0.1)
                    # check empty line for ending.
            else:
                # print "send cmd: " + itm
                self.ser.write(itm)
                ch = ''
                out = ''
                # hexsrt = ''
                time.sleep(0.3)
                if self.work_running is False:
                    break

                while self.ser.inWaiting() > 0:
                    cnt = self.ser.inWaiting()
                    ch = self.ser.read(cnt)
                    out += ch
                    time.sleep(0.01)
                    if self.work_running is False:
                        break

                #    hexsrt += "{0:02x} ".format(ord(ch))

                # if (config.DEV_CMD_DUMP == 1):
                #    print('DUMP str: ' + out)
                #    print('DUMP hex: ' + hexsrt)

                # put rsp into queue, for main thdrd pocesses.
                # print '_cmdprc_work in:'
                # print out

                rsp_itm = out.splitlines()
                # print '_cmdprc_work out:'
                # print rsp_itm
                self.rsp_q.put(rsp_itm, block=True)

        if not self.ser:
            self.ser.close()

        return

    def cmdprc_start(self):
        if self.work_running is False:
            if self.get_mdm_pwr_state() == 'OFF':
                return

            # configure the serial connections
            # (the parameters differs on the device you are connecting to)
            self.ser = serial.Serial(port=self._dev_path,
                                     baudrate=self._baudrate,
                                     parity=self._parity,
                                     stopbits=self._stopbits,
                                     bytesize=self._bytesize,
                                     timeout=0.1)
            self.ser.isOpen()

            self._thrd_inst = threading.Thread(target=self._cmdprc_work)
            self._thrd_inst.daemon = True
            self.work_running = True
            self._thrd_inst.start()

        else:
            if self.get_mdm_pwr_state() == 'OFF':
                self.cmdprc_stop()

        return

    def cmdprc_stop(self):
        self.work_running = False
        self.ser.close()
        while self._thrd_inst.is_alive():
            self._thrd_inst.join(0.5)

        del self._thrd_inst
        del self.ser
        return
