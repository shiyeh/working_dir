#!/usr/bin/python
print 'modem module init'
