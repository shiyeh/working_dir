#!/usr/bin/python
import modem.config as config


class atcmd_parser(object):
    ATRST_TYPE_LIST = [
        "+CME ERROR:",
        "ERROR",
        "OK",
        ""
    ]

    STD_URC_TYPE_LIST = [
        # NETWORK part.
        '+CREG:',  # AT+CREG=2

        # CALL part.
        'RING',  # AT+CRC=1
        '+CRING:',  # AT+CRC=2

        # SMS part.
        '+CMT:',
        '+CMTI:',
        '+CBM:',
        '+CBMI:',
        '+CDS:',
        '+CDSI',
    ]

    # Sierra Wireless URCs
    SW_URC_TYPE_LIST = [
        '^MODE'
    ]

    # standard atcmd supported.
    rsltdct = {}

    """docstring for atcmd_parser"""
    def __init__(self, arg={}):
        super(atcmd_parser, self).__init__()
        self.notifyfunc = arg
        self.rsltdct = {
            '+CPIN:': self.cpin_handle,
            '+CSQ:': self.csq_handle,
            '+COPS:': self.cops_handle,
            '+CREG:': self.creg_handle,
            '+CGREG:': self.cgreg_handle,
            '+CGATT:': self.cgatt_handle,
            '+CGPADDR:': self.cgpaddr_handle,
            'EHS6': self.ehs6_handle,
            'MC7304': self.mc7304_handle
        }

        self.urcdct = {
            '+CREG:': self.urc_creg_hndl,
            'RING': self.urc_ring_hndl,
            '+CRING:': self.urc_cring_hndl,
            '+CMT:': self.urc_cmt_hndl,
            '+CMTI:': self.urc_cmti_hndl,
            '+CBM:': self.urc_cbm_hndl,
            '+CBMI:': self.urc_cbmi_hndl,
            '+CDS:': self.urc_cds_hndl,
            '+CDSI': self.urc_cdsi_hndl
        }

    def exec_handle(self, src_itm=[]):
        caught = []
        print 'Parser incoming:'
        print src_itm

        # 1st, Finding AT CMD final result belong to OK or ERROR.
        substr = "\t".join(src_itm)
        ok_pos = substr.find('OK')

        if substr.find('+CME ERROR:') == 0:
            # EX:
            # +CME ERROR: SIM not inserted
            caught.append('ERROR')
            caught.append(substr[len('+CME ERROR:'):].strip())

        elif substr.find('ERROR') == 0:
            caught.append('ERROR')
            caught.append(substr[len('ERROR'):].strip())

        elif ok_pos >= 0:
            caught.append('OK')
            # TODO: will be performance issue here. should use set to solve this.
            for dstr in self.rsltdct.keys():
                pos = substr.find(dstr)
                if (pos >= 0):
                    pos = pos + len(dstr)

                    if ok_pos == 0:
                        # URC code? ['OK', ATCMDxxx rsp string]
                        tmp = substr[pos:].strip()
                    else:
                        # [ATCMDxxx string, ATCMDxxx rsp string, 'OK']
                        tmp = substr[pos:substr.find('OK')].strip()

                    caught.append(self.rsltdct[dstr](tmp))
                    break
            caught.append('')
        else:
            # try URC list.
            for urcstr in atcmd_parser.STD_URC_TYPE_LIST:
                pos = substr.find(urcstr)
                if pos >= 0:
                    print '** found URC message: \"' + substr + '\"'
                    print '** key: \"' + urcstr + '\"'
                    try:
                        func = self.urcdct[urcstr]
                    except KeyError:
                        print 'Error: not fund mapping callback'
                    else:
                        if (callable(func)):
                            caught.append('OK')
                            caught.append(func(substr[(pos + len(urcstr)):]))
                            caught.append('')
                        else:
                            print 'Error: invaild callback.'
                            caught.append('PROG NG')  # tmp string for warning.
                            caught.append('')

        return caught

    def ehs6_handle(self, rspstr=''):
        return 'EHS6'

    def mc7304_handle(self, rspstr=''):
        return 'MC7304'

    def cpin_handle(self, rspstr=''):
        print ("calling cpin_handle: '{0}'".format(rspstr))
        if ('READY' in rspstr):
            return "READY"
        elif ('SIM PIN' == rspstr):
            return "PIN1"
        elif ('SIM PUK' == rspstr):
            return "PUK1"
        elif ('SIM PIN2' == rspstr):
            return "NOT SUPPORT: PIN2"
        elif ('SIM PUK2' == rspstr):
            return "NOT SUPPORT: PUK2"
        else:
            print ("OTHER LOCK: {0}".format(rspstr))
            return rspstr

    def csq_handle(self, rspstr=''):
        print ("calling csq_handle: '{0}'".format(rspstr))
        rspitm = rspstr.split(',')
        rssi = int(rspitm[0])
        # ber = int(rspitm[1])
        caught = []
        if (rssi == 99) or (rssi > 0 and rssi <= 31):
            caught.append(rssi)
        else:
            caught.append(-1)
        return caught

    def cops_handle(self, rspstr=''):
        caught = []
        print ("calling cops_handle: '{0}'".format(rspstr))
        rspitm = rspstr.split(',')
        mode = int(rspitm[0])
        opformat = int(rspitm[1])
        opname = rspitm[2]
        act = int(rspitm[3])
        print ("mode is {0:d}".format(mode))
        print ("op name format is {0:d}".format(opformat))
        print ("op name is {0}".format(opname))
        print ("Act is {0}".format(act))
        caught.append(mode)
        caught.append(opformat)
        caught.append(opname)
        caught.append(act)
        return caught

    def creg_handle(self, rspstr=''):
        caught = []
        print ("calling creg_handle: '{0}'".format(rspstr))
        rspitm = rspstr.split(',')
        _indx = 0
        _len = len(rspitm)
        mode = int(rspitm[_indx])

        if (mode == 0) or (mode == 1):
            _indx = _indx + 1
            reg_status = rspitm[_indx]

            print ("CREG Mode is {0:d}, reg status is {1}".format(mode, reg_status))
            caught.append(mode)
            reg_status = reg_status.strip()
            caught.append(reg_status)
        elif (mode == 2):
            net_location = "<null>"
            net_cellid = "<null>"
            act = "<null>"

            _indx = _indx + 1
            reg_status = rspitm[_indx]

            _indx = _indx + 1
            if reg_status == '0':
                # not registed network
                caught.append(mode)
                caught.append(reg_status)

            elif _indx < _len:
                net_location = rspitm[_indx]
                _indx = _indx + 1
                if _indx < _len:
                    net_cellid = rspitm[_indx]
                    _indx = _indx + 1
                if _indx < _len:
                    act = rspitm[_indx]

            print ("CREG Mode is {0:d}, netLac:{1}, netCellid:{2}, AcT:{3}".format(mode, net_location, net_cellid, act))
            caught.append(mode)
            caught.append(reg_status)
            caught.append(net_location)
            caught.append(net_cellid)
            caught.append(act)
        return caught

    def cgreg_handle(self, rspstr=''):
        print ("calling cgreg_handle: '{0}'".format(rspstr))
        rspitm = rspstr.split(',')
        mode = int(rspitm[0])
        if (mode == 0):
            stat = int(rspitm[1])
            print ("CGREG mode: {0:d}, stat: {1:d}".format(mode, stat))
        else:
            print ("Currently not support URC message.")
        return

    def cgatt_handle(self, rspstr=''):
        print ("calling cgatt_handle: '{0}'".format(rspstr))
        gprs = int(rspstr)
        print ("GPRS attached: {0:d}".format(gprs))
        return

    def cgpaddr_handle(self, rspstr=''):
        print ("calling cgpaddr_handle: '{0}'".format(rspstr))
        print ("Currently not support.")
        return

    def dummy_handle(self, rspstr=''):
        print ("dummy_handle for OK.")
        return

    def urc_creg_hndl(self, rspstr=''):
        print ('Enter urc_creg_hndl')
        return self.creg_handle(rspstr)

    def urc_ring_hndl(self, rspstr=''):
        print ('Enter urc_ring_hndl')

    def urc_cring_hndl(self, rspstr=''):
        print ('Enter urc_cring_hndl')

    def urc_cmt_hndl(self, rspstr=''):
        print ('Enter urc_cmt_hndl')

    def urc_cmti_hndl(self, rspstr=''):
        print ('Enter urc_cmti_hndl')

    def urc_cbm_hndl(self, rspstr=''):
        print ('Enter urc_cbm_hndl')

    def urc_cbmi_hndl(self, rspstr=''):
        print ('Enter urc_cbmi_hndl')

    def urc_cds_hndl(self, rspstr=''):
        print ('Enter urc_cds_hndl')

    def urc_cdsi_hndl(self, rspstr=''):
        print ('Enter urc_cdsi_hndl')
