#!/bin/sh

source init-mlb-env.sh

if [ -f "${WEB_APP_DB_PATH}" ]
then
	DB_IF_ADDR_IP=`sqlite3 "${WEB_APP_DB_PATH}" 'select ip_addr from lan_setting'`
	DB_IF_MASK_STR=`sqlite3 "${WEB_APP_DB_PATH}" 'select submask from lan_setting'`

	if [ "${DB_IF_ADDR_IP}" = "127.0.0.1" ]
	then
		echo "Err: Not allow IP setting, ${DB_IF_ADDR_IP}."
		exit 1
	fi

	IF_ADDR_SUB=`echo ${DB_IF_ADDR_IP} | awk -F. '{printf ("%s.%s.%s", $1, $2, $3)}'`
	IF_ADDR_IP="${DB_IF_ADDR_IP}"
	IF_MASK_STR="${DB_IF_MASK_STR}"

	echo "${IF_ADDR_IP}"
	echo "${IF_ADDR_SUB}"
	echo "${IF_MASK_STR}"
	source gen-netif-conf.sh
fi