#!/bin/sh

GPIO_EXP="/sys/class/gpio/export"
GPIO_DIN2="/sys/class/gpio/gpio23"
GPIO_DIN1="/sys/class/gpio/gpio22"

if [ ! -d "${GPIO_DIN1}" ]
then
	echo 22 > "${GPIO_EXP}"
fi

if [ ! -d "${GPIO_DIN2}" ]
then
	echo 23 > "${GPIO_EXP}"
fi

echo "${GPIO_DIN1}"
echo "in" > "${GPIO_DIN1}/direction"
cat "${GPIO_DIN1}/direction"
cat "${GPIO_DIN1}/value"

echo "${GPIO_DIN2}"
echo "in" > "${GPIO_DiN2}/direction"
cat "${GPIO_DIN2}/direction"
cat "${GPIO_DIN2}/value"