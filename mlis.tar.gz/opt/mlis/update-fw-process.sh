#!/bin/sh

source init-mlb-env.sh

sleep 1
if [ -f "/tmp/mlis.tar.gz" ]
then
    rm -rf ${MLB_DIR}/*
    tar -xvpf /tmp/mlis.tar.gz -C /

    source web-update-all.sh

    sync
    reboot
    exit 0
fi
echo "cannot found FW file."
exit 1
