#!/bin/sh

if [ "$#" = 0 ]; then
	echo "must have choose on or off."
else
	case $1 in
		ON | on )           
			#echo "Ready LEDs ON"
 			onoff=1
 			;;
 		OFF | off )
			#echo "Ready LEDs OFF"		
 			onoff=0
 			;;
 		Flash | FLASH | flash )
 			#echo "Ready LED flash mode, ON: 1sec, OFF: 1sec."
		 	onoff=2
		 	;;
        * )
        	echo "arg must be [ON|on] or [OFF|off]"
			exit 1
	esac
fi

LED_S3=/sys/class/leds/mlb:86
LED_S2=/sys/class/leds/mlb:87
LED_S1=/sys/class/leds/mlb:89
LED_4G=/sys/class/leds/mlb:117
LED_3G=/sys/class/leds/mlb:110
LED_FAIL=/sys/class/leds/mlb:112
LED_READY=/sys/class/leds/mlb:111
LED_SIM1=/sys/class/leds/mlb:113
LED_SIM2=/sys/class/leds/mlb:114

if [ -d "${LED_READY}" ]
then
	#echo "Led READY: ${LED_READY}"
	if [ $onoff = 1 ]
	then
		echo none > "${LED_READY}"/trigger
		VALUE=`cat "${LED_READY}"/max_brightness`
		#echo "brightness is ${VALUE}"
		echo ${VALUE} > "${LED_READY}/brightness"
	elif [ $onoff = 2 ]
	then
		echo timer > "${LED_READY}"/trigger
		echo 1000 > "${LED_READY}"/delay_on
		echo 1000 > "${LED_READY}"/delay_off
	else
		VALUE=0
		echo none > "${LED_READY}"/trigger
		#echo "brightness is ${VALUE}"
		echo ${VALUE} > "${LED_READY}/brightness"
	fi

fi
