#!/bin/sh

### Generate /opt/mlis/conf/iptables.ppp0.ipv4.nat file.
cat > "${MLB_PPP_NAT_PATH}" << EOF
# Begin ${MLB_PPP_NAT_PATH}
*filter
:INPUT ACCEPT [0:0]
:FORWARD ACCEPT [0:0]
:OUTPUT ACCEPT [0:0]
${IPTBL_FILTER_RULES}
COMMIT
*nat
:PREROUTING ACCEPT [0:0]
:INPUT ACCEPT [0:0]
:OUTPUT ACCEPT [0:0]
:POSTROUTING ACCEPT [0:0]
${IPTBL_NAT_RULES}
COMMIT
# End ${MLB_PPP_NAT_PATH}
EOF
### Generate /opt/mlis/conf/iptables.ppp0.ipv4.nat file.