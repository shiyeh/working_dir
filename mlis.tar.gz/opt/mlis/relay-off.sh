#!/bin/sh

echo 0 > /sys/class/gpio/gpio26/value
exit 0
