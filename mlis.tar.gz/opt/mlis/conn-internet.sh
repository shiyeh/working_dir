#!/bin/sh

if [ "$#" = 0 ]; then
	echo "ERR: must have choose on or off."
else
	case $1 in
		ON | on )           
			echo "LEDs ON"
 			onoff=1
 			;;
 		OFF | off )
			echo "LEDs ON"		
 			onoff=0
 			;;
        * )
        	echo "arg must be [ON|on] or [OFF|off]"
			exit 1
	esac
fi

MDM_3G=/dev/ttyACM0
MDM_4G=/dev/ttyUSB2
APN_CFG=/etc/ppp/apn_opt


MDM_PPPD=/usr/sbin/pppd
MDM_PROFILE=/etc/ppp/peers/cdma
PPPD_PID=

if [ -e "${MDM_3G}" ]; then
	if [ ${onoff} = 1 ]; then
		echo -e "${MDM_3G} connecting...\r\n"
		if [ -e "${APN_CFG}" ]; then
			echo -e "${APN_CFG} content:\r\n"
			cat "${APN_CFG}"
			echo -e "\r\n"
		else
			echo "ERR: Please config PDP type and APN first."
			exit 1;
		fi
		
		source ${APN_CFG}
		if [ -e ${MDM_PROFILE} ]; then
			${MDM_PPPD} call cdma "${MDM_3G}"&
		fi 
	else 
		echo "${MDM_3G} disconnecting...\r\n"
		
	fi
fi

if [ -e "${MDM_4G}" ]; then
	echo "${MDM_4G}"
        if [ ${onoff} = 1 ]; then
                echo -e "${MDM_4G} connecting...\r\n"
                if [ -e "${APN_CFG}" ]; then
                        echo -e "${APN_CFG} content:\r\n"
                        cat "${APN_CFG}"
                        echo -e "\r\n"
                else
                        echo "ERR: Please config PDP type and APN first."
                        exit 1;
                fi

                source ${APN_CFG}
                if [ -e ${MDM_PROFILE} ]; then
                        ${MDM_PPPD} call cdma "${MDM_4G}"&
                fi
        else
                echo "${MDM_4G} disconnecting...\r\n"

        fi
fi 
i