#!/bin/sh
source /opt/mlis/init-mlb-env.sh

PRISIM="2"
if [ ${PRISIM} == "1" ]
then
	BCKINGSIM="2"
elif [ ${PRISIM} == "2" ]
then
	BCKINGSIM="1"
else
	echo "ERR: incorrect setting, reset to default"
	PRISIM="1"
	BCKINGSIM="2"
fi

if [ -f "${WEB_APP_DB_PATH}" ]
then
	export DB_APN=`sqlite3 "${WEB_APP_DB_PATH}" "select apn from wan_setting where id=1"`
	echo "New APN: ${DB_APN}"
	export DB_USR_NAME=`sqlite3 "${WEB_APP_DB_PATH}" "select username from wan_setting where id=1"`
	echo "New User Name: ${DB_USR_NAME}"
	export DB_PASS_WRD=`sqlite3 "${WEB_APP_DB_PATH}" "select password from wan_setting where id=1"`
	echo "New Password: ${DB_PASS_WRD}"

	export DB_2ND_APN=`sqlite3 "${WEB_APP_DB_PATH}" "select apn from wan_setting where id=2"`
	echo "New APN: ${DB_2ND_APN}"
	export DB_2ND_USR_NAME=`sqlite3 "${WEB_APP_DB_PATH}" "select username from wan_setting where id=2"`
	echo "New User Name: ${DB_2ND_USR_NAME}"
	export DB_2ND_PASS_WRD=`sqlite3 "${WEB_APP_DB_PATH}" "select password from wan_setting where id=2"`
	echo "New Password: ${DB_2ND_PASS_WRD}"

	source "${MLB_DIR}/gen-apn-conf.sh"
fi
