#!/usr/bin/python
# import stat
import os
# import Queue
import sys
import time
import logging
from daemon import Daemon
import sqlite3
import csv
from subprocess import Popen
import subprocess
import socket
import json
from keep_alive import KeepAlive

logging.basicConfig(level=logging.NOTSET,
                    filename='/tmp/dev-manager.log',
                    format='%(asctime)s %(message)s')
log = logging.getLogger(__name__)


# WWAN INFORMATION { READ ONLY }
class CellularInfo(object):
    """docstring for LanSettingInfo"""

    def __init__(self, arg):
        super(CellularInfo, self).__init__()
        """
        if arg is not '':
            self.conn_db = sqlite3.connect(arg)
        else:
            self.conn_db = sqlite3.connect('cellular.db')

        self.curr = self.conn_db.cursor()
        self._get_table_keylist()
        """
        self.update_info()

    def update_info(self):
        """
        self.cursor = self.curr.execute(
            "SELECT rssi, ip_addr, mode FROM cellular WHERE id = 1")
        for row in self.cursor:
            self.rssi = row[0]
            self.ip_addr = row[1]
            self.mode = row[2]
        """
        s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        s.connect("/tmp/db.sock")
        send_data = '{"method": "get", "table": "cellular"}'

        s.send(send_data)
        print(send_data)

        data = s.recv(10240)
        data = json.loads(data)

        for itm in data["cellular"]:
            self.rssi = itm["rssi"]
            self.ip_addr = itm["ip_addr"]
            self.mode = itm["mode"]

    def _get_table_keylist(self):
        pass
        """
        self.curr.execute("SELECT * FROM cellular")
        self.curr.fetchall()
        names = [cn[0] for cn in self.curr.description]
        print names
        """

    def get_wwan_ipaddr(self):
        return str(self.ip_addr)

    def chk_wwanip_available(self):
        ipstr = str(self.ip_addr)
        self.wwanip = self.get_wwan_ipaddr()
        log.error("wwan ip: " + self.wwanip)

        if (ipstr == '0.0.0.0') or (ipstr == '192.168.0.1'):
            return False
        else:
            log.debug("chk_wwanip_available, ipstr: " + ipstr)
            return True


# LAN SETTING INFORMATION { READ ONLY }
class SerialSettingInfo(object):
    """docstring for LanSettingInfo"""

    def __init__(self, arg):
        super(SerialSettingInfo, self).__init__()

        """
        if arg is not '':
            self.conn_db = sqlite3.connect(arg)
        else:
            self.conn_db = sqlite3.connect('app.db')

        self.curr = self.conn_db.cursor()
        self._get_table_keylist()

        self.cursor = self.curr.execute(
            "SELECT work_mode, trans_mode, baud_rate, parity, data_bits, stop_bits, ip_addr, port FROM com_setting WHERE id = 1")
        """

        s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        s.connect("/tmp/db.sock")

        send_data = '{"method": "get", "table": "com_setting"}'

        while True:
            s.send(send_data)
            print(send_data)

            data = s.recv(10240)
            data = json.loads(data)
            """
            {u'com_setting': [{u'baud_rate': 115200,
                               u'data_bits': 8,
                               u'id': 1,
                               u'ip_addr': u'',
                               u'parity': u'none',
                               u'port': u'',
                               u'service_mode': 0,
                               u'stop_bits': 1,
                               u'trans_mode': u'232',
                               u'work_mode': u'trans'}],
             u'result': u'success'}
            """
            if data["result"] is "success":
                time.sleep(1)
                continue
            else:
                break

        for itm in data["com_setting"]:
            self.workmode = itm["work_mode"]
            self.transmode = itm["trans_mode"]
            self.baud_rate = itm["baud_rate"]
            self.parity = itm["parity"]
            self.data_bits = itm["data_bits"]
            self.stop_bits = itm["stop_bits"]
            self.server_ipaddr = itm["ip_addr"]
            self.server_port = itm["port"]
            self.service_mode = itm["service_mode"]

    def _get_table_keylist(self):
        pass
        """
        self.curr.execute("SELECT * FROM com_setting")
        self.curr.fetchall()
        names = [cn[0] for cn in self.curr.description]
        print names
        """

    def get_workmode(self):
        return str(self.workmode)

    def get_portype(self):
        return str(self.transmode)

    def get_baudrate(self):
        return str(self.baud_rate)

    def get_conn_ipaddr(self):
        return str(self.server_ipaddr)

    def get_conn_port(self):
        return str(self.server_port)

    def get_service_mode(self):
        self._servicemap = {
            '0': "TCP client",
            '1': "TCP server",
            '2': "UDP service"
        }
        return self._servicemap[str(self.service_mode)]


class status_hwpin (object):
    """docstring for status_hwpin"""

    def __init__(self, arg=''):
        super(status_hwpin, self).__init__()
        self.arg = arg
        self._gpioexport = '/sys/class/gpio/export'
        self._gpiopindef = {
            'TRANS_M0': '46',
            'TRANS_M1': '45',
            'TRANS_M2': '44',
            'TRANS_DIR': '27'
        }
        self._gpioctrlmap = {
            'TRANS_M0': '/sys/class/gpio/gpio46',
            'TRANS_M1': '/sys/class/gpio/gpio45',
            'TRANS_M2': '/sys/class/gpio/gpio44',
            'TRANS_DIR': '/sys/class/gpio/gpio27'
        }
        self._gpiovalmap = {
            # pin funciton by [[filename, value] ... ]
            'SET_ON': [['direction', 'out'], ['value', 1]],
            'SET_OFF': [['direction', 'out'], ['value', 0]],
            'SET_IN': [['direction', 'in'], ['value', 0]]
        }

    # arg = ['LED_READY', 'ON'|'OFF'|'FLASH']
    def _hwpin_set(self, arg):
        pin = arg[0]
        val = arg[1]
        if (pin in self._gpioctrlmap.keys()):
            if (val in self._gpiovalmap.keys()):
                target = self._gpiovalmap[val]
                for itm in target:
                    fn = self._gpioctrlmap[pin] + '/' + itm[0]
                    val = itm[1]
                    print 'path: ' + fn + ', vaule: ' + str(val)
                    fd = open(fn, 'w')
                    fd.write(str(val))
                    fd.close()
            else:
                print 'not found pin value setting in tbl'
        else:
            print 'not found pin path in tbl'

    def comport_config(self, type='232'):
        # initial HW PINs.
        for val in self._gpioctrlmap.keys():
            if not os.path.exists(self._gpioctrlmap[val]):
                fd = open(self._gpioexport, 'w')
                fd.write(self._gpiopindef[val])
                fd.close()

        # config transceiver IC mode.
        if type == '232':
            self._hwpin_set(['TRANS_M0', 'SET_OFF'])
            self._hwpin_set(['TRANS_M1', 'SET_OFF'])
            self._hwpin_set(['TRANS_M2', 'SET_ON'])
        elif type == '485':
            self._hwpin_set(['TRANS_M0', 'SET_ON'])
            self._hwpin_set(['TRANS_M1', 'SET_OFF'])
            self._hwpin_set(['TRANS_M2', 'SET_OFF'])
            self._hwpin_set(['TRANS_DIR', 'SET_OFF'])

        elif type == 'loopback':
            print 'curr not supported.'
            pass
        else:
            # default is 232
            self._hwpin_set(['TRANS_M0', 'SET_OFF'])
            self._hwpin_set(['TRANS_M1', 'SET_OFF'])
            self._hwpin_set(['TRANS_M2', 'SET_ON'])


class DHCPInfo(object):
    """docstring for DHCPInfo"""

    def __init__(self, arg=''):
        super(DHCPInfo, self).__init__()

    def dumpleases2sql(self):

        # Get a dumplease.txt via dumplease.
        ret = subprocess.call("dumpleases -a |sed '1d' > /tmp/dumplease.txt",
                              shell=True)
        if ret != 0:
            sys.exit(ret)

        # Create a database if not exists.
        con = sqlite3.connect('/tmp/status.db')
        cur = con.cursor()

        # Delete table if it exist, and then create it.
        cur.execute("DROP TABLE IF EXISTS LeaseFile;")
        cur.execute(
            "CREATE TABLE LeaseFile(MAC TEXT, IP TEXT, Host TEXT, Expired TEXT)")

        for line in open("/tmp/dumplease.txt", "rb"):
            # Split by width, and strip it.
            mac_addr = line[0:18].strip()
            ip_addr = line[18:30].strip()
            host_name = line[30:45].strip()
            expired = line[45:].strip()

            # Add comma
            line = ''
            line += mac_addr
            line += ', '
            line += ip_addr
            line += ', '
            line += host_name
            line += ', '
            line += expired
            cvsline = []
            cvsline.append(line)

            # Read file by using csv reader.
            reader = csv.reader(cvsline, skipinitialspace=True, delimiter=',')
            data = [row for row in reader]

            # Insert data into table.
            cur.executemany(
                "INSERT INTO LeaseFile(MAC, IP, Host, Expired) VALUES (?, ?, ?, ?);", data)
            con.commit()

        # print "=== This is from QUERY. ==="
        # cur.execute("SELECT MAC, IP, Host, Expired from LeaseFile")
        # for row in cur:
        #     print "MAC = ", row[0]
        #     print "IP = ", row[1]
        #     print "Host = ", row[2]
        #     print "Expired = ", row[3], "\n"

        con.close()


class DevMgrDaemon(Daemon):
    """docstring for manager"""

    def __init__(self, arg=''):
        super(DevMgrDaemon, self).__init__(pidfile='/tmp/dev-manager.pid')
        self.comport_retry = 0
        self.ntp_last_update = time.time()
        self.bckuplog_chckcnt = 10  # every 10 mins, to check one time
        self.first_boot = True  # raise the flag if it is booting first.

    def comport_open(self, type='232', baud_rate='115200', stop_bits='1'):
        self.hwconfig.comport_config(type)

    """
    def update_net_status_proc(self):
        self.cellularinfo = CellularInfo('/tmp/cellular.db')
    """

    def run_backup_log(self):
        if self.bckuplog_chckcnt == 0:
            _cmd = "/usr/sbin/logrotate"
            _arg = "-v"

            _cfg = "/opt/mlis/conf/logrotate-mlis-manager.conf"
            _tcmd = _cmd + ' ' + _arg + ' ' + _cfg
            log.debug(_tcmd)
            p1 = Popen([_cmd, _arg, _cfg], stdout=subprocess.PIPE)
            log.debug(p1.stdout.readlines())

            _cfg = "/opt/mlis/conf/logrotate-messages.conf"
            _tcmd = _cmd + ' ' + _arg + ' ' + _cfg
            log.debug(_tcmd)
            p1 = Popen([_cmd, _arg, _cfg], stdout=subprocess.PIPE)
            log.debug(p1.stdout.readlines())
            self.bckuplog_chckcnt = 10
        else:
            log.debug("bckuplog_chckcnt:" + str(self.bckuplog_chckcnt))
            self.bckuplog_chckcnt = self.bckuplog_chckcnt - 1
        return

    def run_alive_ping(self):
        if self.cellularinfo.chk_wwanip_available() is False:
            log.debug("run_alive_ping, wwanip unavailable")
            return

        try:
            _pf = open('/tmp/keep-alive.pid')
            _pnum = _pf.readlines()
            _pf.close()
            log.debug('keep-alive-bb.pid: ' + str(_pnum))
        except Exception:
            log.debug("starting kee_alive.")
            # self.keep_alive = KeepAlive()
            _keep_alive_path = '/opt/mlis/dev_management/keep_alive.py'
            p1 = Popen(['python', _keep_alive_path], stdout=subprocess.PIPE)
            log.debug(p1.stdout.readlines())
        return

    def run_s2s_exec(self):
        if self.cellularinfo.chk_wwanip_available() is False:
            log.debug("run_s2s_exec, wwanip unavailable")

            if self._chk_s2s_st() is False:
                log.debug("run_s2s_exec, kill proc on sys")
                _tmpcmd = "kill `ps | awk '/[s]erial-socket/{print $1}'`"
                Popen(_tmpcmd, shell=True)
                return

            else:
                log.debug("run_s2s_exec, term proc.")
                self.ser_proc.terminate()
                return

        elif self._chk_s2s_st() is True:
            log.debug("run_s2s_exec, running")
            return
        else:
            dst_ipaddr = self.serialcfg.get_conn_ipaddr()
            dst_ipport = self.serialcfg.get_conn_port()
            baudrate = self.serialcfg.get_baudrate()
            service_mode = self.serialcfg.get_service_mode()

            log.error("Server IP: " + dst_ipaddr)
            log.error("Server Port: " + dst_ipport)

        if (len(dst_ipaddr) == 0) or (len(dst_ipport) == 0):
            log.error("Socket server setting is incompleted, retry: " +
                      str(self.comport_retry))

            # TODO: wakeup period might be to adjusted from web-con.
            self.comport_retry = self.comport_retry + 1
        else:
            _cmd = ['/opt/mlis/bin/serial-socket']

            # running serial2socket program.
            _cmd.append('-a')
            _ipaddr = dst_ipaddr
            _cmd.append(_ipaddr)

            # _portnum = '-p '  # TCP server listen port
            _cmd.append('-p')
            _portnum = dst_ipport
            _cmd.append(_portnum)

            # default, todo: get number from database.
            _clntnum = '5'

            # default, local port.
            _udprmtport = '5003'

            if service_mode == "TCP server":
                _cmd.append('-c')
                _cmd.append(_clntnum)
            elif service_mode == "UDP service":
                _cmd.append('-u')
                _cmd.append(_udprmtport)

            _cmd.append('-o')
            _type = 'type='
            _type += self.serialcfg.get_portype()
            _cmd.append(_type)

            _cmd.append('-o')
            _brate = 'baudrate='
            _brate += baudrate
            _cmd.append(_brate)

            log.error("to run /opt/mlis/bin/serial-socket")
            log.error(str(_cmd))

            log.debug("kill serial-socket")
            Popen("kill -9 `ps | awk '/[s]erial-socket/{print $1}'`",
                  shell=True)

            log.debug("kill serial-config")
            Popen("kill -9 `ps | awk '/[s]erial-config/{print $1}'`",
                  shell=True)

            time.sleep(10.0)
            log.debug("launch serial-socket")
            # self.ser_proc = Popen(_cmd, env={"PATH": "/usr/bin"})
            self.ser_proc = Popen(_cmd)

    def run_ntp_proc(self):
        if self.cellularinfo.chk_wwanip_available():
            # Check if it is first boot,
            # If so, do a ntpd daemon and raise the flag to false.
            # If not, do nothing.
            if self.first_boot:
                Popen("ntpd -g -q pool.ntp.org", shell=True)
                Popen("hwclock -w", shell=True)
                self.first_boot = False

            currtime = time.time()
            timeinterval = currtime - self.ntp_last_update
            if (timeinterval > (3600.0 * 24)):
                Popen("ntpd -g -q pool.ntp.org", shell=True)
                self.ntp_last_update = time.time()

    def _chk_empty_netiface(self):
        nwif_file = '/etc/network/interfaces'
        deft_nwif_file = '/opt/mlis/conf/interfaces'
        nwif_stat = os.stat(nwif_file)
        log.error(nwif_stat.st_size)

        # check filesize is most basic and quick.
        # this is the most critical failure in system.
        if nwif_stat.st_size == 0:
            _cmd = '/bin/mv '
            _cmd += nwif_file
            _cmd += ' '
            _cmd += nwif_file
            _cmd += '.recovery'
            Popen(_cmd, shell=True)

            _cmd = 'cp '
            _cmd += deft_nwif_file
            _cmd += ' '
            _cmd += nwif_file
            Popen(_cmd, shell=True)

            _cmd = '/opt/mlis/web_console/reboot.sh'
            Popen(_cmd, shell=True).wait()
            while (True):
                time.sleep(60)
                log.error("Recovery waiting for reboot.")
        else:
            log.error("network interface not empty")
            # TODO: might be check more detail here.
        return

    def _chk_s2s_st(self):
        try:
            if self.ser_proc.pid is None:
                log.error("no serial-socket process")
                return False
        except Exception:
            print "ser_proc.pid is not existed."
            return False

        # log.error("**** serial program log, start ****")
        # for line in iter(ser_proc.stdout.readline, b''):
            # sys.stdout.write(line)
            # log.error(line)
        # log.error("**** serial program log, end ****")
        # TODO: wakeup period might be to adjusted from web-con.
        ret = self.ser_proc.poll()
        if ret is not None:
            log.error("serial process is ended, exit code: " + str(ret))
            return False
        else:
            return True

    def run(self):
        self._run()

    def _run(self):
        # only for 1st connecting on bootup.
        """
        log.debug("DevMgrDaemon run(), sleep 20sec.")
        time.sleep(20)
        """

        log.debug("DevMgrDaemon run()")

        while not os.path.exists('/tmp/app.db'):
            time.sleep(1)
            log.debug("waiting for /tmp/app.db")

        self.serialcfg = SerialSettingInfo('/tmp/app.db')
        while not os.path.exists('/tmp/cellular.db'):
            time.sleep(1)
            log.debug("waiting for /tmp/cellular.db")

        self.cellularinfo = CellularInfo('/tmp/cellular.db')
        self.hwconfig = status_hwpin('')
        self.wwanip = ''
        self.comport_retry = 0
        self.service_mode = ''

        self.dhcpinfo = DHCPInfo()
        self._chk_empty_netiface()

        while True:

            # starup serial to socket, serial config (MCCP) or serial console.
            mode = self.serialcfg.get_workmode()
            port_type = self.serialcfg.get_portype()
            self.comport_open(type=port_type)
            self.run_alive_ping()

            if mode == 'trans':
                if self.comport_retry > 10:
                    log.error("reached max retry count")
                else:
                    self.run_s2s_exec()

            elif mode == 'mccp':
                # runnnig serial config
                log.debug("running MCCP mode")
                # ser_proc = Popen("/opt/mlis/bin/serial-config&", shell=True)

            elif mode == 'CLI console':
                # TODO function.
                pass

            self.dhcpinfo.dumpleases2sql()
            self.run_ntp_proc()
            self.run_backup_log()
            self.cellularinfo.update_info()

            time.sleep(60.0)

        # end of while True loop
        log.debug("Exiting run loop")


if __name__ == "__main__":

    logging.basicConfig(level=logging.NOTSET, filename='/tmp/dev-manager.log',
                        format='%(asctime)s %(message)s')

    # daemon = MdmMgrDaemon(arg=devpath)
    # development version, need more log to debug.
    daemon = DevMgrDaemon(arg='')

    if len(sys.argv) == 2:
        if 'start' == sys.argv[1]:
            daemon.start()
        elif 'debug' == sys.argv[1]:
            daemon.start(daemon=False)
        elif 'stop' == sys.argv[1]:
            daemon.stop()
        elif 'restart' == sys.argv[1]:
            daemon.restart()
        else:
            print "Unknown command"
            log.error('Unknown command: ' + sys.argv[1])
            sys.exit(2)

        sys.exit(0)
    else:
        print "usage: %s start|stop|restart" % sys.argv[0]
        sys.exit(2)
