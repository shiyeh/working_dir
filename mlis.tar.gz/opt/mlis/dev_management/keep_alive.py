#!/usr/bin/python
import os
import sys
import sqlite3
import time
import subprocess
import init_env
from daemon import Daemon
import logging

log = logging.getLogger(__name__)


class KeepAlive(Daemon):
    """docstring for KeepAlive"""

    def __init__(self, lastPingTime=0, count=0):
        super(KeepAlive, self).__init__(pidfile='/tmp/keep-alive.pid')

        self.lastPingTime = lastPingTime
        self.count = count

    def _bckup_logs(self):
        logfiles_lst = ['/tmp/dev-manager.log',
                        '/tmp/mdm-manager.log',
                        '/tmp/keep-alive.log',
                        '/var/log/messages']

        # make dir with timestamp string.
        # copy log files to folder.
        _cmd = 'mkdir'
        _dstdir = '/opt/log/'
        _dstdir += 'ping-reboot-'
        _dstdir += time.strftime("%Y%m%d%H%M%S", time.localtime())
        log.debug(_cmd + ' ' + _dstdir)

        p1 = subprocess.Popen([_cmd, _dstdir], stdout=subprocess.PIPE)
        log.debug(p1.stdout.readlines())

        _cmd = 'cp'
        _dstfile = _dstdir + '/.'
        for srcfile in logfiles_lst:
            log.debug(_cmd + ' ' + srcfile + ' ' + _dstfile)
            p1 = subprocess.Popen([_cmd, srcfile, _dstfile],
                                  stdout=subprocess.PIPE)
            log.debug(p1.stdout.readlines())

    def run(self):
        try:
            while True:
                # Connect to database
                con = sqlite3.connect(os.environ["WEB_APP_DBTMP_PATH"])
                cur = con.cursor()

                # Reading the hostname and time interval that can be user specific
                # via web console.
                hostTmp = cur.execute(
                    "select ping_addr from lan_setting;").fetchone()
                hostName = str(hostTmp[0])

                intervalTmp = cur.execute(
                    "select ping_intvl from lan_setting;").fetchone()
                timeSpec = int(intervalTmp[0])

                # Record the current time,
                # and calcute the time interval.
                currTime = time.time()
                timeInterval = currTime - self.lastPingTime

                try:
                    # Ping the specific hostname when the time gap is
                    # greater than users specify.
                    if timeInterval >= timeSpec:
                        response = subprocess.check_call(
                            "ping -c2 " + hostName, shell=True)

                        if response == 0:
                            log.debug('Ping %s successful.' % hostName)
                            self.count = 0

                        self.lastPingTime = time.time()
                except Exception:
                    """ If ping failed count to 3, reboot the system. """
                    self.count += 1
                    log.debug('Count = ' + str(self.count))
                    print 'Count = ', self.count

                    if self.count >= 3:
                        print 'Count to ' + str(self.count) + ', it will reboot.'
                        self._bckup_logs()
                        os.system('/sbin/reboot')
                        sys.exit(1)

                con.close()
                time.sleep(1)
        except Exception:
            log.exception('Keep_alive is not run.')


if __name__ == '__main__':
    logging.basicConfig(level=logging.NOTSET, filename='/tmp/keep-alive.log',
                        format='%(asctime)s %(message)s')

    p = KeepAlive()
    p.start()

    # while True:
    #     time.sleep(1)
    #     print time.time()
