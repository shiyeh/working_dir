#!/bin/sh

source init-mlb-env.sh

if [ -f "${WEB_APP_DB_PATH}" ]
then
	export IPTBL_FILTER_RULES=""
	export IPTBL_NAT_RULES=""
	export MLB_IFACE="ppp0"
	
	BACKUP_PATH="${MLB_PPP_NAT_PATH}"

	MLB_PPP_NAT_PATH="${MLB_CONF_DIR}/${MLB_PPP_NAT_CFG}"
	MLB_IFACE="ppp0"

    # blocking new http connection from Public IP/WWAN interface.
    TMP_RULES="-p tcp -s 0/0 --sport 1024:65535 -d 0/0 --dport 80 -m state --state NEW -j DROP"
    IPTBL_FILTER_RULES+="-A INPUT -i ${MLB_IFACE} ${TMP_RULES}"
    IPTBL_FILTER_RULES+=$'\n'
    # blocking new ssh connection from Public IP/WWAN interface.
    TMP_RULES="-p tcp -s 0/0 --sport 1024:65535 -d 0/0 --dport 22 -m state --state NEW -j DROP"
    IPTBL_FILTER_RULES+="-A INPUT -i ${MLB_IFACE} ${TMP_RULES}"
    IPTBL_FILTER_RULES+=$'\n'
    # blocking new icmp connection from Public IP/WWAN interface.
    TMP_RULES="-p icmp --icmp-type 8 -s 0/0 -d 0/0 -m state --state NEW -j DROP"
    IPTBL_FILTER_RULES+="-A INPUT -i ${MLB_IFACE} ${TMP_RULES}"
    IPTBL_FILTER_RULES+=$'\n'
    
	for indx in {1..5}
	do 
		rule="select active from port_forwarding where id=${indx}"
		DB_NAT_PORTFW_EN=`sqlite3 "${WEB_APP_DB_PATH}" "${rule}"`
		if [ "${DB_NAT_PORTFW_EN}" = 1 ]
		then
			rule="select ip from port_forwarding where id=${indx}"
			DB_NAT_PORTFW_IP=`sqlite3 "${WEB_APP_DB_PATH}" "${rule}"`
			rule="select public_port from port_forwarding where id=${indx}"
			DB_NAT_PORTFW_PUBLIC=`sqlite3 "${WEB_APP_DB_PATH}" "${rule}"`
			rule="select internal_port from port_forwarding where id=${indx}"
			DB_NAT_PORTFW_INTERNAL=`sqlite3 "${WEB_APP_DB_PATH}" "${rule}"`
			rule="select protocol from port_forwarding where id=${indx}"
			DB_NAT_PORTFW_PROTOCOL=`sqlite3 "${WEB_APP_DB_PATH}" "${rule}"`

			IPTBL_FILTER_RULES+="-A FORWARD -d ${DB_NAT_PORTFW_IP}/32 -p ${DB_NAT_PORTFW_PROTOCOL} -m ${DB_NAT_PORTFW_PROTOCOL} --dport ${DB_NAT_PORTFW_INTERNAL} -m state --state NEW,RELATED,ESTABLISHED -j ACCEPT"
			IPTBL_FILTER_RULES+=$'\n'

			IPTBL_NAT_RULES+="-A PREROUTING -i ${MLB_IFACE} -p ${DB_NAT_PORTFW_PROTOCOL} -m ${DB_NAT_PORTFW_PROTOCOL} --dport ${DB_NAT_PORTFW_PUBLIC} -j DNAT --to-destination ${DB_NAT_PORTFW_IP}:${DB_NAT_PORTFW_INTERNAL}"
			IPTBL_NAT_RULES+=$'\n'
		fi
	done

	IPTBL_FILTER_RULES+="-A FORWARD -i eth0 -o ${MLB_IFACE} -j ACCEPT"
	IPTBL_FILTER_RULES+=$'\n'
	IPTBL_NAT_RULES+="-A POSTROUTING -o ${MLB_IFACE} -j MASQUERADE"	
	IPTBL_NAT_RULES+=$'\n'

	echo "${IPTBL_FILTER_RULES}"
	echo "${IPTBL_NAT_RULES}"
	source gen-iptables-conf.sh

	### gen for wwan. (stupid code) 
	MLB_PPP_NAT_PATH="${MLB_CONF_DIR}/${MLB_WWAN_NAT_CFG}"
	MLB_IFACE="wwan1"
	IPTBL_FILTER_RULES=""
	IPTBL_NAT_RULES=""

    # blocking new http connection from Public IP/WWAN interface.
    TMP_RULES="-p tcp -s 0/0 --sport 1024:65535 -d 0/0 --dport 80 -m state --state NEW -j DROP"
    IPTBL_FILTER_RULES+="-A INPUT -i ${MLB_IFACE} ${TMP_RULES}"
    IPTBL_FILTER_RULES+=$'\n'
    # blocking new ssh connection from Public IP/WWAN interface.
    TMP_RULES="-p tcp -s 0/0 --sport 1024:65535 -d 0/0 --dport 22 -m state --state NEW -j DROP"
    IPTBL_FILTER_RULES+="-A INPUT -i ${MLB_IFACE} ${TMP_RULES}"
    IPTBL_FILTER_RULES+=$'\n'
    # blocking new icmp connection from Public IP/WWAN interface.
    TMP_RULES="-p icmp --icmp-type 8 -s 0/0 -d 0/0 -m state --state NEW -j DROP"
    IPTBL_FILTER_RULES+="-A INPUT -i ${MLB_IFACE} ${TMP_RULES}"
    IPTBL_FILTER_RULES+=$'\n'

	for indx in {1..5}
	do 
		rule="select active from port_forwarding where id=${indx}"
		DB_NAT_PORTFW_EN=`sqlite3 "${WEB_APP_DB_PATH}" "${rule}"`
		if [ "${DB_NAT_PORTFW_EN}" = 1 ]
		then
			rule="select ip from port_forwarding where id=${indx}"
			DB_NAT_PORTFW_IP=`sqlite3 "${WEB_APP_DB_PATH}" "${rule}"`
			rule="select public_port from port_forwarding where id=${indx}"
			DB_NAT_PORTFW_PUBLIC=`sqlite3 "${WEB_APP_DB_PATH}" "${rule}"`
			rule="select internal_port from port_forwarding where id=${indx}"
			DB_NAT_PORTFW_INTERNAL=`sqlite3 "${WEB_APP_DB_PATH}" "${rule}"`
			rule="select protocol from port_forwarding where id=${indx}"
			DB_NAT_PORTFW_PROTOCOL=`sqlite3 "${WEB_APP_DB_PATH}" "${rule}"`

			IPTBL_FILTER_RULES+="-A FORWARD -d ${DB_NAT_PORTFW_IP}/32 -p ${DB_NAT_PORTFW_PROTOCOL} -m ${DB_NAT_PORTFW_PROTOCOL} --dport ${DB_NAT_PORTFW_INTERNAL} -m state --state NEW,RELATED,ESTABLISHED -j ACCEPT"
			IPTBL_FILTER_RULES+=$'\n'

			IPTBL_NAT_RULES+="-A PREROUTING -i ${MLB_IFACE} -p ${DB_NAT_PORTFW_PROTOCOL} -m ${DB_NAT_PORTFW_PROTOCOL} --dport ${DB_NAT_PORTFW_PUBLIC} -j DNAT --to-destination ${DB_NAT_PORTFW_IP}:${DB_NAT_PORTFW_INTERNAL}"
			IPTBL_NAT_RULES+=$'\n'
		fi
	done

	IPTBL_FILTER_RULES+="-A FORWARD -i eth0 -o ${MLB_IFACE} -j ACCEPT"
	IPTBL_FILTER_RULES+=$'\n'
	IPTBL_NAT_RULES+="-A POSTROUTING -o ${MLB_IFACE} -j MASQUERADE"	
	IPTBL_NAT_RULES+=$'\n'
	echo "${IPTBL_FILTER_RULES}"
	echo "${IPTBL_NAT_RULES}"
	source gen-iptables-conf.sh

	MLB_PPP_NAT_PATH="${BACKUP_PATH}"
fi
