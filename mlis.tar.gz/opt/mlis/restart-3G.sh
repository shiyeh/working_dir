#!/bin/sh
MODEM=/dev/ttyACM3
echo ${MODEM}
until [ ! -e ${MODEM} ]
do 
	echo -e "AT^SMSO\r\n" > ${MODEM}
	#echo $(cat "${MODEM}")
	echo "restart module ${MODEM}"
	sleep 3
done

until [ -e ${MODEM} ]
do
	echo "wait 5sec for 3G module."	
	sleep 5
done
sleep 3
echo "3G module ready."

