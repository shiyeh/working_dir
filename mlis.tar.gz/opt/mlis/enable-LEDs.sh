#!/bin/sh

if [ "$#" = 0 ]; then
	echo "must have choose on or off."
else
	case $1 in
		ON | on )           
			echo "LEDs ON"
 			onoff=1
 			;;
 		OFF | off )
			echo "LEDs ON"		
 			onoff=0
 			;;
        * )
        	echo "arg must be [ON|on] or [OFF|off]"
			exit 1
	esac
fi

LED_S3=/sys/class/leds/mlb:86
LED_S2=/sys/class/leds/mlb:87
LED_S1=/sys/class/leds/mlb:89
LED_4G=/sys/class/leds/mlb:117
LED_3G=/sys/class/leds/mlb:110
LED_FAIL=/sys/class/leds/mlb:111
LED_READY=/sys/class/leds/mlb:112
LED_SIM1=/sys/class/leds/mlb:113
LED_SIM2=/sys/class/leds/mlb:114

if [ -d "${LED_S3}" ]; then
	echo "Led S3: ${LED_S3}"
	if [ $onoff = 1 ]; then
		VALUE=`cat "${LED_S3}"/max_brightness`
	else
		VALUE=0
	fi
	echo "brightness is ${VALUE}"
	echo ${VALUE} > "${LED_S3}/brightness"
fi
if [ -d "${LED_S2}" ]; then
	echo "Led S2: ${LED_S2}"
	if [ $onoff = 1 ]; then
		VALUE=`cat "${LED_S2}"/max_brightness`
	else
		VALUE=0
	fi
	echo "brightness is ${VALUE}"
	echo ${VALUE} > "${LED_S2}/brightness"
fi

if [ -d "${LED_S1}" ]; then
	echo "Led S1: ${LED_S1}"
	if [ $onoff = 1 ]; then
		VALUE=`cat "${LED_S1}"/max_brightness`
	else
		VALUE=0
	fi
	echo "brightness is ${VALUE}"
	echo ${VALUE} > "${LED_S1}/brightness"
fi

if [ -d "${LED_4G}" ]; then
	echo "Led 4G: ${LED_4G}"
	if [ $onoff = 1 ]; then
		VALUE=`cat "${LED_4G}"/max_brightness`
	else
		VALUE=0
	fi
	echo "brightness is ${VALUE}"
	echo ${VALUE} > "${LED_4G}/brightness"
fi

if [ -d "${LED_3G}" ]; then
	echo "Led 3G: ${LED_3G}"
	if [ $onoff = 1 ]; then
		VALUE=`cat "${LED_3G}"/max_brightness`
	else
		VALUE=0
	fi
	echo "brightness is ${VALUE}"
	echo ${VALUE} > "${LED_3G}/brightness"
fi

if [ -d "${LED_FAIL}" ]; then
	echo "Led FAIL: ${LED_FAIL}"
	if [ $onoff = 1 ]; then
		VALUE=`cat "${LED_FAIL}"/max_brightness`
	else
		VALUE=0
	fi
	echo "brightness is ${VALUE}"
	echo ${VALUE} > "${LED_FAIL}/brightness"
fi

if [ -d "${LED_READY}" ]; then
	echo "Led READY: ${LED_READY}"
	if [ $onoff = 1 ]; then
		VALUE=`cat "${LED_READY}"/max_brightness`
	else
		VALUE=0
	fi
	echo "brightness is ${VALUE}"
	echo ${VALUE} > "${LED_READY}/brightness"
fi

if [ -d "${LED_SIM1}" ]; then
	echo "Led SIM1: ${LED_SIM1}"
	if [ $onoff = 1 ]; then
		VALUE=`cat "${LED_SIM1}"/max_brightness`
	else
		VALUE=0
	fi
	echo "brightness is ${VALUE}"
	echo ${VALUE} > "${LED_SIM1}/brightness"
fi

if [ -d "${LED_SIM2}" ]; then
	echo "Led SIM2: ${LED_SIM2}"
	if [ $onoff = 1 ]; then
		VALUE=`cat "${LED_SIM2}"/max_brightness`
	else
		VALUE=0
	fi
	echo "brightness is ${VALUE}"
	echo ${VALUE} > "${LED_SIM2}/brightness"
fi
