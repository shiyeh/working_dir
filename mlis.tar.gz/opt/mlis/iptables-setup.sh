#!/bin/sh

echo "1" > /proc/sys/net/ipv4/conf/ppp0/forwarding 
echo "1" > /proc/sys/net/ipv4/conf/eth0/forwarding

set -x
iptables -t nat -A PREROUTING -p tcp -i ppp0 --dport 80 -j DNAT --to-destination 10.0.10.21:80
iptables -A FORWARD -p tcp -d 10.0.10.21 --dport 80 -m state --state NEW,ESTABLISHED,RELATED -j ACCEPT

iptables -A FORWARD -i eth0 -o ppp0 -j ACCEPT
iptables -t nat -A POSTROUTING -o ppp0 -j MASQUERADE
