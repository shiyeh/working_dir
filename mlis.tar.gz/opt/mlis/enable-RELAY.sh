#!/bin/sh

GPIO_EXP="/sys/class/gpio/export"
GPIO_RELAY="/sys/class/gpio/gpio26"
DIR=out
if [ "$#" = 0 ]; then
	echo "Enable ${GPIO_RELAY}"
	onoff=1
else
	case $1 in
		on | ON | 1 )           
			echo "Enable ${GPIO_RELAY}"
 			onoff=1
 			;;
 		off | OFF | 0 )
			echo "Disable ${GPIO_RELAY}"		
 			onoff=0
 			;;
        * )
        	echo "arg must be [on|ON|1] or [off|OFF|0]"
			exit 1
	esac
fi

if [ -d "${GPIO_RELAY}" ]
then
	echo "detected ${GPIO_RELAY}"
else 
	echo 26 > "${GPIO_EXP}"
	echo "open ${GPIO_RELAY}"
fi

echo "${DIR}" > "${GPIO_RELAY}/direction"
cat "${GPIO_RELAY}/direction"

echo "${onoff}" > "${GPIO_RELAY}/value"
cat "${GPIO_RELAY}/value"