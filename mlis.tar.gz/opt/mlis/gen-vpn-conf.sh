#!/bin/sh

### Generate /opt/mlis/conf/ipsec.conf file.
cat > "${MLB_VPN_CFG_PATH}" << EOL
#!/bin/sh
# Begin ${MLB_VPN_CFG_PATH}
# ipsec.conf - strongSwan IPsec configuration file

# basic configuration

config setup
        # strictcrlpolicy=yes
        # uniqueids = no

# Add connections here.

conn %default
        mobike=no
        keyingtries=%forever

${VPN_IPSEC_CONF_RULES}

# End ${MLB_VPN_CFG_PATH}
EOL

cp -f "${MLB_VPN_CFG_PATH}" "${SYS_VPN_CFG}"
####### End to config "/opt/mlis/conf/ipsec.conf" 

### Generate /opt/mlis/conf/ipsec.secrets file.

cat > "${MLB_VPN_SECRETS_PATH}" << EOL
#!/bin/sh
# Begin ${MLB_VPN_SECRETS_PATH}
# /etc/ipsec.secrets - strongSwan IPsec secrets file

${VPN_IPSEC_SECRETS_RULES}

# End ${MLB_VPN_SECRETS_PATH}
EOL

cp -f "${MLB_VPN_SECRETS_PATH}" "${SYS_VPN_SECRETS}"
######## End to config "/opt/mlis/conf/ipsec.secrets" 
