$(window).on("load", function(){
  var middle_resize = function() {
    var bannerHeight = $(window).height() - $("#banner").height() - 43;
    $("#middleFrame").height(bannerHeight);
    $("#loginFrame").height(bannerHeight);
  };

  middle_resize();

  $(window).resize(function(){
    middle_resize()
  });

  $(".menu").click(function() {
    $(this).next().fadeToggle();
  });

  $(".sub-menu").click(function() {
    $(this).next().fadeToggle();
  });

  $.ajaxSetup ({
    cache: false
  });

  $("a,#logout").click(function(){
    $("body").css('cursor', 'wait');
    $("#mainpage").load($(this).attr("data-link"), function(data, status) {
      if(status == "error") {
        window.location.href = '/';
      }
    })
  });

  $("a,#logout").click(function(){
    $("[class='menu_current']").addClass("menu").removeClass("menu_current");
    $("[class='sub-menu_current']").addClass("sub-menu").removeClass("sub-menu_current");
    $("[class='T-menu_current']").addClass("T-menu").removeClass("T-menu_current");
    if ($(this).hasClass("menu")){
      $(this).addClass("menu_current").removeClass("menu");
    };
    if ($(this).hasClass("sub-menu")){
      $(this).parent().prev(".menu").addClass("menu_current").removeClass("menu");
      $(this).addClass("sub-menu_current").removeClass("sub-menu");
    };
    if ($(this).hasClass("T-menu")){
      var path = $(this).parent().prev(".sub-menu");
      path.addClass("sub-menu_current").removeClass("sub-menu");
      path.parent().prev(".menu").addClass("menu_current").removeClass("menu");
      $(this).addClass("T-menu_current").removeClass("T-menu");
    };
  });

  $("#menu-toggle").click(function(){
    if ($("#sidebar").css("left") == "-220px"){
      $("#mainpage").animate({left: "220px"});
      $("#sidebar").animate({left: "0px"});
      $('body, .btn, :button').css('cursor', 'default');
    }
    else {
      $("#mainpage").animate({left: "0px"});
      $("#sidebar").animate({left: "-220px"});
      $('body, .btn, :button').css('cursor', 'default');
    }
  });

  $('.ip_address').mask('099.099.099.099');
  $(".mac_address").mask("HH:HH:HH:HH:HH:HH");
  $( ".port" ).mask('09999');

  // serialize form to JSON object
  (function ($) {
    $.fn.serializeFormJSON = function () {

        var o = {};
        var a = this.serializeArray();
        $.each(a, function () {
            if (o[this.name]) {
                if (!o[this.name].push) {
                    o[this.name] = [o[this.name]];
                }
                o[this.name].push(this.value || '');
            } else {
                o[this.name] = this.value || '';
            }
        });
        return o;
    };
  })(jQuery);
});

var btn_wait = function() {
  $('#msg').remove();
  $('body, .btn, :button').css('cursor', 'wait');
};
var btn_return = function() {
  $('body, .btn, :button').css('cursor', 'default');
}
var return_success = function () {
  $('body, .btn, :button').css('cursor', 'default');
  if (document.getElementById('msg')) {
    $('#msg').remove();
  };
  $('.btn').after("<span id='msg'> &nbsp;&nbsp;*Need to click <b>Save</b>" +
  " button after you set ready. All settings will be applied.</span>")
};

var check_ip = function() {
  $('.invalid').remove();
  var ip_array = $('.ip_address:not(:disabled)');
  for (i=0;i<ip_array.length;i++) {
    if($(ip_array[i]).val().length == 0) {
      continue;
    }
    var ip_split = $(ip_array[i]).val().split(".");
    if (ip_split.length != 4) {
      $(ip_array[i]).after("<span class='invalid' style='color:red'>invalid</span>");
      continue;
    }
    else {
      for (x=0;x<4;x++) {
        if (ip_split[x] > 255 | ip_split[x] == '') {
          $(ip_array[i]).after("<span class='invalid' style='color:red'>invalid</span>");
          break;
        }
      }
    }
  }

  var port_array = $('.port');
  for (i=0;i<port_array.length;i++) {
    if ($(port_array[i]).val() > 65535) {
      $(port_array[i]).after("<span class='invalid' style='color:red'>invalid</span>");
      continue;
    }
  }

  if ($('.invalid').length == 0) {return true;}
  else {return false;}
}


function submit_data(url, data) {
  $.ajax({
    type:         "POST",
    contentType:  "application/json; charset=utf-8",
    url:          url,
    data:         data,
    error:        function() {
                    window.location.href = '/';
                  },
    success:      function (result) {
                    if (result == 'success') {
                      return_success();
                    }
                  },
  });
}

var timeout;
function keepMeAlivePls() {
  $.getJSON('/');
  clearTimeout(timeout);
  timeout = setTimeout("keepMeAlivePls()", 30000);
}
