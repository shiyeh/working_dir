import os
import mimetypes
import subprocess

from flask import Flask, g
from flask.ext.login import LoginManager
from flask.ext.sqlalchemy import SQLAlchemy


def source_mlb_env():
    command = ['bash', '-c', 'source ../init-mlb-env.sh && env']
    proc = subprocess.Popen(command, stdout=subprocess.PIPE)
    for line in proc.stdout:
        (key, _, value) = line.partition("=")
        os.environ[key] = value
    proc.communicate()

mimetypes.add_type('image/svg+xml', '.svg')
# source_mlb_env()

app = Flask(__name__)
basedir = os.path.abspath(os.path.dirname(__file__))
web_console_dir = os.path.abspath(os.path.join(basedir, os.path.pardir))
mlis_dir = os.path.abspath(os.path.join(web_console_dir, os.path.pardir))

app.config['SRF_ENABLED'] = True
app.config['SECRET_KEY'] = 'Schmidt-Web-Console-SecretKey'

# ===================LoginManager==============================================
login_manager = LoginManager()
login_manager.init_app(app)

# ===================Update folder=============================================
# This is the path to the upload directory
app.config['FW_UPLOAD_FOLDER'] = os.path.join(basedir, '/tmp/')
app.config['OPENVPN_UPLOAD_FOLDER'] = os.environ.get(
                'MLB_OPENVPN_CONF_DIR',
                os.path.join(mlis_dir, 'conf/openvpn')).strip('\n')
app.config['CA_UPLOAD_FOLDER'] = os.environ.get(
                'SYS_VPN_CAS_DIR', '/etc/ipsec.d/cacerts').strip('\n')

# These are the extension that we are accepting to be uploaded
app.config['FW_ALLOWED_EXTENSIONS'] = set(['fw'])
app.config['OPENVPN_ALLOWED_EXTENSIONS'] = set(['conf', 'ovpn'])
app.config['CACERT_ALLOWED_EXTENSIONS'] = set(['der', 'pem'])
app.config['EECERT_ALLOWED_EXTENSIONS'] = set(['der', 'pem'])
app.config['SETTING_ALLOWED_EXTENSIONS'] = set(['json'])

# ===================SQLAlchemy================================================
# track_modifications = app.config.setdefault(
#    'SQLALCHEMY_TRACK_MODIFICATIONS', True)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:////tmp/app.db'
app.config['SQLALCHEMY_BINDS'] = {
    'status': 'sqlite:///' + os.path.join(basedir, 'status.db'),
    'cellular': 'sqlite:////tmp/cellular.db',
}
# ===================CA cert path==============================================
app.config['SYS_VPN_CA_CERT_PATH'] = os.environ.get(
                'SYS_VPN_CA_CERT_PATH',
                "/etc/ipsec.d/cacerts/caCert.der").strip('\n')

# ===================EE Key dir================================================
app.config['SYS_VPN_PRIVATE_KEY_DIR'] = os.environ.get(
                'SYS_VPN_PRIVATE_KEY_DIR',
                "/etc/ipsec.d/private").strip('\n')

# ===================EE cert dir===============================================
app.config['SYS_VPN_EE_CERTS_LOCAL_DIR'] = os.environ.get(
                'SYS_VPN_EE_CERTS_LOCAL_DIR',
                "/etc/ipsec.d/certs/local").strip('\n')

app.config['SYS_VPN_EE_CERTS_REMOTE_DIR'] = os.environ.get(
                'SYS_VPN_EE_CERTS_REMOTE_DIR',
                "/etc/ipsec.d/certs/remote").strip('\n')
# ===================MLB-init==================================================
app.config['MLB_INIT_PATH'] = os.environ.get(
                'MLB_INIT_PATH',
                os.path.join(mlis_dir, 'conf/init-G420x')).strip('\n')

db = SQLAlchemy(app)
app.debug = True

from app import views, models
