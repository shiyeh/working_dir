from datetime import timedelta
import os
import json
import time
import socket
import zipfile
# import pdb

from flask import render_template, request, url_for, redirect, jsonify
from flask import g, send_file
# from flask import session, make_response, flash

from werkzeug import secure_filename
from werkzeug.security import check_password_hash
from app import app, login_manager, models
from flask.ext.login import current_user, fresh_login_required
from flask.ext.login import login_user, logout_user
# from flask.ext.login import login_required

model = {
            "G4201": models.G4201(),
            "G4202": models.G4202(),
            "noneTemp": models.noneTemp(),
            "ISON": models.ISON(),
        }


# (updateFW) For a given file, return whether it's an allowed type or not
def allowed_file(filename, allowed_file):
    if allowed_file is "fw":
        allowed_extensions = app.config['FW_ALLOWED_EXTENSIONS']
    elif allowed_file is "openvpn":
        allowed_extensions = app.config['OPENVPN_ALLOWED_EXTENSIONS']
    elif allowed_file is "eeCerts":
        allowed_extensions = app.config['EECERT_ALLOWED_EXTENSIONS']
    elif allowed_file is "caCerts":
        allowed_extensions = app.config['CACERT_ALLOWED_EXTENSIONS']
    elif allowed_file is "settings":
        allowed_extensions = app.config['SETTING_ALLOWED_EXTENSIONS']
    else:
        allowed_extensions = set([])
    bool_allow = '.' in filename and \
                 filename.rsplit('.', 1)[1] in allowed_extensions
    return bool_allow


# make dict of path for jsTree
def path_to_dict(path):
    d = {'text': os.path.basename(path)}
    d['abspath'] = path
    if os.path.isdir(path):
        d['type'] = "directory"
        d['icon'] = "jstree-folder"
        d['children'] = [path_to_dict(os.path.join(path,x)) for x in os.listdir\
                            (path)]
    else:
        d['type'] = "file"
        d['icon'] = "jstree-file"
    return d


@login_manager.user_loader
def load_user(id):
    user = models.User.query.filter_by(id=id).first()
    return user


@app.before_request
def init_g_variable():
    g.model = model['G4201']


@app.before_request
def make_session_permanent():
    # session.permanent = True
    app.permanent_session_lifetime = timedelta(minutes=5)
    # app.permanent_session_lifetime = timedelta(seconds=10)


@app.before_request
def check_users_permission():
    if current_user.is_authenticated:
        g.permission = current_user.permission
        if current_user.permission > 10:
            if request.path != '/logout':
                if request.method == 'POST':
                    return ("unauthorized"), 401


@login_manager.unauthorized_handler
def unauthorized():
    return ("unauthorized"), 401


@app.route("/test", methods=['GET', 'POST'])
def test():
    if request.method == 'GET':
        return render_template('test.html')


@app.route("/")
def index():
    if not current_user.is_authenticated:
        return render_template('login.html')
    return render_template(
            'sideBar.html',
            user=current_user.get_username())


@app.route("/login", methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.json['username']
        password = request.json['password']
        user = models.User.query.filter_by(username=username).first()
        if user and check_password_hash(str(user.password), password):
            login_user(user)
            return "success"
        return "fail"
    if request.method == 'GET':
        return current_user.get_username()


@app.route("/main")
@fresh_login_required
def main():
    return render_template('sidebar.html')


@app.route("/overview", methods=['GET', 'POST'])
@fresh_login_required
def overview():
    if request.method == 'GET':
        if request.args.get('action') == 'getTime':
            date = os.popen('busybox date').read()[:-1]
            return jsonify(result=date)
        sys = models.SystemInfo.query.filter_by(id='1').first()
        lan = models.LanInfo.query.filter_by(id='1').first()
        cell_info = models.CellularInfo.query.filter_by(id='1').first()
        cell_vars = models.Cellular.query.filter_by(id='1').first()
        # utc time
        nowTime = time.time()
        # timezone time
        date = os.popen('busybox date').read()[:-1]
        return render_template('overview.html',
                               sys=vars(sys), lan=vars(lan),
                               cell_info=vars(cell_info),
                               cell_vars=vars(cell_vars),
                               nowTime=nowTime,
                               date=date)
    if request.method == 'POST':
        if request.json['action'] == 'syncTime':
            os.chdir('..')
            result = os.system('python ./web-update-ntp-sync.py')
            os.chdir('./web_console')
            return jsonify(result='success' if result == 0 else 'fail')


# Basic Settings===============================================================
@app.route("/networkSet", methods=['GET', 'POST'])
@fresh_login_required
def networkSet():
    system_info = models.SystemInfo.query.filter_by(id='1').first()
    lan_info = models.LanInfo.query.filter_by(id='1').first()
    lan = models.LanSetting.query.filter_by(id='1').first()
    dhcp = models.DHCPServer.query.filter_by(id='1').first()
    if request.method == 'GET':
        return render_template(
            'networkSet.html',
            device_name=system_info.device_name,
            timezone=system_info.timezone,
            ip_addr=lan.ip_addr,
            submask=lan.submask,
            dns=lan.dns,
            sec_dns=lan.sec_dns,
            allow_ping=lan.allow_ping,
            ping_addr=lan.ping_addr,
            ping_intvl=lan.ping_intvl)
    if request.method == 'POST':
        payload = request.json
        dns = '8.8.8.8' if request.json['dns'] == "" else request.json['dns']
        sec_dns = '8.8.4.4' if request.json['sec_dns'] \
            == '' else request.json['sec_dns']
        dhcp_data = {}
        dhcp_data['gateway'] = request.json['ip_addr']
        dhcp_data['submask'] = request.json['submask']
        dhcp_data['dns'] = dns
        dhcp_data['sec_dns'] = sec_dns
        dhcp.update_db(dhcp_data)

        lan.ip_addr = request.json['ip_addr']
        lan.submask = request.json['submask']
        lan.dns = dns
        lan.sec_dns = sec_dns
        lan.allow_ping = request.json['allow_ping']
        lan.ping_addr = "8.8.8.8" if request.json['ping_addr'] == "" \
            else request.json['ping_addr']
        lan.ping_intvl = "60" if request.json['ping_intvl'] == "" \
            else request.json['ping_intvl']
        lan.update_db()

        system_info.update_db(payload)
        lan_info.update_db(payload)
        os.chdir('..')
        result = os.system('./web-update-timezone.sh')
        os.chdir('./web_console')
        return "success"


# Cellular Settings============================================================
@app.route("/cellularWANSet", methods=['GET', 'POST'])
@fresh_login_required
def cellularWANSet():
    sim1 = models.WANSetting.query.filter_by(id='1').first()
    sim2 = models.WANSetting.query.filter_by(id='2').first()
    priority = models.WANPrioritySetting.query.filter_by(id='1').first()
    if request.method == 'GET':
        return render_template(
                            'cellularWANSet.html',
                            sim1=sim1.get_vars(),
                            sim2=sim2.get_vars(),
                            pri=priority.get_vars())
    if request.method == 'POST':
        payload = request.get_json()
        sim1_data = {}
        sim2_data = {}
        pri_data = {}
        for key, value in payload.items():
            if type(value) is list:
                sim1_data[key] = '' if value[0] == ' ' else value[0]
                sim2_data[key] = '' if value[1] == ' ' else value[1]
            else:
                pri_data[key] = value
        sim1.update_db(sim1_data)
        sim2.update_db(sim2_data)
        priority.update_db(pri_data)
        return "success"


# Advanced Settings============================================================
@app.route("/DHCPServer", methods=['GET', 'POST'])
@fresh_login_required
def DHCPServer():
    dhcp = models.DHCPServer.query.filter_by(id='1').first()
    if request.method == 'GET':
        # convert to minutes from seconds.
        dhcp.client_time = dhcp.client_time/60
        map_list = []
        for i in range(16):
            map_list.append([])
            mapping = models.DHCPMapping.query.filter_by(id=i+1).first()
            map_list[i].append(mapping.active)
            map_list[i].append(mapping.ip)
            map_list[i].append(mapping.mac)
        return render_template(
            'DHCPServer.html',
            data=dhcp.get_vars(), mapping=map_list)
    if request.method == 'POST':
        data = request.get_json()
        # convert to seconds from minutes.
        data['client_time'] = str(int(data['client_time'])*60)
        data['dhcp_server'] = 1 if data['dhcp_server'] == 'True' else 0
        data['max_users'] = int(data['max_users'])
        for i in range(16):
            mapping = models.DHCPMapping.query.filter_by(id=i+1).first()
            active = data.pop("check" + str(i+1), "0")
            ip = data.pop("ip" + str(i+1), u"")
            mac = data.pop("mac" + str(i+1), u"")
            mapping.update_db(active, ip, mac.upper())
        dhcp.update_db(data)
        return "success"


# Advanced Settings - Packet Filters===========================================
@app.route("/portForwarding", methods=['GET', 'POST'])
@fresh_login_required
def portForwarding():
    if request.method == 'GET':
        fw_list = [[]]
        for i in range(1, 33):
            fw_list.append([])
            fw = models.PortForwarding.query.filter_by(id=i).first()
            fw_list[i].append(fw.active)
            fw_list[i].append(fw.protocol)
            fw_list[i].append(fw.public_port)
            fw_list[i].append(fw.ip)
            fw_list[i].append(fw.internal_port)
        return render_template(
            'portForwarding.html', list=fw_list)
    if request.method == 'POST':
        data = request.get_json()
        for i in range(1, 33):
            fw = models.PortForwarding.query.filter_by(id=i).first()
            active = data.pop("check" + str(i), "0")
            protocol = data.pop("protocol" + str(i), "TCP")
            public_port = data.pop("public_port" + str(i), "")
            ip = data.pop("ip" + str(i), "")
            internal_port = data.pop("internal_port" + str(i), "")
            fw.update_db(active, protocol, public_port, ip, internal_port)
        return "success"


@app.route("/consoleSet", methods=['GET', 'POST'])
@fresh_login_required
def consoleSet():
    service = models.ServiceSetting.query.filter_by(id='1').first()
    if request.method == 'GET':
        return render_template('consoleSet.html', service=vars(service))
    if request.method == 'POST':
        payload = request.json
        service.update_db(payload)
        return "success"


@app.route("/comSetting", methods=['GET', 'POST'])
@fresh_login_required
def comSetting():
    serial = models.comSetting.query.filter_by(id='1').first()
    if request.method == 'GET':
        return render_template('comSetting.html', payload=serial)
    if request.method == 'POST':
        payload = request.get_json()
        serial.update_db(payload)
        return 'success'


@app.route("/snmpAgent", methods=['GET', 'POST'])
@fresh_login_required
def snmpAgent():
    snmp = models.snmpAgent.query.filter_by(id='1').first()
    if request.method == 'GET':
        return render_template('snmpAgent.html', snmp=snmp.get_vars())
    if request.method == 'POST':
        payload = request.get_json()
        snmp.update_db(payload)
        return 'success'


@app.route("/vpnList", methods=['GET', 'POST'])
@fresh_login_required
def vpnList():
    vpn_active = models.VpnActive.query.filter_by(id='1').first()
    openvpn = models.openvpn.query.filter_by(id='1').first()
    if request.method == 'GET':
        vpn_list = []
        for i in range(1, 6):
            vpn = models.Vpn.query.filter_by(id=i).first()
            if vpn._right == '%any':
                vpn._right = ''
            vpn_list.append(vars(vpn))
        return render_template('vpnList.html',
                               vpn=vpn_list,
                               vpn_active=vars(vpn_active),
                               openvpn_active=openvpn.active)
    if request.method == 'POST':
        vpn_active.update_db(request.json['ipsec'])
        return 'success'


@app.route("/vpn", methods=['GET', 'POST'])
@fresh_login_required
def vpn():
    if request.method == 'GET':
        certs_local_dir = app.config['SYS_VPN_EE_CERTS_LOCAL_DIR']
        certs_remote_dir = app.config['SYS_VPN_EE_CERTS_REMOTE_DIR']
        current_id = request.args.get('id')
        vpn = models.Vpn.query.filter_by(id=current_id).first()
        data = vpn.get_vars()

        def netPrefix_to_netmask(subnet):
            try:
                subnet, netprefix = subnet.split('/')
                netmask = ''
                for i in range(int(netprefix)):
                    netmask += '1'
                for i in range(32-int(netprefix)):
                    netmask += '0'
                netmask = [netmask[i:i+8] for i in range(0, len(netmask), 8)]
                netmask = [int(netmask[i], 2) for i in range(len(netmask))]
                netmask = '.'.join(map(str, netmask))
            except ValueError:
                subnet, netmask = '', ''
            return subnet, netmask

        data['leftsubnet'], data['leftmask'] = netPrefix_to_netmask(
                                                            data['leftsubnet'])
        data['rightsubnet'], data['rightmask'] = netPrefix_to_netmask(
                                                        data['rightsubnet'])
        data['ike_encrypt'], data['ike_hash'], data['ike_dh'] = \
            data['ike'][0:-1].split('-')
        # if data['rekey'] == 'yes':
        #     data['lifetime'] = '0h'

        data['lifetime'] = data['lifetime'][0:-1]
        data['esp_encrypt'], data['esp_hash'] = data['esp'][0:-1].split('-')

        data['dpddelay'] = data['dpddelay'][0:-1]
        data['dpdtimeout'] = data['dpdtimeout'][0:-1]

        # data['local_cert_list'] = os.listdir("/tmp".strip('\n'))
        # data['remote_cert_list'] = os.listdir("/etc".strip('\n'))
        data['local_cert_list'] = os.listdir(certs_local_dir.strip('\n'))
        data['remote_cert_list'] = os.listdir(certs_remote_dir.strip('\n'))

        return render_template('vpn.html', data=data, id=current_id)

    if request.method == 'POST':
        vpn_set = request.get_json()
        vpn = models.Vpn.query.filter_by(id=vpn_set['data-id']).first()
        # =================merge subent and submask===========================

        def netmask_to_netPrefix(subnet, prefix):
            try:
                mask = sum([bin(int(x)).count('1') for x in prefix.split('.')])
            except ValueError:
                return ''
            return "{}/{}".format(subnet, str(mask))
        vpn_set['leftsubnet'] = netmask_to_netPrefix(
                                    vpn_set['leftsubnet'], vpn_set['leftmask'])
        vpn_set.pop('leftmask')
        vpn_set['rightsubnet'] = netmask_to_netPrefix(
                                vpn_set['rightsubnet'], vpn_set['rightmask'])
        vpn_set.pop('rightmask')
        # =================merge subent and submask end=======================
        if vpn_set['lifetime'] == '0':
            vpn_set['rekey'] = 'yes'
            vpn_set['lifetime'] = '3'
        # else:
        #     vpn_set['rekey'] = 'no'
        vpn_set['lifetime'] = vpn_set['lifetime'] + 'h'
        # =================merge ike setting==================================
        vpn_set['ike'] = '{}-{}-{}!'.format(vpn_set.pop('ike_encrypt'),
                                            vpn_set.pop('ike_hash'),
                                            vpn_set.pop('ike_dh'))
        # =================merge ike setting end==============================
        # =================merge esp setting==================================
        vpn_set['esp'] = '{}-{}!'.format(vpn_set.pop('esp_encrypt'),
                                         vpn_set.pop('esp_hash'))
        # =================merge esp setting end==============================
        if vpn_set['_right'] == '':
            vpn_set['_right'] = "%any"
        vpn_set['dpddelay'] = vpn_set['dpddelay'] + 's'
        vpn_set['dpdtimeout'] = vpn_set['dpdtimeout'] + 's'
        vpn_set['conn_name'] = vpn_set['conn_name'].split(' ')[0]

        vpn.update_db(vpn_set)
        return "success"


@app.route("/caCert", methods=['GET', 'POST'])
@fresh_login_required
def caCert():
    cacert = models.caCert.query.filter_by(id='1').first()
    if request.method == 'GET':
        payload = cacert.get_vars()
        payload['root_ca_info'] = ''
        if os.path.exists(app.config['SYS_VPN_CA_CERT_PATH']):
            os.system('ipsec pki --print --in ' +
                      app.config['SYS_VPN_CA_CERT_PATH'] +
                      '> /tmp/root_ca_info')
            with open('/tmp/root_ca_info', 'r') as file:
                for line in file:
                    payload['root_ca_info'] += line
        return render_template('caCert.html', cacert=payload)
    if request.method == 'POST':
        if bool(request.form):
            ca_cert = app.config['SYS_VPN_CA_CERT_PATH']
            if request.form['func'] == "root_ca_del":
                if os.path.exists(ca_cert):
                    os.remove(ca_cert)
                return 'success'
            elif request.form['func'] == "root_ca_export":
                if os.path.exists(ca_cert):
                    return "/caCertDownload"
                else:
                    return "root_ca_not_exist"
        elif bool(request.json):
            payload = request.get_json()
            if payload['lifetime'] == "":
                payload['lifetime'] = 1095
            if int(payload['lifetime']) > 7300:
                return "Certificate days must less than 7300 days."
            cacert.update_db(payload)
            os.chdir('..')
            result = os.system('./gen-ca-cert.sh')
            os.chdir('./web_console')
            if result != 0:
                return "At least 1 cell of DN must be set."
            return 'success'


@app.route("/caCertDownload", methods=['GET'])
@fresh_login_required
def caCertDownload():
    return send_file(app.config['SYS_VPN_CA_CERT_PATH'], as_attachment=True)


@app.route("/eeCerts", methods=['GET', 'POST'])
@fresh_login_required
def eeCerts():
    eecert = models.eeCert.query.filter_by(id='1').first()
    certs_local_dir = app.config['SYS_VPN_EE_CERTS_LOCAL_DIR']
    certs_remote_dir = app.config['SYS_VPN_EE_CERTS_REMOTE_DIR']
    certKeys_dir = app.config['SYS_VPN_PRIVATE_KEY_DIR']
    if request.method == 'GET':
        root_ca = True if os.path.exists(
                                app.config['SYS_VPN_CA_CERT_PATH']) else False
        local_cert_list = os.listdir(certs_local_dir.strip('\n'))
        remote_cert_list = os.listdir(certs_remote_dir.strip('\n'))
        local_certs = {}
        remote_certs = {}

        for cert in local_cert_list:
            command = "ipsec pki --print --in {} > /tmp/local_cert_info" \
                        .format(os.path.join(certs_local_dir, cert))
            os.system(command)
            cert = cert.rsplit('.', 1)[0]
            with open('/tmp/local_cert_info', 'r') as file:
                local_certs[cert] = ''
                for line in file:
                    local_certs[cert] += line

        for cert in remote_cert_list:
            command = "ipsec pki --print --in {} > /tmp/remote_cert_info" \
                        .format(os.path.join(certs_remote_dir, cert))
            os.system(command)
            cert = cert.rsplit('.', 1)[0]
            with open('/tmp/remote_cert_info', 'r') as file:
                remote_certs[cert] = ''
                for line in file:
                    remote_certs[cert] += line
        return render_template('eeCerts.html',
                               root_ca=root_ca,
                               local_certs=local_certs,
                               remote_certs=remote_certs)
    if request.method == 'POST':
        if bool(request.files):
            file = request.files['file']
            if file.filename == '':
                return "empty"
            elif file and allowed_file(file.filename, 'eeCerts'):
                filename = secure_filename(file.filename)
                file.save(os.path.join(
                        app.config['SYS_VPN_EE_CERTS_REMOTE_DIR'], filename))
                return 'file_uploaded'
            else:
                return "not_allowed"
        elif bool(request.form):
            target = request.form['target']
            remote_cert = os.path.join(
                                certs_remote_dir, '{}.der'.format(target))
            ee_cert = os.path.join(certs_local_dir, '{}.der'.format(target))
            ee_cert_key = os.path.join(certKeys_dir,
                                       '{}.der'.format(target))
            if request.form['func'] == "cert_del":
                if request.form['location'] == 'local':
                    if os.path.exists(ee_cert):
                        os.remove(ee_cert)
                    if os.path.exists(ee_cert_key):
                        os.remove(ee_cert_key)
                elif request.form['location'] == 'remote':
                    if os.path.exists(remote_cert):
                        os.remove(remote_cert)
                return 'success'
            elif request.form['func'] == "cert_export":
                if os.path.exists(ee_cert):
                    return "/eeCertDownload/{}.der".format(target)
                else:
                    return "root_ca_not_exist"
            return 'success'
        elif bool(request.json):
            payload = request.get_json()
            if payload['ee_name'] == '':
                return "Certificate Name cannot be empty."
            if payload['lifetime'] == "":
                payload['lifetime'] = 365
            if int(payload['lifetime']) > 7300:
                return "Certificate Days must less than 7300 days."
            payload['ee_name'] = payload['ee_name'].strip()
            payload['ee_name'] = payload['ee_name'].split(' ')[0]
            eecert.update_db(payload)
            os.chdir('..')
            result = os.system('./gen-ee-cert.sh')
            os.chdir('./web_console')
            if result != 0:
                return "At least 1 cell of DN must be set."
            return 'success'


@app.route("/eeCertDownload/<filename>", methods=['GET'])
@fresh_login_required
def eeCertDownload(filename):
    filename = os.path.join(app.config['SYS_VPN_EE_CERTS_LOCAL_DIR'], filename)
    return send_file(filename, as_attachment=True)


@app.route("/openvpn", methods=['GET', 'POST'])
@fresh_login_required
def openvpn():
    openvpn = models.openvpn.query.filter_by(id='1').first()
    vpn_active = models.VpnActive.query.filter_by(id='1').first()
    if request.method == 'GET':
        openvpn_dir = app.config['OPENVPN_UPLOAD_FOLDER']
        conf_list = os.listdir(openvpn_dir.strip('\n'))
        conf_list.remove('empty')
        list_len = len(conf_list)
        if not (openvpn.conf in conf_list):
            openvpn.active = False
            openvpn.conf = 'None'
            openvpn.update_db()
        return render_template('openvpn.html',
                               conf_list=conf_list,
                               list_len=list_len,
                               current=openvpn.conf,
                               vpn_active=vpn_active.active)
    if request.method == 'POST':
        if bool(request.files):
            file = request.files['file']
            if file.filename == '':
                return "empty"
            elif file and allowed_file(file.filename, 'openvpn'):
                filename = secure_filename(file.filename)[:-4] + "conf"
                file.save(os.path.join(
                            app.config['OPENVPN_UPLOAD_FOLDER'], filename))
                return 'file_uploaded'
            else:
                return "not_allowed"

        elif bool(request.json):
            conf = request.json['conf']
            if type(conf) is list:
                for conf_name in conf:
                    os.remove(
                            app.config['OPENVPN_UPLOAD_FOLDER']+"/"+conf_name)
                return "edited"
            openvpn.active = False if conf == "None" else True
            openvpn.conf = conf
            openvpn.update_db()
            return "openvpn_updated"
# Advanced Settings - VPN -END-================================================


@app.route("/updateFW", methods=['GET', 'POST'])
@fresh_login_required
def updateFW():
    if request.method == 'GET':
        return render_template('updateFW.html')
    if request.method == 'POST':
        file = request.files['file']
        if file.filename == '':
            return "empty"
        if file and allowed_file(file.filename, 'fw'):
            filename = secure_filename(file.filename)
            file.save(os.path.join(app.config['FW_UPLOAD_FOLDER'], filename))
            os.chdir('..')
            check_file = os.system('python ./update-fw-check.py')
            if check_file == 0:
                logout_user()
                os.system('python ./update-fw-process.py &')
                return 'success'
            else:
                return 'check file fail'
        else:
            return "not allowed"


@app.route("/ping", methods=['GET', 'POST'])
@fresh_login_required
def ping():
    if request.method == 'GET':
        return render_template('ping.html')
    if request.method == 'POST':
        dest = request.json['ping']
        os.system('ping -w 1 ' + dest +
                  ' | while read pong; do echo "$(date): $pong";\
                  done | grep seq > /tmp/ping')
        ping = open("/tmp/ping", 'r')
        ping_result = ping.read()
        ping.close()
        if ping_result == '':
            ping_result = "Request timeout"
        return ping_result


@app.route("/password", methods=['GET', 'POST'])
@fresh_login_required
def password():
    if request.method == 'GET':
        return render_template('password.html')
    if request.method == 'POST':
        curPass = request.json['curPass']
        newPass = request.json['newPass']
        confPass = request.json['confPass']
        password = current_user.get_password()
        if not check_password_hash(password, curPass):
            return "curPassErr"
        if not newPass == confPass:
            return "confPassErr"
        current_user.update_password(newPass)
        logout_user()
        return "success"


@app.route("/usersManage", methods=['GET', 'POST'])
@fresh_login_required
def usersManage():
    _list = ["admin", "guest"]
    users = models.User.query.filter(
                                    models.User.username.notin_(_list)).all()
    if request.method == 'GET':
        user_list = [i.username for i in users]
        return render_template('usersManage.html',
                               user_list=user_list)

    if request.method == 'POST':
        method = request.form['method']
        print(method)
        if method == "del_user":
            target = request.form['target']
            user = models.User.query.filter_by(username=target).first()
            user.delself()
            return "success", 200
        if method == "add_user":
            name = request.form['username']
            user = models.User(username=name)
            user.add()
            return "success", 200


@app.route("/dio", methods=['GET', 'POST'])
@fresh_login_required
def dio():
    io = models.IoStatus.query.filter_by(id='1').first()
    if request.method == 'GET':
        return render_template('dio.html', relay=io.relay)
    if request.method == 'POST':
        if request.form.get('di'):
            di = request.form['di']
            if di == 'di1':
                command = 'cat /sys/class/gpio/gpio22/value'
            elif di == 'di2':
                command = 'cat /sys/class/gpio/gpio23/value'
            result = os.popen(command).readline()[0]
            result = 'High' if result is '1' else 'Low'
            return jsonify(di=di, result=result)
        if request.form.get('relay'):
            relay_on = str(request.form['relay']) == str('true')
            if relay_on:
                os.system('../relay-on.sh')
                io.update_db(1)
            else:
                os.system('../relay-off.sh')
                io.update_db(0)
            return 'success'


@app.route("/atCommand", methods=['GET', 'POST'])
@fresh_login_required
def atCommand():
    import socket
    laninfo = models.LanInfo.query.filter_by(id='1').first()
    lan = laninfo.ip_addr
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(5)
    if request.method == 'GET':
        return render_template('atCommand.html')
    if request.method == 'POST':
        try:
            s.connect((lan, 10001))
            command = request.form['command']
            if request.form['sms'] == 'True':
                command = '{}{}'.format(str(command), '\x1a')
            s.sendall(command)
            payload = s.recv(1024)
            s.close()
            return payload
        except socket.timeout:
            return'AT command is unavailable. please try again later.'


@app.route("/ipsecLog", methods=['GET'])
@fresh_login_required
def ipsecLog():
    if request.method == 'GET':
        try:
            log = open('/tmp/ipsec.log', 'r')
            log_file = log.read()
            log.close()
        except IOError:
            log_file = 'IPsec has been disabled.'
        return render_template('ipsecLog.html', log=log_file)


@app.route("/openvpnLog", methods=['GET'])
@fresh_login_required
def openvpnLog():
    if request.method == 'GET':
        os.system("cat /var/log/messages | grep openvpn > /tmp/openvpn.log")
        # os.system("cat /var/log/messages > /tmp/openvpn.log")
        try:
            log = open('/tmp/openvpn.log', 'r')
            log_file = log.read()
            log.close()
        except IOError:
            log_file = 'OpenVPN has been disabled.'
        if log_file == '':
            log_file = 'OpenVPN has been disabled.'
        return render_template('openvpnLog.html', log=log_file)


@app.route("/log", methods=['GET'])
@fresh_login_required
def log():
    if request.method == 'GET':
        try:
            log = open('/tmp/mdm-manager.log', 'r')
            log_file = log.read()
            log.close()
        except IOError:
            log_file = 'Log file is unavailable!!'
        return render_template('log.html', log=log_file)


@app.route("/logFolder", methods=['GET'])
@fresh_login_required
def logDirectory():
    if request.method == 'GET':
        log_files = json.dumps(path_to_dict('/opt/log'))
        return render_template('logFolder.html', log_files=log_files)


@app.route("/resetDefault", methods=['GET', 'POST'])
@fresh_login_required
def resetDefault():
    if request.method == 'GET':
        return render_template('resetDefault.html')
    if request.method == 'POST':
        result = os.system('./reset_to_default.sh')
        if result is 0:
            logout_user()
            os.system('./reboot.sh &')
            return "success"
        else:
            return "error"


@app.route("/importExportSetting", methods=['GET', 'POST'])
@fresh_login_required
def importExportSetting():
    if request.method == 'GET':
        return render_template('importExportSetting.html')
    if request.method == 'POST':
        # import setting
        if bool(request.files):
            file = request.files['file'];
            if file.filename == '':
                return "empty"
            elif file and allowed_file(file.filename, 'settings'):
                filename = secure_filename(file.filename)
                file.save(os.path.join(
                            app.config['FW_UPLOAD_FOLDER'], filename))
                print("uploaded");
                return "success"
            else:
                return "not allowed"

        # export setting
        elif request.form['func'] == "export":
            s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
            s.connect("/tmp/db.sock")
            send_data = '{"method": "dump"}'
            s.send(send_data)
            data = s.recv(10240)
            data = json.loads(data)
            with open('/tmp/g420x.json', 'w') as outfile:
                json.dump(data, outfile, indent=2)
            return 'g420x.json'


@app.route("/download/<filename>", methods=['GET'])
@fresh_login_required
def download(filename):
    return send_file('/tmp/' + filename, as_attachment=True)


@app.route("/zipFiles", methods=['POST'])
@fresh_login_required
def zipFiles():
    with zipfile.ZipFile('/tmp/'+request.form['zip_name'], 'w') as myzip:
        for path in json.loads(request.form['files']):
            myzip.write(path, path.split('/')[-1])
    return request.form['zip_name']


@app.route("/save", methods=['GET', 'POST'])
@fresh_login_required
def save():
    if request.method == 'GET':
        return render_template('save.html')
    if request.method == 'POST':
        laninfo = models.LanInfo.query.filter_by(id='1').first()
        lansetting = models.LanSetting.query.filter_by(id='1').first()
        laninfo.ip_addr = lansetting.ip_addr
        laninfo.update_db()
        os.system('cp -f /tmp/app.db app/app.db')
        os.chdir('..')
        result = os.system('./web-update-all.sh')
        os.chdir('./web_console')
        if result is 0:
            logout_user()
            os.system('./reboot.sh &')
            return "success"
        else:
            return "error"


@app.route("/restart")
@fresh_login_required
def restart():
    return render_template('restart.html')


@app.route("/logout", methods=['GET', 'POST'])
@fresh_login_required
def logout():
    if request.method == 'GET':
        return render_template('logout.html')
    if request.method == 'POST':
        logout_user()
        return 'success'
