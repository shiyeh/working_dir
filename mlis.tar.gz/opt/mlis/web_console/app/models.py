from copy import copy
from app import db
from werkzeug.security import generate_password_hash


class model_template(object):
    def __init__(self):
        self.css = "/static/css/style.css"
        self.style = None
        self.header = "/static/images/Header.svg"
        self.display_name = "MLiS"
        self.current_user_icon = "/static/images/Curt_user.gif"
        self.logout_icon = "/static/images/logout.gif"
        self.logout_image = "/static/images/7caRqL7oi.png"
        self.save_image = "/static/images/save.png"
        self.footer = "@ 2007 Schmidt & Co., " + \
                      "(HK) Ltd. - Taiwan Branch." + \
                      " All Rights reserved."


class G4201(model_template):
    def __init__(self):
        super(G4201, self).__init__()


class G4202(model_template):
    def __init__(self):
        super(G4202, self).__init__()


class noneTemp(model_template):
    def __init__(self):
        super(noneTemp, self).__init__()
        self.header = "/static/images/Header_none.svg"
        self.display_name = ""
        self.footer = ""


class ISON(model_template):
    def __init__(self):
        super(ISON, self).__init__()
        self.style = "/static/css/style_ISON.css"
        self.header = "/static/images/Header_ISON.svg"
        self.display_name = "ISON"
        self.current_user_icon = "/static/images/user_icon_ISON.png"
        self.logout_icon = "/static/images/logout_ISON.png"
        self.logout_image = "/static/images/Lock_ISON.png"
        self.save_image = "/static/images/save_ISON.png"
        self.footer = "@ Copyright 2015 by ISON Technology Co.," + \
                      " Ltd. All right rights reserved."


class Cellular(db.Model):
    __bind_key__ = 'cellular'
    id = db.Column(db.Integer, primary_key=True)
    rssi = db.Column(db.String(50))
    ip_addr = db.Column(db.String(50))
    mode = db.Column(db.String(50))
    active_sim = db.Column(db.Integer)

    def __init__(self, rssi="N/A", ip_addr="0.0.0.0", mode="N/A",
                 active_sim=1):
        self.rssi = rssi
        self.ip_addr = ip_addr
        self.mode = mode
        self.active_sim = active_sim


class SystemInfo(db.Model):
    __bind_key__ = 'status'
    id = db.Column(db.Integer, primary_key=True)
    model_name = db.Column(db.String(100))
    device_name = db.Column(db.String(100))
    serial_no = db.Column(db.String(100))
    up_time = db.Column(db.Integer)
    fw_ver = db.Column(db.String(100))
    fw_build_time = db.Column(db.String(100))
    kernel_ver = db.Column(db.String(100))
    utc_offset = db.Column(db.String(10))
    timezone = db.Column(db.String(50))

    def __init__(self, model_name="", device_name="",
                 serial_no="", up_time=0, fw_ver="",
                 fw_build_time="", kernel_ver="",
                 utc_offset="+00:00", timezone="UTC"):
        self.up_time = up_time
        self.utc_offset = utc_offset
        self.timezone = timezone

    def get_vars(self):
        var = copy(self)
        var = vars(var)
        del var['_sa_instance_state']
        return var

    def update_db(self, data):
        for keys in data:
            setattr(self, keys, data.get(keys))
        db.session.commit()
        return 0


class LanInfo(db.Model):
    __bind_key__ = 'status'
    id = db.Column(db.Integer, primary_key=True)
    mac_addr = db.Column(db.String(17))
    ip_addr = db.Column(db.String(15))
    submask = db.Column(db.String(15))

    def __init__(self, mac_addr='00:00:00:00:00:00',
                 ip_addr='10.0.10.1', submask='255.255.255.0'):
        self.ip_addr = ip_addr
        self.submask = submask

    def update_db(self, data={}):
        for keys in data:
            setattr(self, keys, data.get(keys))
        db.session.commit()
        return 0


class CellularInfo(db.Model):
    __bind_key__ = 'status'
    id = db.Column(db.Integer, primary_key=True)
    imei = db.Column(db.String(50))
    imsi = db.Column(db.String(50))

    def __init__(self, imei='imei', imsi='imsi'):
        pass


class IoStatus(db.Model):
    __bind_key__ = 'status'
    id = db.Column(db.Integer, primary_key=True)
    relay = db.Column(db.Boolean)

    def __init__(self, relay=False):
        self.relay = relay

    def update_db(self, relay):
        self.relay = relay
        db.session.commit()
        return 0


class User(db.Model):
    __bind_key__ = 'status'
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(100), unique=True)
    password = db.Column(db.String(100))
    permission = db.Column(db.Integer)

    def __init__(self, username=None, password=None, permission=15):
        self.username = username
        self.password = password
        self.permission = permission

    def __repr__(self):
        return '<User %r>' % self.username

    def add(self):
        self.password = generate_password_hash('1234')
        self.permission = 8
        db.session.add(self)
        db.session.commit()

    def delself(self):
        db.session.delete(self)
        db.session.commit()

    def is_authenticated(self):
        return True

    def is_active(self):
        return True

    def is_anonymous(self):
        return False

    def get_id(self):
        return self.id

    def get_username(self):
        return self.username

    def get_password(self):
        return self.password

    def update_password(self, newPassword):
        self.password = generate_password_hash(newPassword)
        db.session.commit()
        return self.password


class LanSetting (db.Model):
    id = db.Column(db.Integer, primary_key=True)
    ip_addr = db.Column(db.String(15))
    submask = db.Column(db.String(15))
    dns = db.Column(db.String(15))
    sec_dns = db.Column(db.String(15))
    allow_ping = db.Column(db.Boolean)
    ping_addr = db.Column(db.String(15))
    ping_intvl = db.Column(db.String(15))

    def __init__(
            self, ip_addr="10.0.10.1", submask="255.255.255.0",
            dns="8.8.8.8", sec_dns="8.8.4.4", allow_ping=False,
            ping_addr="8.8.8.8", ping_intvl="60"):
        self.ip_addr = ip_addr
        self.submask = submask
        self.dns = dns
        self.sec_dns = sec_dns
        self.allow_ping = allow_ping
        self.ping_addr = ping_addr
        self.ping_intvl = ping_intvl

    def update_db(self):
        db.session.commit()
        return 0


class WANPrioritySetting(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    redundant = db.Column(db.Boolean)
    priority = db.Column(db.Integer)
    reg_nw_timeout = db.Column(db.Integer)
    data_session_retry = db.Column(db.Integer)
    term_redundant = db.Column(db.Integer)

    def __init__(self, **kwargs):
        self.__dict__.update(kwargs)

    def get_vars(self):
        var = copy(self)
        var = vars(var)
        del var['_sa_instance_state']
        return var

    def update_db(self, data):
        for keys in data:
            setattr(self, keys, data.get(keys))
        db.session.commit()
        return 0


class WANSetting (db.Model):
    id = db.Column(db.Integer, primary_key=True)
    apn = db.Column(db.String(50))
    pin = db.Column(db.String(4))
    auth = db.Column(db.String(4))
    username = db.Column(db.String(100))
    password = db.Column(db.String(100))

    def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    def get_vars(self):
        var = copy(self)
        var = vars(var)
        del var['_sa_instance_state']
        return var

    def update_db(self, data):
        for keys in data:
            setattr(self, keys, data.get(keys))
        db.session.commit()
        return 0


class DHCPServer (db.Model):
    id = db.Column(db.Integer, primary_key=True)
    dhcp_server = db.Column(db.Boolean)
    gateway = db.Column(db.String(15))
    submask = db.Column(db.String(15))
    dns = db.Column(db.String(15))
    sec_dns = db.Column(db.String(15))
    start_ip = db.Column(db.String(15))
    max_users = db.Column(db.Integer)
    client_time = db.Column(db.Integer)

    def __init__(self, **kwargs):
        self.__dict__.update(kwargs)

    def get_vars(self):
        var = vars(self)
        del var['_sa_instance_state']
        return var

    def update_db(self, data):
        for keys in data:
            setattr(self, keys, data.get(keys))
        db.session.commit()
        return self


class DHCPMapping (db.Model):
    id = db.Column(db.Integer, primary_key=True)
    active = db.Column(db.Boolean)
    ip = db.Column(db.String(15))
    mac = db.Column(db.String(17))

    def __init__(self, active=False, ip="", mac=""):
        self.active = active
        self.ip = ip
        self.mac = mac

    def update_db(self, active, ip, mac):
        self.active = active
        self.ip = ip
        self.mac = mac
        db.session.commit()
        return 0


class PortForwarding (db.Model):
    id = db.Column(db.Integer, primary_key=True)
    active = db.Column(db.Boolean)
    protocol = db.Column(db.String(3))
    public_port = db.Column(db.String(5))
    ip = db.Column(db.String(15))
    internal_port = db.Column(db.String(5))

    def __init__(self, active=False,
                 protocol="TCP", public_port="", ip="", internal_port=""):
        self.active = active
        self.protocol = protocol
        self.public_port = public_port
        self.ip = ip
        self.internal_port = internal_port

    def update_db(self, active, protocol, public_port, ip, internal_port):
        self.active = active
        self.protocol = protocol
        self.public_port = public_port
        self.ip = ip
        self.internal_port = internal_port
        db.session.commit()
        return 0


class VpnActive (db.Model):
    id = db.Column(db.Integer, primary_key=True)
    active = db.Column(db.Boolean)

    def __init__(self, active=False):
        self.active = active

    def update_db(self, active):
        self.active = active
        db.session.commit()
        return 0


class Vpn (db.Model):
    id = db.Column(db.Integer, primary_key=True)
    ipsec = db.Column(db.Boolean)
    conn_name = db.Column(db.String(19))
    _left = db.Column(db.String(15))
    startup_mode = db.Column(db.Boolean)
    leftsubnet = db.Column(db.String(18))
    leftid = db.Column(db.String(50))
    _right = db.Column(db.String(15))
    rightsubnet = db.Column(db.String(18))
    rightid = db.Column(db.String(50))
    keyexchange = db.Column(db.String(5))
    aggressive = db.Column(db.String(3))
    ike = db.Column(db.String(25))
    lifetime = db.Column(db.String(3))
    rekey = db.Column(db.String(3))
    esp = db.Column(db.String(20))
    dpdaction = db.Column(db.String(7))
    dpddelay = db.Column(db.String(4))
    dpdtimeout = db.Column(db.String(4))
    auth_mode = db.Column(db.String(20))
    psk = db.Column(db.String(100))
    local_cert = db.Column(db.String(100))
    remote_cert = db.Column(db.String(100))

    def __init__(self, **kwargs):
        self.__dict__.update(kwargs)

    def get_vars(self):
        var = vars(self)
        del var['_sa_instance_state']
        return var

    def update_db(self, data):
        for keys in data:
            setattr(self, keys, data.get(keys))
        db.session.commit()
        return 0


class caCert (db.Model):
    id = db.Column(db.Integer, primary_key=True)
    lifetime = db.Column(db.Integer)
    c = db.Column(db.String(2))
    st = db.Column(db.String(50))
    l = db.Column(db.String(50))
    o = db.Column(db.String(50))
    ou = db.Column(db.String(50))
    cn = db.Column(db.String(50))
    e = db.Column(db.String(50))

    def __init__(self, **kwargs):
        self.__dict__.update(kwargs)

    def get_vars(self):
        var = copy(self)
        var = vars(var)
        del var['_sa_instance_state']
        return var

    def update_db(self, data):
        for keys in data:
            setattr(self, keys, data.get(keys))
        db.session.commit()
        return 0


class eeCert (db.Model):
    id = db.Column(db.Integer, primary_key=True)
    ee_name = db.Column(db.String(50))
    lifetime = db.Column(db.Integer)
    c = db.Column(db.String(2))
    st = db.Column(db.String(50))
    l = db.Column(db.String(50))
    o = db.Column(db.String(50))
    ou = db.Column(db.String(50))
    cn = db.Column(db.String(50))
    e = db.Column(db.String(50))

    def __init__(self, **kwargs):
        self.__dict__.update(kwargs)

    def get_vars(self):
        var = copy(self)
        var = vars(var)
        del var['_sa_instance_state']
        return var

    def update_db(self, data):
        for keys in data:
            setattr(self, keys, data.get(keys))
        db.session.commit()
        return 0


class openvpn (db.Model):
    id = db.Column(db.Integer, primary_key=True)
    active = db.Column(db.Boolean)
    conf = db.Column(db.String(50))

    def __init__(self, active=False, conf=''):
        self.active = active
        self.conf = conf

    def update_db(self):
        db.session.commit()
        return 0


class comSetting (db.Model):
    id = db.Column(db.Integer, primary_key=True)
    work_mode = db.Column(db.String(10))
    trans_mode = db.Column(db.String(5))
    baud_rate = db.Column(db.Integer)
    parity = db.Column(db.String(4))
    data_bits = db.Column(db.Integer)
    stop_bits = db.Column(db.Integer)
    service_mode = db.Column(db.Integer)
    ip_addr = db.Column(db.String(15))
    port = db.Column(db.Integer)

    def __init__(self, **kwargs):
        self.__dict__.update(kwargs)

    def get_vars(self):
        var = copy(self)
        var = vars(var)
        del var['_sa_instance_state']
        return var

    def update_db(self, data):
        for keys in data:
            setattr(self, keys, data.get(keys))
        db.session.commit()
        return 0


class snmpAgent(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    active = db.Column(db.Boolean)
    read_community = db.Column(db.String(50))
    write_community = db.Column(db.String(50))
    agent_ver = db.Column(db.Integer)
    auth_protocol = db.Column(db.Integer)
    auth_key = db.Column(db.String(50))
    priv_protocol = db.Column(db.Integer)
    priv_key = db.Column(db.String(50))

    def __init__(self, **kwargs):
        self.__dict__.update(kwargs)

    def get_vars(self):
        var = copy(self)
        var = vars(var)
        del var['_sa_instance_state']
        return var

    def update_db(self, data):
        for keys in data:
            setattr(self, keys, data.get(keys))
        db.session.commit()
        return 0


class ServiceSetting (db.Model):
    id = db.Column(db.Integer, primary_key=True)
    lan_allow_http = db.Column(db.Boolean)
    lan_allow_https = db.Column(db.Boolean)
    lan_allow_ssh = db.Column(db.Boolean)
    wan_allow_http = db.Column(db.Boolean)
    wan_allow_https = db.Column(db.Boolean)
    wan_allow_ssh = db.Column(db.Boolean)

    def __init__(self,
            lan_allow_http=True, lan_allow_https=True, lan_allow_ssh=True,
            wan_allow_http=False, wan_allow_https=False, wan_allow_ssh=False):
        self.lan_allow_http = lan_allow_http
        self.lan_allow_https = lan_allow_https
        self.lan_allow_ssh = lan_allow_ssh
        self.wan_allow_http = wan_allow_http
        self.wan_allow_https = wan_allow_https
        self.wan_allow_ssh = wan_allow_ssh

    def update_db(self, data):
        for keys in data:
            setattr(self, keys, data.get(keys))
        db.session.commit()
        return 0
