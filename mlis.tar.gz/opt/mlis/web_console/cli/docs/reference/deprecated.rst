Deprecated Classes
------------------

.. currentmodule:: urwid

.. autoclass:: FlowWidget

.. autoclass:: BoxWidget

.. autoclass:: FixedWidget

.. autoclass:: AttrWrap

.. autoclass:: PollingListWalker
