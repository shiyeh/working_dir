Raw Display Attributes
======================

.. currentmodule:: urwid

.. autoclass:: AttrSpec
