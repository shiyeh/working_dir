#!/bin/sh
source /opt/mlis/init-mlb-env.sh

if [ ! -n "${PPP_CTRL+1}" ]
then 
	PPP_CTRL="/var/tmp/ppp-stop"
fi
touch "${PPP_CTRL}"

rm -f ${SYS_VPN_CAS_DIR}/*
rm -f ${SYS_VPN_PRIVATE_KEY_DIR}/*
rm -f ${MLB_OPENVPN_CONF_DIR}/*.conf
rm -rf ${SYS_VPN_CERTS_DIR}
rm -f ${MLB_INIT_PATH}
