import os
from app import db, models
from werkzeug.security import generate_password_hash

if os.path.exists('/tmp/app.db'):
    os.system('rm -f /tmp/app.db')
if os.path.exists('app/status.db'):
    os.system('rm -f app/status.db')

db.create_all()

# =====================Lan Setting=============================================
lan_setting = models.LanSetting(ip_addr='10.0.10.1', submask='255.255.255.0',
                                dns='8.8.8.8', sec_dns='8.8.4.4',
                                allow_ping=False, ping_addr="8.8.8.8",
                                ping_intvl="60")
db.session.add(lan_setting)


# =====================WAN Setting=============================================
pri = models.WANPrioritySetting(redundant=0,
                                priority=1,
                                reg_nw_timeout=5,
                                data_session_retry=2,
                                term_redundant=10)
wan1 = models.WANSetting(apn='internet', pin='', auth='',
                         username='', password='')
wan2 = models.WANSetting(apn='internet', pin='', auth='',
                         username='', password='')
db.session.add(wan1)
db.session.add(wan2)
db.session.add(pri)


# =====================DHCP Server=============================================
dhcp_server = models.DHCPServer(dhcp_server=1, gateway='10.0.10.1',
                                submask='255.255.255.0', dns='8.8.8.8',
                                sec_dns='8.8.4.4',
                                start_ip='10.0.10.100', max_users=20,
                                client_time=14400)
db.session.add(dhcp_server)


# =====================DHCP Mapping============================================
for i in range(16):
    dhcp_mapping = models.DHCPMapping(active=False, ip='', mac='')
    db.session.add(dhcp_mapping)


# =====================Port Forwarding=========================================
for i in range(32):
    port_forwarding = models.PortForwarding(active=False, protocol='tcp',
                                            public_port='', ip='',
                                            internal_port='')
    db.session.add(port_forwarding)


# =====================comport=================================================
com = models.comSetting(work_mode='trans',
                        trans_mode='232',
                        baud_rate=115200,
                        parity='none',
                        data_bits=8,
                        stop_bits=1,
                        service_mode=0,
                        ip_addr='0.0.0.0',
                        port='')

db.session.add(com)

# =====================snmp agent==============================================
snmp = models.snmpAgent(active=0, read_community='',
                        write_community='', agent_ver=1,
                        auth_protocol=0, auth_key='',
                        priv_protocol=0, priv_key='')
db.session.add(snmp)
# =====================VPN=====================================================
vpn_active = models.VpnActive(active=False)
db.session.add(vpn_active)

for i in range(5):
    vpn = models.Vpn(ipsec='0', conn_name='', _left='',
                     startup_mode='0', leftsubnet='',
                     leftid='', _right='', rightsubnet='',
                     rightid='', keyexchange='ikev1', aggressive='no',
                     psk='', ike='aes128-md5-modp1024!', lifetime='3h',
                     rekey='yes', esp='aes128-md5!', dpdaction='none',
                     dpddelay='30s', dpdtimeout='150s', auth_mode='psk',
                     local_cert='', remote_cert='')
    db.session.add(vpn)

# =====================caCert==================================================
caCert = models.caCert(lifetime="1095", c='', st='', l='',
                       o='', ou='', cn='', e='')
db.session.add(caCert)

# =====================caCert==================================================
eeCert = models.eeCert(ee_name='', lifetime='', c='', st='', l='',
                       o='', ou='', cn='', e='')
db.session.add(eeCert)

# =====================openVPN=================================================
openvpn = models.openvpn(active=0, conf="None")
db.session.add(openvpn)

# =====================Service Setting=========================================
service_setting = models.ServiceSetting(lan_allow_http=True,
                                        lan_allow_https=True,
                                        lan_allow_ssh=True,
                                        wan_allow_http=False,
                                        wan_allow_https=False,
                                        wan_allow_ssh=False)
db.session.add(service_setting)

# =============================================================================
# =====================status.db===============================================
# =====================system_info=============================================
system_info = models.SystemInfo()
db.session.add(system_info)

# =====================len info================================================
lan_info = models.LanInfo()
db.session.add(lan_info)

# =====================cellular info===========================================
cellular_info = models.CellularInfo()
db.session.add(cellular_info)

# =====================io status===============================================
io_status = models.IoStatus()
db.session.add(io_status)

# =====================User====================================================
admin_password = generate_password_hash('1234')
admin = models.User(username='admin', password=admin_password, permission=1)
db.session.add(admin)
guest_password = generate_password_hash('')
guest = models.User(username='guest', password=guest_password, permission=15)
db.session.add(guest)

db.session.commit()
os.system('cp /tmp/app.db app/')
os.system('cp /tmp/app.db ../conf/app.db.bak')
os.system('cp app/status.db ../conf/status.db.bak')
