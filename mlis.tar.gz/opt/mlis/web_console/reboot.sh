#!/bin/sh

sync
sleep 1
reboot
