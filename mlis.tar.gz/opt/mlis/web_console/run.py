import os

if not os.path.exists('/tmp/app.db'):
    os.system('cp -f app/app.db /tmp/app.db')

from app import db, models
from app import app as application

if os.path.exists('/tmp/cellular.db'):
    os.system('rm -f /tmp/cellular.db')

db.create_all(bind='cellular')
cellular = models.Cellular()
db.session.add(cellular)
db.session.commit()

if __name__ == '__main__':
    application.run(host='0.0.0.0')
